# WARP3/warp2/corpus/shelf.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/shelf.py
#  Used by   : warp2/corpus/convert/run.py (what is kept, measured);
#              warp2/corpus/tests/.
#  Uses      : warp2/corpus/parts.py; warp2/corpus/convert/kg.py (kg_parts);
#              warp2/corpus/convert/webs.py (kept_now); warp2/store/small_kg/
#              layout.py (the KG's build in use); (stdlib) pathlib.
#  Description:
#    EVERY CORPUS OF THE WARP IN ONE PLACE, EACH WITH ITS OWN FORM HIDDEN.
#    A thing is read back by what it is and comes back the same; how each
#    kind is kept stays inside its own corpus:
#      the KG's record  - anchors over the KG's corpus beside its book (read
#                         through warp2/tags/dehydrated/small_bytes.py)
#      the KG's facts   - the KG itself: the record's book and corpus, read
#                         where they are (warp2/store/small_kg/, BUILD_LOG
#                         1656c - there is no working view any more)
#      the connection web - the webs over the KG as blocks of columns over
#                         one word table (convert/webs.py, BUILD_LOG 1638c)
#      the state's text - anchors over the text corpus of each collection
#                         (read through convert/state_text.py file_back - a
#                         packed file given back packed, the same bytes)
#      the models, the Eye, the pictures - their tensor books, the models'
#                         own corpus kept the old way, each file an anchor
#                         over its tensors (said here by what they hold)
#    `measures` says, for every corpus, what its things take as they are and
#    what they take in corpus form.
#  User intention (Andrew, 2026-11-13 21:01): "we can have the old way for
#    the models as their own corpus and use that form there"; 21:05: "keep
#    the ease of this form but hide higher forms in each things corpus of
#    tags and we should also allow cross tags". BUILD_LOG 1621c.
# ============================================================================
"""Every corpus of the warp and what each measures."""
from __future__ import annotations

from pathlib import Path

from warp2.corpus.convert.kg import kg_parts
from warp2.corpus.parts import Parts

RECORD = Path("store") / "tags" / "dehydrated" / "web_tagged"
BOOKS = {"house models": Path("house") / "models_small" / "book", "eye": Path("models") / "eye" / "pairs_small",
         "pictures": Path("store") / "media_small" / "book"}


class Shelf:
    """Intention: the warp's corpora, found from the state folder."""

    def __init__(self, state) -> None:
        """Intention: the state folder whose corpora these are."""
        self.state = Path(state)

    def measures(self) -> dict:
        """Intention: for every corpus, its parts' size and what its things take as they are."""
        out = {}
        record = kg_parts(self.state / RECORD)
        out["kg record"] = _summed(record)
        text_home = self.state / "corpus" / "text"
        for folder in sorted(text_home.iterdir()) if text_home.is_dir() else []:
            out[f"text {folder.name}"] = _summed(Parts(folder))
        # Intention (BUILD_LOG 1656c): the KG's facts are the record itself - what the small KG adds beside it is
        # the build in use: the ways each tag knows its facts, kept by function.
        from warp2.store.small_kg.layout import build_folder, current_build
        build = build_folder(self.state / "store") if current_build(self.state / "store") else None
        out["kg facts"] = {"build": build.name if build else "",
                           "kept_bytes": sum(p.stat().st_size for p in build.iterdir() if p.is_file())
                           if build and build.is_dir() else 0,
                           "form": "the record's tags, found by each tag, kept by function"}
        # Intention (1638c): the connection web - its picture now kept, and the database it was kept from.
        from warp2.corpus.convert.webs import kept_now
        webs = kept_now(self.state)
        out["connection web"] = {"kept_bytes": webs.get("bytes", 0), "as_it_was_bytes": webs.get("db_bytes", 0),
                                 "rows": webs.get("rows", 0), "at": webs.get("at", ""),
                                 "form": "columns over one word table"}
        for name, folder in BOOKS.items():
            path = self.state / folder
            out[name] = {"kept_bytes": sum(p.stat().st_size for p in path.rglob("*") if p.is_file())
                         if path.is_dir() else 0, "form": "tensor book"}
        return out


def _summed(parts) -> dict:
    """Intention: a corpus's parts summed - as they were, kept, how many things."""
    total = {"parts": 0, "things": 0, "hydrated": 0, "kept_bytes": 0, "corpus": 0, "notations": 0}
    for path in parts.files():
        head = parts.head(path)
        total["parts"] += 1
        total["things"] += head["things"]
        total["hydrated"] += head["measures"]["hydrated"]
        total["corpus"] += head["measures"]["corpus"]
        total["notations"] += head["measures"]["notations"]
        total["kept_bytes"] += path.stat().st_size
    return total
