# WARP2/warp2/corpus/convert/rest.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/rest.py
#  Used by   : warp2/work/side/dehydrate_rest.py (each turn of the warp, in a
#              child process); warp2/corpus/tests/.
#  Uses      : warp2/corpus/convert/{state_text,turn_walk,webs}.py (the
#              ways each kind is kept small, each reading back what it keeps);
#              warp2/corpus/kinds/keep.py (every file that is not text);
#              projects/behemoth_eye/eye/turn_clock.py (the turn it runs
#              inside); warp2/record/kept_file.py; (stdlib) time.
#  Description:
#    EVERYTHING THE WARP HOLDS THAT IS NOT IN ITS SMALL FORM YET - FOUND,
#    AND KEPT SMALL, INSIDE ONE TURN. Each turn, in this order:
#      1. (BUILD_LOG 1656c) nothing for the KG's facts: they are the record
#         held small, asked where they are (warp2/store/small_kg/);
#      2. the connection web - a new picture when the web has changed by at
#         least what a picture takes to keep, and the turn still has the time
#         the last picture took (so pictures pile up no faster than the web
#         changes, and a picture never runs past the turn);
#      3. (1652c) the state walked on from where the last turn stopped, a
#         folder at a time (turn_walk.py - a whole listing takes minutes, a
#         turn far less: the first live turn, 43 seconds, listed everything
#         and kept nothing): in each folder the text not kept yet, or
#         written since, goes to its collection's part (state_text.py
#         TextTurn), and every file that is not text - pictures, weights,
#         arrays, databases, anything - is kept its least way, the way
#         learned kind by kind (warp2/corpus/kinds); a folder counts as
#         walked only once both are done with it, so nothing is passed by
#         when the time comes part way.
#    Everything kept is read back the same before it counts (each way's own
#    rule). What is still waiting is written to state/corpus/rest.json each
#    turn and handed back, so it can be seen.
#    The KG's lane and record, the models' books and the pictures already
#    have their own turn (warp2/work/side/keep_kg_small.py); they are not
#    done again here.
#  User intention (Andrew, 2026-11-14 22:25): "Let's get a system to look for
#    nondehydrated things and dehydrates them and puts them in the smaller
#    kg." (2026-11-13 20:35) "everything needs to be in and run from a fully
#    dehydrated form." BUILD_LOG 1651c. 23:42: "Then we need to adapt it to
#    adapt it to everything" (BUILD_LOG 1652c).
# ============================================================================
"""What the warp holds that is not small yet, found and kept small inside one turn."""
from __future__ import annotations

import time
from pathlib import Path

from warp2.corpus.convert.state_text import TextTurn
from warp2.corpus.convert.turn_walk import StateWalk
from warp2.corpus.convert.webs import keep_webs, kept_now, source_of
from warp2.corpus.kinds.keep import KindsTurn
from warp2.record.kept_file import write_kept

REPORT = "rest.json"


class DehydrateRest:
    """Intention: one turn of it, as plain values (the state folder) so it crosses into a spawned child."""

    def __init__(self, state) -> None:
        """Intention: the state folder, kept as text."""
        self.state = str(state)

    def __call__(self) -> dict:
        """Intention: the turn done; what it kept and what still waits, handed back."""
        return rest(Path(self.state))


def rest(state) -> dict:
    """One turn: the KG's new facts, the connection web, then the state walked on from where the last turn stopped -
    its text and every other kind of file - kept small inside the turn's time.

    Intention: the order is what the KG needs first (its facts), then what
    is heaviest to keep and least often new (the web's picture, only when
    the turn has the time it last took), then the walk (1652c): the state
    is walked a folder at a time, carried from turn to turn (turn_walk.py) -
    a turn far shorter than one listing of the whole state still gets on.
    In each folder the text goes to its collection's part (TextTurn) and
    every other file is kept its least way (KindsTurn); a folder counts as
    walked only once both are done with it. The report goes beside the
    corpora; a short form of it is handed back for the journal.
    """
    state = Path(state)
    began = time.monotonic()
    until = _until()
    report = {"at": time.strftime("%Y-%m-%d %H:%M:%S")}
    # Intention (BUILD_LOG 1656c; Andrew 2026-11-15 13:59: "The KG should be the dehydrated tag one"): the KG's
    # facts are the record held small, asked where they are (warp2/store/small_kg) - there is no view of them left
    # to copy into blocks, so this step has nothing to keep.
    report["facts"] = {"did": "the KG's facts are the record held small", "rows": 0, "waiting": 0}
    report["webs"] = _webs(state, until)
    walk, text, kinds = StateWalk(state), TextTurn(state, say=lambda _line: None), KindsTurn(state, say=lambda _line: None)
    try:
        collection_now = None
        for collection, folder, files in walk.folders(until):
            if collection != collection_now and collection_now is not None:
                text.finish(collection_now)
            collection_now = collection
            handed = text.take(collection, files, until)
            if text.stopped:
                break
            kinds.keep(handed, until)
            if kinds.stopped:
                break
            walk.done_with(folder)
    finally:
        done = text.close()
        kept = kinds.close()
        report["walk"] = walk.save()
    report["text"] = {"files": done["files"], "bytes_were": done["bytes_were"],
                      "parts": len([p for p in done["parts"] if p.get("kept")]),
                      "bytes_now": sum(int(p.get("bytes") or 0) for p in done["parts"] if p.get("kept")),
                      "not_looked_at": done["not_looked_at"], "own_form_smaller": done["own_form_smaller"],
                      "written_while_kept": len(done["written_while_kept"]),
                      "not_text": {kind: list(found) for kind, found in sorted(done["not_text"].items())}}
    report["kinds"] = {key: (value if key != "by_kind" else {kind: list(found) for kind, found in sorted(value.items())})
                       for key, value in kept.items()}
    report["seconds"] = round(time.monotonic() - began, 1)
    write_kept(state / "corpus" / REPORT, report, indent=1)
    return said(report)


def said(report: dict) -> dict:
    """Intention: the turn's report, short - for the journal and the thread."""
    text, facts, webs, kinds = report["text"], report["facts"], report["webs"], report["kinds"]
    no_form = report["text"]["not_text"]
    kept = facts.get("rows") or text["files"] or webs.get("bytes_now") or kinds["files"]
    return {"did": "kept small" if kept else "nothing new",
            "facts_kept": int(facts.get("rows") or 0), "facts_waiting": int(facts.get("waiting") or 0),
            "text_files_kept": text["files"], "text_bytes_were": text["bytes_were"], "text_bytes_now": text["bytes_now"],
            "text_files_not_looked_at": text["not_looked_at"],
            "webs": webs.get("did"), "webs_why": webs.get("why", ""),
            "not_text_files": sum(found[0] for found in no_form.values()),
            "not_text_bytes": sum(found[1] for found in no_form.values()),
            "kinds_files_kept": kinds["files"], "kinds_bytes_were": kinds["bytes_were"],
            "kinds_bytes_now": kinds["bytes_now"], "kinds_own_form_smaller": kinds["own_form_smaller"]["files"],
            "kinds_waiting": kinds["not_looked_at"] + kinds["waits_for_time"] + kinds["still_being_written"],
            "kinds_in_other_books": sum(kinds["in_other_books"].values()),
            "walk_pass_ended": report["walk"]["pass_ended"], "walk_folders_left": report["walk"]["folders_left"],
            "seconds": report["seconds"]}


def _until():
    """Intention: the end of the turn this runs inside, as a time.monotonic(); None with no turn (then no end is set)."""
    from projects.behemoth_eye.eye.turn_clock import current
    clock = current()
    left = clock.left() if clock is not None else None
    return None if left is None else time.monotonic() + max(0.0, float(left))


def _left(until) -> float | None:
    """Intention: the seconds left of the turn; None with no turn."""
    return None if until is None else until - time.monotonic()


def webs_due(state, left) -> tuple:
    """(whether a new picture of the connection web is due now, and why not when it is not).

    Intention: a picture is kept beside the last one, nothing thrown away -
    so one is taken only when the web has changed by at least what a picture
    takes to keep, and only when the turn has the time the last one took.
    """
    source = source_of(state)
    if not source.is_file():
        return False, "there is no connection web yet"
    kept = kept_now(state)
    if not kept:
        return True, ""
    stat = source.stat()
    if kept.get("db_bytes") == stat.st_size and kept.get("db_mtime_ns") == stat.st_mtime_ns:
        return False, "the picture kept is of the web as it is now"
    if abs(stat.st_size - int(kept.get("db_bytes") or 0)) < int(kept.get("bytes") or 0):
        return False, "the web has changed by less than a picture takes to keep"
    if left is not None and left < float(kept.get("seconds") or 0.0):
        return False, f"the turn has less left than a picture took ({kept.get('seconds')} s)"
    return True, ""


def _webs(state: Path, until) -> dict:
    """Intention: a new picture of the connection web when one is due; otherwise why not."""
    due, why = webs_due(state, _left(until))
    if not due:
        return {"did": "not now", "why": why}
    kept = keep_webs(state, say=lambda _line: None)
    return {"did": kept.get("did", "kept"), "rows": kept.get("rows", 0), "bytes_now": kept.get("bytes", 0),
            "db_bytes": kept.get("db_bytes", 0), "seconds": kept.get("seconds", 0.0)}
