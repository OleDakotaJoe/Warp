# WARP3/warp2/corpus/convert/pace.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/convert/pace.py
#  Used by   : warp2/corpus/convert/outside.py (BringIn - the seconds each file that is not text is given);
#              warp2/corpus/tests/test_outside_folders_come_in_through_the_warps_own_keeper.py.
#  Uses      : warp2/room/mine.py (my_room - what a new piece of work may take now); psutil (the process's peak).
#  Description:
#    HOW FAST A RUN KEEPS WHAT IS NOT TEXT, SO EACH FILE IS GIVEN SECONDS BY ITS SIZE. Nothing is set: the first
#    file of a run is given no end; after it, a file is given its size at the pace the run has measured so far,
#    twice over (the pieces book's miner stops there and what it found is kept). Files are handed in smallest
#    first, so the first measure is the cheapest.
#    2026-11-22: AND THE MEMORY A BYTE COSTS. The first run kept a 320 MB zip with 1.4 GB free and ended on a memory
#    error after holding 6.4 GB (the pieces book makes each byte an 8-byte number, and more besides). The most a byte
#    has cost so far (from how far each file raised the process's peak) times a file's size is held against the room
#    a new piece of work may take now; a file that does not fit waits for a later run.
#  User intention (Andrew, 2026-10-26): no part of his code should be just set numbers - any number must come from
#    a calculable source; (2026-11-09 22:41-22:59) time constraints adaptive, applied where needed.
# ============================================================================
"""The pace a run keeps files at, and the seconds a file of a size is given by it."""
from __future__ import annotations


def peak_now() -> int:
    """Intention: the most memory this process has held so far (Windows keeps it; elsewhere what it holds now)."""
    import psutil
    held = psutil.Process().memory_info()
    return int(getattr(held, "peak_wset", 0) or held.rss)


class Pace:
    """Intention: bytes kept, seconds taken and memory a byte has cost so far in this run."""

    def __init__(self) -> None:
        """Intention: nothing measured yet."""
        self.bytes, self.seconds = 0, 0.0
        self.memory_a_byte = 0.0

    def fits(self, size: int) -> bool:
        """Intention (2026-11-22): whether a file of this size can be kept now - its size at the memory a byte has
        cost in this run, against the room a new piece of work may take now (warp2/room/mine.py my_room, which leaves
        room for the rest of the machine). Before anything is measured, yes (the run goes smallest first)."""
        if self.memory_a_byte <= 0:
            return True
        from warp2.room.mine import my_room
        return int(size) * self.memory_a_byte <= my_room()

    def given(self, size: int):
        """Intention: the seconds a file of this size is given - none (no end) before anything is measured."""
        if self.bytes == 0 or self.seconds <= 0:
            return None
        return 2 * size * self.seconds / self.bytes

    def took(self, size: int, seconds: float, grew: int = 0) -> None:
        """Intention: one file's keeping counted in the pace; `grew`, how far its keeping raised the process's peak
        memory - the most a byte has cost so far is kept."""
        self.bytes += int(size)
        self.seconds += float(seconds)
        if size and grew > 0:
            self.memory_a_byte = max(self.memory_a_byte, grew / int(size))
