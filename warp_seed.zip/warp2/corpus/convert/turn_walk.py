# WARP2/warp2/corpus/convert/turn_walk.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/turn_walk.py
#  Used by   : warp2/corpus/convert/rest.py (each turn's keeping of what is
#              not small yet); warp2/corpus/tests/.
#  Uses      : warp2/corpus/convert/state_text.py (corpora_of_their_own);
#              warp2/record/kept_file.py; (stdlib) os, time, pathlib.
#  Description:
#    THE STATE WALKED A FOLDER AT A TIME, ACROSS AS MANY TURNS AS IT TAKES.
#    Listing the whole state takes minutes (343,358 files, 2026-11-15) and
#    the warp's turn of keeping is far shorter (the first live one had 43
#    seconds - it listed everything and had no time left to keep anything).
#    So the walk is carried from turn to turn: the folders still to be
#    walked are kept in state/corpus/walk.json; each turn lists folders, one
#    after another (each folder's files before the folders in it, in name
#    order), until its time is up; a folder counts as walked only once the
#    turn has finished with its files (`done_with`) - one left part way is
#    the first the next turn lists. When every folder has been walked the
#    pass is over and the next turn starts again at the top; files kept and
#    not written since are passed over at once, so a pass after the first
#    is quick. The corpora of their own are not walked.
#  User intention (Andrew, 2026-11-14 22:25): "a system to look for
#    nondehydrated things and dehydrates them"; 23:42: "adapt it to
#    everything" - and working in the turns the warp has. BUILD_LOG 1652c.
# ============================================================================
"""The state walked a folder at a time, carried from turn to turn until every folder has been walked."""
from __future__ import annotations

import os
import time
from pathlib import Path

from warp2.record.kept_file import read_kept, write_kept

WALK = "walk.json"


class StateWalk:
    """Intention: the folders still to walk, read from where the last turn left them, and written back at the end."""

    def __init__(self, state) -> None:
        """Intention: the state, and the walk where it was left (a new pass when there was none, or it had ended)."""
        from warp2.corpus.convert.state_text import corpora_of_their_own
        self.state = Path(state)
        self.home = self.state / "corpus" / WALK
        kept = read_kept(self.home, dict)
        kept = kept if isinstance(kept, dict) else {}
        self.passes = int(kept.get("passes", 0))
        self.began = kept.get("began") or time.strftime("%Y-%m-%d %H:%M:%S")
        self.stack = [str(self.state / rel) for rel in kept.get("pending", [])] or [str(self.state)]
        if not kept.get("pending"):
            self.began = time.strftime("%Y-%m-%d %H:%M:%S")
        self.own = {str(each) for each in corpora_of_their_own(self.state)}
        self.listed = 0
        self._inside: dict = {}

    def folders(self, until: float | None = None):
        """Intention: (collection, folder, [(path, write time, size)]) for each folder in turn, until the time is up or
        every folder has been walked. The same folder is given again until `done_with` says it is finished."""
        while self.stack:
            if until is not None and time.monotonic() >= until:
                return
            folder = self.stack[-1]
            if folder in self.own:
                self.stack.pop()
                continue
            files, inside = self._listing(folder)
            self._inside[folder] = inside
            self.listed += 1
            rel = Path(folder).relative_to(self.state)
            yield (rel.parts[0] if rel.parts else "."), Path(folder), files
            if self.stack and self.stack[-1] == folder:
                return   # Intention: the turn stopped part way through this folder - it is the next turn's first

    def done_with(self, folder) -> None:
        """Intention: a folder's files are finished - it leaves the walk, and the folders in it come next."""
        folder = str(folder)
        if self.stack and self.stack[-1] == folder:
            self.stack.pop()
            self.stack.extend(reversed(self._inside.pop(folder, [])))

    def _listing(self, folder: str) -> tuple:
        """Intention: a folder's files (path, write time, size - from the listing itself) and the folders in it, each in
        name order; a folder that cannot be listed now gives nothing (the next pass lists it)."""
        try:
            with os.scandir(folder) as listing:
                entries = sorted(listing, key=lambda entry: entry.name)
        except OSError:  # fault: ok a folder that cannot be listed now is passed over; the next pass lists it
            return [], []
        files, inside = [], []
        for entry in entries:
            try:
                if entry.is_dir(follow_symlinks=False):
                    inside.append(entry.path)
                    continue
                if not entry.is_file(follow_symlinks=False):
                    continue
                seen = entry.stat(follow_symlinks=False)
            except OSError:  # fault: ok an entry gone since the listing is passed over
                continue
            files.append((Path(entry.path), seen.st_mtime_ns, seen.st_size))
        return files, inside

    def save(self) -> dict:
        """Intention: where the walk is, written for the next turn - the folders still to walk, or a pass ended."""
        ended = not self.stack
        if ended:
            self.passes += 1
        kept = {"pending": [str(Path(each).relative_to(self.state)) for each in self.stack],
                "passes": self.passes, "began": self.began, "listed_this_turn": self.listed}
        write_kept(self.home, kept, indent=1)
        return {"pass_ended": ended, "passes": self.passes, "folders_listed": self.listed,
                "folders_left": len(self.stack)}
