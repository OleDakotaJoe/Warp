# WARP2/warp2/corpus/convert/state_text.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/state_text.py
#  Used by   : warp2/corpus/convert/run.py, warp2/corpus/convert/rest.py (each
#              turn of the warp, inside the turn's time); warp2/corpus/kinds/
#              keep.py (OwnForm); warp2/corpus/tests/.
#  Uses      : warp2/corpus/{parts,varint}.py; warp2/corpus/convert/{memory,
#              packed}.py; warp2/record/kept_file.py (own_form.json);
#              (stdlib) zlib (crc32 - which share a file falls to);
#              (stdlib) os, time, pathlib.
#  Description:
#    EVERY TEXT FILE OF THE STATE AS AN ANCHOR OVER THE TEXT CORPUS OF ITS
#    COLLECTION (the folder it is in under state/). A file is text when it
#    holds no zero byte and reads as UTF-8; a packed file (gzip, zlib) is
#    taken as its text when it packs back to the very same bytes
#    (packed.py). Its anchor: its path under state/ (identity), its type
#    ("text", "gzip", "zlib") and its notation over the collection's corpus.
#    A file too big to lift with the memory free now is kept in pieces cut at
#    line ends, read back joined. Files that are already in a corpus of their
#    own - the tensor books of the house, the Eye and the pictures, the KG's
#    lane and its record - and files that are not text (pictures, weights, databases,
#    arrays) are not taken here; they are counted, by kind, in what is said.
#    A file already kept, and not written since, is not kept again. A part
#    goes in only when it is smaller than its files on disk (a packed file
#    counts as its packed bytes; packed files go in parts of their own); when
#    it would not be, those files stay in their own form and are noted so,
#    not tried again until written since. After a
#    part goes in, every file in it is given back from the corpus
#    (`file_back`, packed ones packed again) and must be the very bytes of
#    the file, or the run stops and says which.
#    1651c - so the warp can run it every turn: the state is listed once,
#    each file's write time and size read from the listing itself (no file
#    looked at twice); a file found not to be text is noted (not_text.json
#    beside the parts) and not read again until written since - and one
#    whose first buffer holds a zero byte is known to be not text without
#    reading the rest; with a time to end by, once it has come no more files
#    are looked at (the part being filled is finished) and how many were
#    not is counted - the next run starts again, passing kept files at once.
#    1652c - the files found not to be text are handed on, each with its
#    collection, name, write time and size (`not_text_files`), to be kept by
#    their kind (warp2/corpus/kinds/keep.py); the work on the files is a
#    TextTurn, which the warp's own turn feeds a folder at a time as it walks
#    the state across turns (turn_walk.py, rest.py).
#  User intention (Andrew, 2026-11-13 20:49): "it should all be just the
#    files with their tags that are incredibly compressed". BUILD_LOG 1621c.
#    (2026-11-14 22:25) "a system to look for nondehydrated things and
#    dehydrates them and puts them in the smaller kg" (1651c).
# ============================================================================
"""The state's text files kept as anchors over a text corpus per collection."""
from __future__ import annotations

import io
import os
import time
import zlib
from pathlib import Path

from warp2.corpus.convert.memory import tags_that_fit
from warp2.corpus.convert.packed import GZIP, ZLIB, opened, packed
from warp2.corpus.parts import PIECE, TEXT, Parts
from warp2.corpus.varint import first, pack
from warp2.record.kept_file import read_kept, write_kept

BYTES_A_PIECE = 2.75   # Intention: measured - text of the warp averages 2.75 bytes a piece (word, space or mark)
PACKED = {".gz": GZIP, ".z": ZLIB, ".zlib": ZLIB}
OWN_FORM = "own_form.json"
NOT_TEXT = "not_text.json"   # Intention (1651c): files found not to be text, by the time each was written then


def corpora_of_their_own(state: Path) -> list:
    """Intention: folders whose files are already kept in a corpus of their own (and this corpus's own folder)."""
    state = Path(state)
    return [state / "corpus", state / "house" / "models_small" / "book", state / "models" / "eye" / "pairs_small",
            state / "store" / "media_small" / "book", state / "store" / "tags"]


def text_parts(state, collection: str) -> Parts:
    """Intention: the text corpus of one collection (the files right in state/ are the collection "_top")."""
    return Parts(Path(state) / "corpus" / "text" / ("_top" if collection == "." else collection))


def taken(path: Path, raw: bytes):
    """Intention: (type, what is kept, the length of its head) for a file kept here, or None when it is not text.
    A packed file is kept as its head's length, its head and its text (packed.py packs it back)."""
    how = PACKED.get(path.suffix.lower())
    if how is not None:
        opened_up = opened(raw, how)
        if opened_up is None:
            return None
        text, head = opened_up
        return how, pack([len(head)]) + head + text, len(head)
    if b"\x00" in raw:
        return None
    try:
        raw.decode("utf-8")
    except UnicodeDecodeError:  # fault: ok bytes that are not UTF-8 are not taken as text
        return None
    return ("text", raw, 0)


def walk(state: Path):
    """Every file under the state outside the corpora of their own: (collection, path, written, size).

    Intention (1651c): the write time and size come from the folder listing
    itself (os.scandir - on Windows the listing carries them), so a pass over
    the whole state looks at no file twice; folders and files in name order,
    each folder's files before the folders inside it.
    """
    state = Path(state)
    own = {str(each) for each in corpora_of_their_own(state)}
    waiting = [str(state)]
    while waiting:
        folder = waiting.pop()
        if folder in own:
            continue
        try:
            with os.scandir(folder) as listing:
                entries = sorted(listing, key=lambda entry: entry.name)
        except OSError:  # fault: ok a folder that cannot be listed now is passed over; the next run lists it
            continue
        inside = []
        for entry in entries:
            try:
                if entry.is_dir(follow_symlinks=False):
                    inside.append(entry.path)
                    continue
                if not entry.is_file(follow_symlinks=False):
                    continue
                seen = entry.stat(follow_symlinks=False)
            except OSError:  # fault: ok an entry gone since the listing is passed over
                continue
            path = Path(entry.path)
            rel = path.relative_to(state)
            yield (rel.parts[0] if len(rel.parts) > 1 else "."), path, seen.st_mtime_ns, seen.st_size
        waiting.extend(reversed(inside))


def keep_state_text(state, say=print, share: tuple = (0, 1), until: float | None = None) -> dict:
    """Intention: every text file of the state not yet kept (or written since), kept; what it came to. A
    collection's plain text and its packed files go in parts of their own (a packed file is measured against its
    packed bytes); a part that would not be smaller than its files on disk is not put in, and its files are noted as
    smaller in their own form (own_form.json beside the parts) so they are not tried again until written since.
    With share (i, n) (1633c), this run keeps only the files whose name falls to share i of n, with an n-th of the
    memory one run would take - n runs side by side keep the state n times as fast on a machine with free cores.
    With `until` (1651c, a time.monotonic() to end by), once it has come no more files are looked at; how many were
    not is "not_looked_at". (1652c) The work on the files is TextTurn's, which the warp's own turn also uses, a
    folder at a time (warp2/corpus/convert/rest.py)."""
    state = Path(state)
    groups: dict = {}
    mine, of = share
    for collection, path, seen, size in walk(state):
        if zlib.crc32(path.relative_to(state).as_posix().encode("utf-8")) % of == mine:
            groups.setdefault((collection, path.suffix.lower() in PACKED), []).append((path, seen, size))
    turn = TextTurn(state, say, of)
    # Intention (1629c): the collections that take the least room on disk first - the most of the state comes into
    # corpus form soonest. (1635c) Packed files after every plain one: what they hold is not what they take on disk
    # (the raw captures take 0.58 GB and open to tens of GB of text), so they go last, smallest first among them.
    for collection, is_packed in sorted(groups, key=lambda group: (group[1], _on_disk(groups[group]), group)):
        if until is not None and time.monotonic() >= until:
            turn.done["not_looked_at"] += len(groups[(collection, is_packed)])
            continue
        turn.take(collection, groups[(collection, is_packed)], until)
        turn.finish(collection)
    return turn.close()


class TextTurn:
    """Intention (1652c): the text of the state kept as its files are handed in - collection by collection, a folder
    at a time when the warp's turn walks it - each collection's plain text and its packed files filling parts of
    their own, a part put in when it is as full as the memory free allows, when its collection is finished, or when
    the turn ends. What is not text is noted and handed back, for the kinds (warp2/corpus/kinds)."""

    def __init__(self, state, say=print, of: int = 1) -> None:
        """Intention: the state, where progress is said, and how many runs share the memory (`of`)."""
        self.state = Path(state)
        self.say = say
        self.of = max(1, int(of))
        self.began = time.time()
        self.done = {"files": 0, "bytes_were": 0, "parts": [], "not_text": {}, "not_text_files": [],
                     "written_while_kept": [], "own_form_smaller": {"files": 0, "bytes": 0}, "not_looked_at": 0,
                     "seconds": 0.0}
        self.groups: dict = {}
        self.stopped = False   # Intention: whether the last `take` stopped because the time had come

    def _group(self, collection: str, is_packed: bool) -> dict:
        """Intention: the part being filled for a collection's plain or packed files, opened the first time."""
        key = (collection, is_packed)
        if key not in self.groups:
            parts = text_parts(self.state, collection)
            self.groups[key] = {"parts": parts, "own": OwnForm(parts.folder), "not_text": OwnForm(parts.folder, NOT_TEXT),
                                "group": [], "held": 0, "waiting": [], "stamps": [], "worth": 0, "found_not_text": [],
                                "fits": tags_that_fit() // self.of}
        return self.groups[key]

    def take(self, collection: str, files: list, until: float | None = None) -> list:
        """Intention: these files of one collection - (path, write time, size) - looked at in turn while the time
        lasts: text not kept (or written since) put in its part; what is not text noted and handed back as
        (collection, name, path, write time, size). When the time comes the rest are counted as not looked at, and
        `self.stopped` says so."""
        handed, self.stopped = [], False
        for at, (path, seen, size) in enumerate(files):
            if until is not None and time.monotonic() >= until:
                self.done["not_looked_at"] += len(files) - at
                self.stopped = True
                break
            self._one(collection, path, seen, size, handed)
        return handed

    def _one(self, collection: str, path: Path, seen: int, size: int, handed: list) -> None:
        """Intention: one file: passed over when kept and not written since (or its own form the smaller); noted when
        it is not text; otherwise read and put in its collection's part (in pieces when it is more than a part can
        lift), the part put in first when it would grow past what the memory free allows."""
        is_packed = path.suffix.lower() in PACKED
        g = self._group(collection, is_packed)
        name = path.relative_to(self.state).as_posix()
        if g["not_text"].still(name, path, seen):
            self._not_text(handed, collection, name, path, seen, size)
            return
        if (g["parts"].holds(name) and _not_written_since(g["parts"], name, path, seen)) or g["own"].still(name, path, seen):
            return
        # Intention (1651c): a file whose first buffer holds a zero byte is not text - known without reading the rest
        # of it (a picture or a weights file is never read whole to find that out).
        if not is_packed and _zero_in_first_buffer(path):
            g["found_not_text"].append((name, path, seen, size))
            self._not_text(handed, collection, name, path, seen, size)
            return
        try:
            stamp = path.stat().st_mtime_ns
            raw = path.read_bytes()
        except OSError:  # fault: ok a file in use or gone is left for the next run
            return
        kept = taken(path, raw)
        if kept is None:
            g["found_not_text"].append((name, path, stamp, len(raw)))
            self._not_text(handed, collection, name, path, stamp, len(raw))
            return
        kind, text, _head = kept
        for piece_name, piece in _pieces(name, text, g["fits"]):
            pieces_in = len(piece) / BYTES_A_PIECE
            if g["group"] and g["held"] + pieces_in > g["fits"]:
                self._put_in(collection, g)
            g["group"].append((piece_name, kind, piece))
            g["stamps"].append(stamp)
            g["held"] += pieces_in
            g["worth"] += len(raw) * len(piece) / max(1, len(text))
        g["waiting"].append((name, path, stamp, len(raw)))
        self.done["files"] += 1
        self.done["bytes_were"] += len(raw)

    def _not_text(self, handed: list, collection: str, name: str, path: Path, seen: int, size: int) -> None:
        """Intention: a file that is not text counted by its kind and handed back for the kinds to keep."""
        _not_text(self.done, path, size, (collection, name, seen))
        handed.append((collection, name, path, seen, int(size)))

    def _put_in(self, collection: str, g: dict) -> None:
        """Intention: the part being filled put in (or its files noted as smaller in their own form), and a new one
        begun, as big as the memory free allows now."""
        self.done["parts"].append(_kept(g["parts"], collection, g["group"], g["stamps"], self.say, self.state,
                                        g["waiting"], self.done, g["worth"], g["own"]))
        g.update(group=[], held=0, waiting=[], stamps=[], worth=0, fits=tags_that_fit() // self.of)

    def finish(self, collection: str | None = None) -> None:
        """Intention: a collection's parts put in and what was found not to be text noted (one write each); every
        collection's when none is said."""
        for key in [key for key in self.groups if collection is None or key[0] == collection]:
            g = self.groups.pop(key)
            # Intention (1651c): the files found not to be text noted once for the collection (one write, not one a file).
            if g["found_not_text"]:
                g["not_text"].note(g["found_not_text"])
            if g["group"]:
                self._put_in(key[0], g)

    def close(self) -> dict:
        """Intention: every part still being filled put in; what the turn came to."""
        self.finish()
        self.done["seconds"] = round(time.time() - self.began, 1)
        return self.done


def _on_disk(files: list) -> int:
    """Intention: the bytes a group of files took on disk when listed (1651c: from the listing, no file looked at)."""
    return sum(size for _path, _seen, size in files)


def _not_text(done: dict, path: Path, size: int, where: tuple) -> None:
    """Intention: one file that is not text counted by its kind (its suffix), and (1652c) handed on - `where` is its
    (collection, name, write time) - for the kinds to keep (warp2/corpus/kinds/keep.py)."""
    kind = path.suffix.lower() or "-"
    count, total = done["not_text"].get(kind, (0, 0))
    done["not_text"][kind] = (count + 1, total + int(size))
    collection, name, seen = where
    done["not_text_files"].append((collection, name, path, seen, int(size)))


def _zero_in_first_buffer(path: Path) -> bool:
    """Intention (1651c): whether the file's first buffer (the size Python reads in one go) holds a zero byte - then
    it is not text; False when it cannot be read now (it is then read whole, or passed over, as before)."""
    try:
        with path.open("rb") as stream:
            return b"\x00" in stream.read(io.DEFAULT_BUFFER_SIZE)
    except OSError:  # fault: ok a file that cannot be opened now is left to the whole read, which passes it over
        return False


class OwnForm:
    """Intention: the files of one collection found smaller in their own form than in a part, by the time each was
    written when found so (own_form.json beside the parts) - not tried again until written since. (1651c) The same
    for files found not to be text (not_text.json)."""

    def __init__(self, folder: Path, file_name: str = OWN_FORM) -> None:
        """Intention: the collection's parts folder (and which note it is); what it says is read once."""
        self.path = Path(folder) / file_name
        self.found = read_kept(self.path, dict)

    def still(self, name: str, path: Path, seen: int | None = None) -> bool:
        """Intention: whether this file was found so and has not been written since (`seen`: its write time from
        the listing, when known)."""
        if seen is not None:
            return self.found.get(name) == seen
        try:
            return self.found.get(name) == path.stat().st_mtime_ns
        except OSError:  # fault: ok a file that cannot be looked at now is passed over this run
            return True

    def note(self, files: list) -> None:
        """Intention: these files (name, path, stamp, size) found smaller in their own form, kept."""
        for name, _path, stamp, _size in files:
            self.found[name] = stamp
        write_kept(self.path, self.found, separators=(",", ":"))


def _not_written_since(parts: Parts, name: str, path: Path, seen: int | None = None) -> bool:
    """Intention: whether the kept file is still the file on disk - written at the very time it was when kept
    (`seen`: its write time from the listing, when known)."""
    if seen is not None:
        return parts.stamp_of(name) == seen
    try:
        return parts.stamp_of(name) == path.stat().st_mtime_ns
    except OSError:  # fault: ok a file that cannot be looked at now is left as kept
        return True


def _pieces(name: str, text: bytes, fits: int):
    """Intention: the file as one thing, or as pieces cut at line ends when it is more than one part can lift."""
    room = max(1, int(fits * BYTES_A_PIECE))
    if len(text) <= room:
        yield name, text
        return
    at, number = 0, 1
    while at < len(text):
        end = min(len(text), at + room)
        if end < len(text):
            cut = text.rfind(b"\n", at, end)
            end = cut + 1 if cut >= at else end
        yield f"{name}{PIECE}{number}", text[at:end]
        at, number = end, number + 1


def file_back(state, name: str, parts=None) -> bytes:
    """Intention: a kept file of the state (its path under state/) given back from its corpus as the very bytes it
    was - a packed file packed again the way its head says. The collection's Parts may be passed (1624c: kept open
    across many files - opened afresh for each, every part's names were read again for every file)."""
    name = Path(name).as_posix()
    if parts is None:
        parts = text_parts(state, name.split("/", 1)[0] if "/" in name else ".")
    held = parts.read(name)
    kind = parts.type_of(name)
    if kind == "text":
        return held
    length, used = first(held)
    return packed(held[used + length:], held[used:used + length], kind)


def _kept(parts: Parts, collection: str, group: list, stamps: list, say, state, waiting: list, done: dict,
          worth: float, own: OwnForm) -> dict:
    """Intention: one group of files kept as a part when that is smaller than they are on disk, said as it goes;
    then every file whose every piece is now in the corpus given back from it and set beside the file on disk - the
    very bytes, or the run stops and says which. A file written while it was being kept is noted (the next run
    keeps it again), not counted wrong. A group whose part would not be smaller stays in its own form, noted."""
    say(f"text {collection}: lifting {len(group)} files ({sum(len(t) for _n, _k, t in group):,} bytes) ...")
    # Intention (1636c): a group that holds a piece of a file kept in pieces always goes in - refusing it would
    # leave that file with a piece missing between pieces kept in other parts.
    whole_files_only = not any(PIECE in name for name, _kind, _text in group)
    measures = parts.add(group, TEXT, stamps=stamps, worth=worth if whole_files_only else None)
    measures["collection"] = collection
    if not measures["kept"]:
        own.note(waiting)
        done["own_form_smaller"]["files"] += len(waiting)
        done["own_form_smaller"]["bytes"] += int(worth)
        waiting.clear()
        say(f"text {collection}: {int(worth):,} bytes on disk would be {measures['bytes']:,} in a part - "
            f"left in their own form")
        return measures
    for name, path, stamp, _size in waiting:
        try:
            same_file = path.stat().st_mtime_ns == stamp
            on_disk = path.read_bytes() if same_file else b""
        except OSError:  # fault: ok a file gone since it was read is noted below like one written since
            same_file, on_disk = False, b""
        if not same_file:
            done["written_while_kept"].append(name)
        elif file_back(state, name, parts) != on_disk:
            raise ValueError(f"{name} did not come back from the corpus as the very bytes of the file")
    waiting.clear()
    measures["collection"] = collection
    say(f"text {collection}: {measures['part']} - {measures['hydrated']:,} bytes -> {measures['bytes']:,} bytes, "
        f"every file read back the same")
    return measures
