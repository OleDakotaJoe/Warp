# WARP2/warp2/corpus/fold_in.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/fold_in.py
#  Used by   : started by hand: python -m warp2.corpus.fold_in <state> fold <label> <folder> [seconds] [workers]
#              and: python -m warp2.corpus.fold_in <state> back <name> <file to write>; tests.
#  Uses      : warp2/corpus/kinds/{way,packs,keep}.py (the ways a file's bytes are kept, the packs they go in),
#              warp2/corpus/convert/memory.py (the memory free now), warp2/store/store.py (the KG names what was
#              kept); (stdlib) collections, hashlib, json,
#              multiprocessing, os, sys, threading, time, pathlib.
#  Description:
#    THINGS FROM OUTSIDE THE WARP FOLDED IN: KEPT SMALL, NAMED IN THE KG, PROVED, AND ONLY THEN TAKEN OUT OF WHERE
#    THEY WERE. A folder outside the warp (deep storage, the old warp, an archive) is walked; each file is read a
#    piece at a time (a piece is a share of the memory free now, so a file of any size is kept without lifting it
#    whole), each piece kept the least way that gives back its very bytes (the same ways the warp keeps its own
#    files by; a piece no way makes smaller is kept as it is), and the pieces put in the packs of the collection
#    "folded_in" with their sha256. The file is then read back from the packs alone and its sha256 must be the
#    file's; the KG is told what it is (its name, sha256, sizes, where it came from); only after both is the
#    original removed. Stopped at any point and started again, it carries on: a file already kept is not kept
#    again. Nothing here reads or writes any other collection, so the running warp is not in its way.
#    BUILD_LOG 2115g: pieces of different files are kept side by side, every way is tried only on a kind's
#    first few pieces, and how far it is is said every quarter minute. BUILD_LOG 2125d: a file whose very bytes
#    the warp already holds (folded in before, in its packs, or in the KG's evidence) is not kept again - its
#    record says where it is held, and it is proved from there before it is taken out.
#  User intention (Andrew, 2026-11-19 21:04): "if they are not in the kg they either need to be put in it or they
#    need to be stored with the internal compression system and in the kg that way. Then we need to make sure
#    everything from ... the warp2 deep storage outside the file ... get it all in the kg and get rid of it."
#    (21:07): "just make sure at the end it is all compressed in the kg". BUILD_LOG 2110f. (22:02): "we dont
#    need to deuplicate thing if it is already in the kg we dont need to repeat it in there".
# ============================================================================
"""Outside folders folded into the warp: kept small in pieces, named in the KG, proved, their originals taken out."""
from __future__ import annotations

import collections
import hashlib
import json
import multiprocessing
import os
import sys
import threading
import time
from pathlib import Path

COLLECTION = "folded_in"
WHOLE = "#whole"


class Plain:
    """Intention: way 0 - the bytes as they are, for a piece no way makes smaller (it is still held in the packs)."""

    number = 0
    name = "as it is"

    def keep(self, raw, hints: dict) -> tuple | None:
        """Intention: the bytes themselves."""
        return bytes(raw), {}

    def back(self, body) -> bytes:
        """Intention: the bytes again."""
        return bytes(body)


def known_ways() -> dict:
    """Intention: every way the warp keeps a file by, and the plain way."""
    from warp2.corpus.kinds.way import ways
    return {Plain.number: Plain(), **ways()}


def packs(state):
    """Intention: the packs everything folded in is kept in."""
    from warp2.corpus.kinds.keep import packs_of
    return packs_of(state, COLLECTION)


def piece_bytes(workers: int) -> int:
    """Intention: how much of a file is lifted at once - a share of the memory free now, so that every worker's
    piece, its kept form and the way's own working room fit together."""
    from warp2.corpus.convert.memory import free_bytes
    return max(1, free_bytes() // (max(1, workers) * len(known_ways()) * 2))


def least(task: tuple) -> tuple:
    """Intention: one piece kept its least way - (the way's number, the kept form, {way: bytes out}); each way asked
    for is tried, the smallest form that gives back the very bytes wins, and the plain way holds what none shrinks."""
    from warp2.corpus.kinds.way import kept_form
    raw, numbers = task
    ways, best, tried = known_ways(), None, {}
    for number in numbers:
        got = ways[number].keep(raw, {"recipes": [], "forms": ["webp", "rows"]})
        if got is None:
            continue
        form = kept_form(number, got[0])
        tried[number] = len(form)
        if (best is None or len(form) < len(best[1])) and bytes(ways[form[0]].back(memoryview(form)[1:])) == raw:
            best = (number, form)
    return best[0], best[1], tried


class Tried:
    """Intention: which ways are worth trying for a kind of file - all of them for as many pieces as there are ways
    (2115g: it was that many squared, and every way run on every piece kept 0.35 MB a second), then the plain way
    and the ways that have ever won for it."""

    def __init__(self) -> None:
        """Intention: nothing seen yet."""
        self.seen: dict = {}
        self.won: dict = {}

    def numbers(self, kind: str) -> list:
        """Intention: the ways to try for this kind now."""
        every = sorted(known_ways())
        if self.seen.get(kind, 0) < len(every):
            return every
        return sorted({Plain.number} | self.won.get(kind, set()))

    def note(self, kind: str, number: int) -> None:
        """Intention: one piece of this kind counted, and the way that won it."""
        self.seen[kind] = self.seen.get(kind, 0) + 1
        self.won.setdefault(kind, set()).add(number)


def _pieces(path: Path, size: int):
    """Intention: a file's bytes, a piece at a time."""
    with path.open("rb") as handle:
        for piece in iter(lambda: handle.read(size), b""):
            yield piece


class Feed:
    """Intention: the pieces of many files handed to the workers in one line, and what each piece is of kept beside
    it in the same order - so pieces of different files are kept side by side (2115g: one file at a time left every
    worker but one idle on files of a single piece). No more pieces are lifted than the workers can hold."""

    def __init__(self, files: list, tried: Tried, size: int, room: int) -> None:
        """Intention: (path, name) of each file to keep, the ways to try, the piece size, how many pieces may be
        lifted at once."""
        self.files, self.tried, self.size = files, tried, size
        self.room = threading.Semaphore(max(1, room))
        self.of: collections.deque = collections.deque()
        self.ended = False

    def end(self) -> None:
        """Intention: no more pieces are handed out - and a hand waiting for room is let go, so the workers' line
        can be closed (a run stopped for time must not wait for ever on a piece nobody will take)."""
        self.ended = True
        self.room.release()

    def tasks(self):
        """Intention: every piece of every file in turn as (bytes, ways to try); for each, what it is of is noted:
        (path, name, kind, its number, its sha256, its length, the whole file's record when it is the last)."""
        for path, name in self.files:
            kind = path.suffix.lower() or "(none)"
            whole, were, count = hashlib.sha256(), 0, 0
            total = path.stat().st_size
            handle = path.open("rb")
            try:
                while True:
                    raw = handle.read(self.size)
                    if not raw and count:
                        break
                    whole.update(raw)
                    were += len(raw)
                    last = {"sha": whole.hexdigest(), "size": were, "pieces": count + 1} if were >= total else None
                    if last is not None:
                        handle.close()     # the file is let go before its last piece is handed on: it is removed after it
                    self.room.acquire()
                    if self.ended:
                        return
                    self.of.append((path, name, kind, count, hashlib.sha256(raw).hexdigest(), len(raw), last))
                    yield raw, self.tried.numbers(kind)
                    count += 1
                    if last is not None:
                        break
            finally:
                handle.close()


def whole_record(kept, name: str, record: dict) -> None:
    """Intention: a file's record of the whole ({sha, size, pieces, kept}) put in the packs beside its pieces."""
    body = json.dumps(record, separators=(",", ":")).encode("utf-8")
    kept.add(name + WHOLE, "whole", Plain.number, bytes([Plain.number]) + body, 0, len(body), hashlib.sha256(body).hexdigest())


def record_of(kept, name: str):
    """Intention: a folded-in file's record of the whole, or None when it is not (wholly) kept."""
    if kept.entry(name + WHOLE) is None:
        return None
    return json.loads(bytes(kept.read(name + WHOLE))[1:].decode("utf-8"))


def _evidence(state, sha: str):
    """Intention: the bytes the KG's evidence holds under this sha256, or None - looked for in the state's
    evidence and the KG's own; the evidence checks the sha256 itself when it reads."""
    from warp2.record.evidence import Evidence
    from warp2.store.store import store_home
    for root in (Path(state) / "evidence", Path(store_home(state)) / "evidence"):
        held = Evidence(root)
        if held.has(sha):
            return held.get(sha)
    return None


class Held:
    """Intention (2125d - Andrew 2026-11-19 22:02: "if it is already in the kg we dont need to repeat it in
    there"): what the warp already holds, by sha256 - the files folded in before, every file the warp keeps in its
    packs, and the KG's evidence - so a file that is already held is not kept a second time."""

    def __init__(self, state, kept) -> None:
        """Intention: the sha256 of every whole file already folded in, and of every file in the warp's other
        packs (read from their indexes once)."""
        from warp2.corpus.kinds.keep import kinds_home
        from warp2.corpus.kinds.packs import Packs
        self.state = Path(state)
        self.folded = {record_of(kept, name[:-len(WHOLE)])["sha"]: name[:-len(WHOLE)]
                       for name in list(kept.index()) if name.endswith(WHOLE) and "same_as" not in record_of(kept, name[:-len(WHOLE)])}
        self.kept_elsewhere = {}
        home = kinds_home(self.state)
        for folder in sorted(p for p in home.glob("*") if p.is_dir() and p.name != COLLECTION) if home.is_dir() else []:
            for name, entry in Packs(folder).index().items():
                self.kept_elsewhere[entry["sha"]] = name

    def where(self, sha: str) -> dict:
        """Intention: {"same_as": where it is held} when the warp already holds these very bytes, else nothing."""
        if sha in self.folded:
            return {"same_as": self.folded[sha]}
        if sha in self.kept_elsewhere:
            return {"same_as": f"kept:{self.kept_elsewhere[sha]}"}
        if _evidence(self.state, sha) is not None:
            return {"same_as": f"evidence:{sha}"}
        return {}


def _same_back(state, same_as: str, kept):
    """Intention: the bytes of a file that is held somewhere else in the warp, read from there."""
    if same_as.startswith("evidence:"):
        yield bytes(_evidence(state, same_as.split(":", 1)[1]))
    elif same_as.startswith("kept:"):
        from warp2.corpus.kinds.keep import file_back
        yield file_back(state, same_as.split(":", 1)[1])
    else:
        yield from pieces_back(state, same_as, kept)


def pieces_back(state, name: str, kept=None):
    """Intention: a folded-in file given back from the packs alone, a piece at a time - each piece checked against
    the sha256 it had when kept; a piece that does not give itself back is an error, never a guess. A file that
    was already held when it came (2125d) is read from where it is held."""
    kept = kept if kept is not None else packs(state)
    record, ways = record_of(kept, name), known_ways()
    if record is None:
        raise KeyError(name)
    if "same_as" in record:
        yield from _same_back(state, record["same_as"], kept)
        return
    for at in range(record["pieces"]):
        form = kept.read(f"{name}#{at}")
        raw = bytes(ways[form[0]].back(memoryview(form)[1:]))
        if hashlib.sha256(raw).hexdigest() != kept.entry(f"{name}#{at}")["sha"]:
            raise ValueError(f"{name}: piece {at} of its kept form does not give back what was kept")
        yield raw


def proved(state, kept, name: str, record: dict) -> bool:
    """Intention: whether the packs alone give back the whole file - its size and its sha256."""
    whole, size = hashlib.sha256(), 0
    for raw in pieces_back(state, name, kept):
        whole.update(raw)
        size += len(raw)
    return size == record["size"] and whole.hexdigest() == record["sha"]


def _sha_of(path: Path, size: int) -> str:
    """Intention: a file's sha256, read a piece at a time."""
    whole = hashlib.sha256()
    for piece in _pieces(path, size):
        whole.update(piece)
    return whole.hexdigest()


def tell_kg(store, name: str, record: dict, came_from: str) -> None:
    """Intention: the KG told of one folded-in file - what it is, its sha256, how big it was and is kept, in how
    many pieces, and where it came from - so it is a thing of the KG, found and given back by its name."""
    said = {"kind": "kept_file", "sha256": record["sha"], "bytes": record["size"], "kept_bytes": record["kept"],
            "pieces": record["pieces"], "kept_in": record.get("same_as") or f"corpus/kinds/{COLLECTION}", "came_from": came_from}
    for attr, value in said.items():
        store.assert_fact(name, "has", attr=attr, value=value)


# Intention: how often a person watching is told how far it is (Andrew 2026-11-09: "things like this need visuals as
# they run").
SAY_EVERY = 15.0  # fault: ok seconds between progress lines for a person watching; nothing is decided by it


class Folding:
    """Intention: one run of folding a folder in - what it has done so far, and the taking out of each file once
    the packs alone give it back and the KG has been told."""

    def __init__(self, state, kept, store, say, total: int, many: int) -> None:
        """Intention: the state, the packs, the KG, where progress is said, and how much there is to do."""
        self.state, self.kept, self.store, self.say = state, kept, store, say
        self.total, self.many = total, many
        self.done = {"files": 0, "bytes_were": 0, "bytes_now": 0, "left": 0, "held_already": 0}
        self.held = Held(state, kept)
        self.began = self.last = time.monotonic()

    def finish(self, path: Path, name: str, record: dict) -> None:
        """Intention: one kept file proved from the packs alone, told to the KG, and only then removed from where
        it was; a file the packs do not give back stays, and is said."""
        if not proved(self.state, self.kept, name, record):
            self.say(f"  NOT TAKEN OUT - the packs do not give it back: {path}")
            self.done["left"] += 1
            return
        tell_kg(self.store, name, record, str(path))
        path.unlink(missing_ok=True)   # gone already (another run took it out a moment ago): it is out, and kept
        self.done["files"] += 1
        self.done["bytes_were"] += record["size"]
        self.done["bytes_now"] += record["kept"]
        self.done["held_already"] += int("same_as" in record)
        if "same_as" not in record:
            self.held.folded[record["sha"]] = name

    def already(self, path: Path, name: str, sha: str) -> bool:
        """Intention (2125d): a file the warp already holds is not kept again - its record says where it is held,
        it is proved from there, the KG is told, and it is taken out; whether it was."""
        where = self.held.where(sha)
        if not where:
            return False
        record = dict(where, sha=sha, size=path.stat().st_size, pieces=0, kept=0)
        whole_record(self.kept, name, record)
        self.finish(path, name, record)
        return True

    def progress(self, in_hand: int = 0) -> None:
        """Intention: how far it is, said when long enough has passed since it was last said."""
        if time.monotonic() - self.last < SAY_EVERY:
            return
        self.last = time.monotonic()
        done, were = self.done, self.done["bytes_were"] + in_hand
        rate = were / max(time.monotonic() - self.began, 1e-9)
        self.say(f"  {done['files']:,} of {self.many:,} files, {were / 2 ** 30:.2f} of {self.total / 2 ** 30:.2f} GB in, "
                 f"kept at {100 * done['bytes_now'] / max(1, done['bytes_were']):.1f}%, {rate / 2 ** 20:.1f} MB a second, "
                 f"about {(self.total - were) / max(rate, 1) / 60:.0f} minutes left")


def fold(state, label: str, source, say=print, seconds: float | None = None, workers: int = 1, size: int | None = None) -> dict:
    """Intention: every file under `source` folded in under folded_in/<label>/ - kept, proved from the packs alone,
    told to the KG, and only then its original removed; {"files", "bytes_were", "bytes_now", "left"} for what this
    run did. A file already kept (a run stopped part way) is proved and taken out without being kept again."""
    from warp2.store.store import Store, store_home
    state, source = Path(state), Path(source)
    kept, tried = packs(state), Tried()
    size = int(size) if size else piece_bytes(workers)
    files = sorted(p for p in source.rglob("*") if p.is_file())
    total = sum(p.stat().st_size for p in files)
    say(f"{len(files):,} files, {total / 2 ** 30:.2f} GB to fold in from {source}; pieces of {size / 2 ** 20:.0f} MB, {workers} at a time")
    store = Store(store_home(state))
    run = Folding(state, kept, store, say, total, len(files))
    over = (lambda: False) if seconds is None else (lambda: time.monotonic() - run.began >= seconds)
    pool = multiprocessing.Pool(workers) if workers > 1 else None
    feed = Feed([], tried, size, workers * 2)
    try:
        waiting, twins, first = [], [], set()
        for path in files:
            name = f"{COLLECTION}/{label}/{path.relative_to(source).as_posix()}"
            if over():
                waiting.append((path, name))
                continue
            record, sha = record_of(kept, name), _sha_of(path, size)
            if record is not None and record["sha"] == sha:
                run.finish(path, name, record)
            elif sha in first:
                twins.append((path, name, sha))    # the same bytes as a file about to be kept: taken out after it is
            elif not run.already(path, name, sha):
                waiting.append((path, name))
                first.add(sha)
            run.progress()
        feed.files, in_hand, now = waiting, 0, {}
        tasks = feed.tasks()
        for number, form, _sizes in (() if over() else (map(least, tasks) if pool is None else pool.imap(least, tasks))):
            path, name, kind, count, sha, length, last = feed.of.popleft()
            kept.add(f"{name}#{count}", kind, number, form, 0, length, sha)
            tried.note(kind, number)
            now[name] = now.get(name, 0) + len(form)
            in_hand += length
            if last is not None:
                record = dict(last, kept=now.pop(name))
                whole_record(kept, name, record)
                run.finish(path, name, record)
                in_hand -= record["size"]
            feed.room.release()
            run.progress(in_hand)
            if over():
                break
        for path, name, sha in twins:
            run.already(path, name, sha)
    finally:
        feed.end()
        if pool is not None:
            pool.terminate()
            pool.join()
        kept.close()
        store.close()
    for folder in sorted((p for p in source.rglob("*") if p.is_dir()), reverse=True):
        if not any(folder.iterdir()):
            folder.rmdir()
    done = run.done
    done["left"] = sum(1 for p in source.rglob("*") if p.is_file())
    say(f"done: {done['files']:,} files folded in and taken out ({done['held_already']:,} of them the warp already held, "
        f"not kept again), {done['bytes_were'] / 2 ** 30:.2f} GB kept as "
        f"{done['bytes_now'] / 2 ** 30:.2f} GB ({100 * done['bytes_now'] / max(1, done['bytes_were']):.1f}%); {done['left']:,} left")
    return done


def back(state, name: str, to) -> int:
    """Intention: a folded-in file written out again as the very file it was; how many bytes."""
    written = 0
    with Path(to).open("wb") as out:
        for raw in pieces_back(state, name):
            written += out.write(raw)
    return written


def main(args: list) -> None:
    """Intention: started by hand - `<state> fold <label> <folder> [seconds] [workers]` or
    `<state> back <name> <file to write>`; each line said as soon as it happens."""
    state = Path(args[0])
    if args[1] == "back":
        print(f"{back(state, args[2], args[3]):,} bytes written to {args[3]}", flush=True)
        return
    seconds = float(args[4]) if len(args) > 4 else None
    workers = int(args[5]) if len(args) > 5 else max(1, (os.cpu_count() or 2) // 2)
    fold(state, args[2], args[3], say=lambda line: print(time.strftime("%H:%M:%S"), line, flush=True), seconds=seconds, workers=workers)


if __name__ == "__main__":
    main(sys.argv[1:])
