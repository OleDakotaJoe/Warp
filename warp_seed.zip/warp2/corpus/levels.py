# WARP3/warp2/corpus/levels.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/levels.py
#  Used by   : warp2/corpus/corpus.py, warp2/corpus/part.py,
#              warp2/corpus/columns.py (asks for recipes too); warp2/corpus/tests/.
#  Uses      : warp2/corpus/{varint,grammar,level,expand,smooth}.py;
#              warp2/equation_book/keep.py (keep_values, values_back - the
#              fourth way); warp2/record/swallowed.py (noted); numpy.
#  Description:
#    THE CORPUS KEPT AS A CORPUS OF ITS OWN, UNTIL NOTHING GAINS. Any list
#    of notations (lists of numbers) is kept one of these ways, whichever is
#    smallest, measured:
#      plain  - how many, each one's length, then every number;
#      smooth - the same, every number coded to its information with a
#               model of how often each stands (smooth.py), the model kept
#               the same way;
#      lifted - as a level (level.py): its band table, its base values
#               (each band's values as steps from the one before), its
#               higher tags' parts, and the notations in tag numbers;
#      book   - (when the caller asks for recipes) how many and each one's
#               length, then every number as the equation book's cheapest
#               recipe (warp2/equation_book/, BUILD_LOG 1647c) - a run, each
#               from the one before, a shared factor, end transforms...
#               Asked for by columns (the KG's facts, the connection web),
#               where numbers follow rules (step 1 measured times 17 percent,
#               confidences 31 percent smaller); not inside a level's own
#               parts, so the corpus's other work keeps its pace.
#    A way is tried only when it could come out smaller: smooth when the
#    information plus its lanes' states is under the plain bytes, lifted
#    when some pair repeats or numbering the values by use is smaller.
#    The base values and the higher tags' parts of a lifted level are lists
#    of notations too, so they are kept the same way - lifted again if that
#    makes them smaller, and so on, level after level, until a level no
#    longer gains. Each part only ever goes to a level when it holds fewer
#    numbers than the level above it, so it always ends.
#  User intention (Andrew, 2026-11-13 20:56): "The corpus should also be
#    keept like this with its own corpus and that should continue in that
#    pattern until it no longer gives gains." BUILD_LOG 1621c. (2026-11-14
#    15:34-17:08) numbers kept as the equations that make them - "The only
#    things that matter are storage space and time to generate from
#    storage" (claude/equation_book_plan_2026_11_14.md, step 3).
# ============================================================================
"""Lists of notations kept plain or as a level over its own corpus - whichever is smaller."""
from __future__ import annotations

import math

import numpy as np

from warp2.corpus import smooth
from warp2.corpus.expand import expand
from warp2.corpus.grammar import cut_apart, laid_out
from warp2.corpus.level import kinds_of, make
from warp2.corpus.varint import first, pack, size, unpack
from warp2.equation_book.keep import keep_values, values_back
from warp2.record.swallowed import noted

PLAIN, LIFTED, SMOOTH, BOOK = 0, 1, 2, 3


def keep(notations, recipes: bool = False) -> bytes:
    """The notations as bytes, the smallest of the ways.

    Intention: `recipes` adds the equation book's way, for callers whose
    numbers follow rules (columns); it is never asked for inside a level's
    own parts, so those keep their pace.
    """
    notations = [np.asarray(each, dtype=np.int64) for each in notations]
    plain = _plain(notations)
    held = sum(each.size for each in notations)
    if held < 4:
        return plain
    numbers = np.concatenate(notations)
    ways = [plain]
    if _smooth_could_pay(numbers, len(plain)):
        ways.append(_smooth(notations, held))
    if _lifting_could_pay(notations, numbers):
        ways.append(_lifted(notations, held))
    # Intention: with a negative number the book is always tried - it is the one way here that gives negatives back.
    if recipes and (numbers.min() < 0 or _book_could_pay(numbers)):
        ways.append(_book(notations, numbers))
    ways = sorted((way for way in ways if way is not None), key=len)
    if numbers.min() >= 0:
        return ways[0]
    # Intention (found 2026-11-14, claude/equation_book_plan_2026_11_14.md): the plain, smooth and lifted ways do not
    # give back negative numbers, and nothing said so - callers fold their numbers first, so nothing kept was ever
    # wrong, but the trap was open. With a negative number, the smallest way that gives every number back is kept
    # (the equation book's does, when recipes are asked for); when none does, it is an error, never a wrong answer.
    for way in ways:
        if _gives_back(way, notations):
            return way
    raise ValueError("these numbers hold negatives no way here gives back - fold them first, or ask for recipes")


def _gives_back(raw: bytes, notations: list) -> bool:
    """Intention: whether these bytes read back as exactly these notations."""
    try:
        back = unkeep(raw)
    except (ValueError, IndexError, OverflowError) as exc:
        noted("warp2/corpus/levels.py:_gives_back", exc)
        return False
    return len(back) == len(notations) and all(np.array_equal(a, b) for a, b in zip(back, notations))


def _book_could_pay(numbers: np.ndarray) -> bool:
    """Whether the equation book's whole search is worth its time here.

    Intention: the search costs about a minute for two million numbers that
    follow no rule (measured on the KG's first facts block, 2026-11-14), and
    a rule shows in a column's start. So the book is tried on the first
    square root of the numbers - a share that shrinks as the list grows, set
    by the list, not by a number - and the whole search runs only when that
    start comes out smaller as a recipe than today's ways keep it.
    """
    head = numbers[:max(1, math.isqrt(numbers.size))]
    return len(keep_values(head)) < len(keep([head]))


def _book(notations: list, numbers: np.ndarray) -> bytes:
    """Intention: how many and each one's length, then every number as the equation book's cheapest recipe (read
    back and checked by the book before it is given)."""
    sizes = pack([len(notations)] + [each.size for each in notations])
    return bytes([BOOK]) + _sized(sizes) + _sized(keep_values(numbers))


def _smooth_could_pay(numbers: np.ndarray, plain: int) -> bool:
    """Intention: whether coding to the information could come out under the plain bytes - the information itself
    (order 0) and the lanes' closing states are the least it can take, worked out before trying."""
    _tags, counts = np.unique(numbers, return_counts=True)
    information = float(-(counts * np.log2(counts / counts.sum())).sum()) / 8
    return information + 4 * smooth.lanes_for(numbers.size) < plain


def _lifting_could_pay(notations: list, numbers: np.ndarray) -> bool:
    """Intention: whether a level could come out smaller - only when some pair of tags side by side repeats, or
    when numbering the values by how often they are used takes fewer bytes than the values themselves."""
    firsts = np.concatenate([each[:-1] for each in notations])
    seconds = np.concatenate([each[1:] for each in notations])
    if firsts.size and np.unique(firsts * np.int64(1 << 31) + seconds).size < firsts.size:
        return True
    distinct = np.unique(numbers)
    return size(np.searchsorted(distinct, numbers)) + size(np.diff(distinct, prepend=0)) < size(numbers)


def unkeep(raw: bytes) -> list:
    """Intention: the notations back from what `keep` gave."""
    return _read(memoryview(raw), 0)[0]


def _plain(notations: list) -> bytes:
    """Intention: how many, each one's length, then every number."""
    sizes = [each.size for each in notations]
    body = np.concatenate([np.asarray([len(notations)] + sizes, dtype=np.int64)] + notations)
    return bytes([PLAIN]) + _sized(pack(body))


def _smooth(notations: list, held: int) -> bytes:
    """Intention: every number coded to its information with a model of how often each stands (smooth.py); the
    model kept the same way as anything else (smaller than what it models, so this ends)."""
    numbers = np.concatenate(notations)
    tags, how_often = np.unique(numbers, return_counts=True)
    model = smooth.Model.of(tags, how_often)
    written = model.written()
    inner = keep(written) if sum(each.size for each in written) < held else _plain(written)
    sizes = pack([len(notations)] + [each.size for each in notations])
    return bytes([SMOOTH]) + _sized(sizes) + _sized(inner) + _sized(smooth.encode(numbers, model))


def _sized(raw: bytes) -> bytes:
    """Intention: bytes with their length before them, so a reader knows where they end."""
    return pack([len(raw)]) + raw


def _lifted(notations: list, held: int):
    """Intention: the notations as a level, its parts kept the same way; None when it cannot be smaller."""
    laid, _starts = laid_out(notations)
    level = make(laid)
    base_counts = level.bands[:, 0]
    ends = np.cumsum(base_counts)
    values = [level.values[end - count:end] for count, end in zip(base_counts, ends)]
    steps = [np.diff(each, prepend=0) if each.size else each for each in values]
    parts = [level.flat[level.offsets[i]:level.offsets[i + 1]] for i in range(level.offsets.size - 1)]
    inner_steps = keep(steps) if sum(each.size for each in steps) < held else _plain(steps)
    inner_parts = keep(parts) if level.flat.size < held else _plain(parts)
    written = _plain(cut_apart(level.laid))
    head = pack(np.concatenate([[level.bands.shape[0]], level.bands.reshape(-1)]))
    return bytes([LIFTED]) + _sized(head) + _sized(inner_steps) + _sized(inner_parts) + _sized(written)


def _take(raw: memoryview, at: int) -> tuple:
    """Intention: one length-led piece - (its bytes, the place after it)."""
    length, used = first(raw[at:at + 10])
    return raw[at + used:at + used + length], at + used + length


def _read(raw: memoryview, at: int) -> tuple:
    """Intention: one kept list of notations from this place - (the notations, the place after)."""
    kind = raw[at]
    if kind == PLAIN:
        body, after = _take(raw, at + 1)
        numbers = unpack(bytes(body))
        count = int(numbers[0])
        sizes = numbers[1:1 + count]
        flat = numbers[1 + count:]
        ends = np.cumsum(sizes)
        return [flat[end - size:end] for size, end in zip(sizes, ends)], after
    if kind == SMOOTH:
        sizes, at = _take(raw, at + 1)
        inner, at = _take(raw, at)
        coded, after = _take(raw, at)
        sizes = unpack(bytes(sizes))
        numbers = smooth.decode(coded, smooth.Model.read(_read(inner, 0)[0]))
        ends = np.cumsum(sizes[1:])
        return [numbers[end - size:end] for size, end in zip(sizes[1:], ends)], after
    if kind == BOOK:
        sizes, at = _take(raw, at + 1)
        kept, after = _take(raw, at)
        sizes = unpack(bytes(sizes))
        numbers = values_back(bytes(kept))
        ends = np.cumsum(sizes[1:])
        return [numbers[end - size:end] for size, end in zip(sizes[1:], ends)], after
    head, at = _take(raw, at + 1)
    inner_steps, at = _take(raw, at)
    inner_parts, at = _take(raw, at)
    written, after = _take(raw, at)
    head_numbers = unpack(bytes(head))
    bands = head_numbers[1:].reshape(-1, 2)
    steps = _read(inner_steps, 0)[0]
    parts = _read(inner_parts, 0)[0]
    notations = _read(written, 0)[0]
    values = np.concatenate([np.cumsum(each) for each in steps]) if steps else np.zeros(0, dtype=np.int64)
    widths = np.asarray([each.size for each in parts], dtype=np.int64)
    offsets = np.concatenate([[0], np.cumsum(widths)]).astype(np.int64)
    flat = np.concatenate(parts) if parts else np.zeros(0, dtype=np.int64)
    higher, row = kinds_of(bands)
    laid, _starts = laid_out(notations)
    opened = expand(laid, higher, offsets, flat, row)
    back = opened.copy()
    back[opened >= 0] = values[row[opened[opened >= 0]]]
    return cut_apart(back), after
