# WARP2/warp2/corpus/tests/test_outside_folders_are_folded_in_and_given_back.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/test_outside_folders_are_folded_in_and_given_back.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/fold_in.py, warp2/store/store.py.
#  Description:
#    A folder outside the warp is folded in: every file kept small in pieces,
#    named in the KG, given back from the packs alone as the very bytes, and
#    only then gone from where it was. A file no way makes smaller is still
#    held; a run stopped part way carries on; a kept form that has been
#    spoiled is never taken for the file.
#  User intention (Andrew, 2026-11-19 21:07): "just make sure at the end it is
#    all compressed in the kg". BUILD_LOG 2110f.
# ============================================================================
"""Outside folders are kept small in the warp, named in the KG, proved, and only then removed."""
from __future__ import annotations

import os

import pytest

from warp2.corpus import fold_in
from warp2.store.store import Store, store_home


def _outside(tmp_path) -> dict:
    """Intention: a folder outside the state with text, bytes nothing shrinks, an empty file and a file in a folder."""
    source = tmp_path / "outside"
    (source / "deep" / "er").mkdir(parents=True)
    files = {"notes.txt": b"the same line again and again\n" * 4000, "noise.bin": os.urandom(70000), "empty.dat": b"",
             "deep/er/numbers.json": ("[" + ",".join(str(k * 7) for k in range(30000)) + "]").encode()}
    for name, raw in files.items():
        (source / name).write_bytes(raw)
    return files


def test_a_folder_is_kept_small_named_proved_and_only_then_taken_out(tmp_path):
    files, state, said = _outside(tmp_path), tmp_path / "state", []
    done = fold_in.fold(state, "old", tmp_path / "outside", say=said.append, size=16384)     # small pieces: many a file
    assert done["files"] == 4 and done["left"] == 0 and done["bytes_now"] < done["bytes_were"]
    assert not (tmp_path / "outside" / "notes.txt").exists() and not (tmp_path / "outside" / "deep").exists()
    for name, raw in files.items():
        assert b"".join(fold_in.pieces_back(state, f"folded_in/old/{name}")) == raw
    assert fold_in.back(state, "folded_in/old/noise.bin", tmp_path / "again.bin") == 70000
    assert (tmp_path / "again.bin").read_bytes() == files["noise.bin"]                       # held, though nothing shrinks it
    store = Store(store_home(state))
    try:
        told = {str(f["attr"]): f["value"] for f in store.current(subject="folded_in/old/notes.txt") if f.get("attr")}
    finally:
        store.close()
    assert told["kind"] == "kept_file" and int(told["bytes"]) == len(files["notes.txt"]) and int(told["pieces"]) == 8
    assert int(told["kept_bytes"]) < int(told["bytes"]) // 10 and "said" not in told


def test_a_stopped_run_carries_on_and_a_spoiled_form_is_never_taken_for_the_file(tmp_path):
    files, state = _outside(tmp_path), tmp_path / "state"
    first = fold_in.fold(state, "old", tmp_path / "outside", say=lambda _t: None, seconds=0.0)
    assert first["files"] == 0 and first["left"] == 4 and (tmp_path / "outside" / "notes.txt").exists()   # nothing lost
    part = fold_in.fold(state, "old", tmp_path / "outside", say=lambda _t: None, workers=2, size=4096, seconds=1e-9)
    assert part["left"] >= 3                                                                 # stopped with pieces in hand
    again = fold_in.fold(state, "old", tmp_path / "outside", say=lambda _t: None, workers=2, size=16384)   # side by side
    assert again["files"] + part["files"] == 4 and again["left"] == 0
    for name, raw in files.items():
        assert b"".join(fold_in.pieces_back(state, f"folded_in/old/{name}")) == raw
    pack = max((state / "corpus" / "kinds" / "folded_in").glob("pack-*.bin"), key=lambda p: p.stat().st_size)
    spoiled = bytearray(pack.read_bytes())
    for at in range(len(spoiled) // 3, len(spoiled) // 3 + 40):
        spoiled[at] ^= 0xFF
    pack.write_bytes(bytes(spoiled))
    with pytest.raises(Exception):
        for name in files:
            b"".join(fold_in.pieces_back(state, f"folded_in/old/{name}"))


def test_what_the_warp_already_holds_is_not_kept_again(tmp_path):
    """Intention (2125d): the same bytes under another name, and bytes the KG's evidence already holds, are taken
    out without being kept a second time - and are still given back by their own names."""
    state, source = tmp_path / "state", tmp_path / "outside"
    source.mkdir()
    twin, known = b"a file that comes twice\n" * 3000, b"words the KG already holds as evidence\n" * 500
    store = Store(store_home(state))
    try:
        store.evidence.put(known)
    finally:
        store.close()
    (source / "a.txt").write_bytes(twin)
    (source / "b_copy.txt").write_bytes(twin)
    (source / "known.txt").write_bytes(known)
    done = fold_in.fold(state, "old", source, say=lambda _t: None)
    assert done["files"] == 3 and done["held_already"] == 2 and done["left"] == 0            # the twin, and the evidence one
    pack = sum(p.stat().st_size for p in (state / "corpus" / "kinds" / "folded_in").glob("pack-*.bin"))
    (source / "c_again.txt").write_bytes(twin)                                                  # a later run: held from before
    (source / "b_copy.txt").write_bytes(twin)
    again = fold_in.fold(state, "later", source, say=lambda _t: None)
    assert again["held_already"] == 2 and again["bytes_now"] == 0
    grown = sum(p.stat().st_size for p in (state / "corpus" / "kinds" / "folded_in").glob("pack-*.bin")) - pack
    assert grown < len(twin) // 20                                                               # only the small records
    for name, raw in (("old/a.txt", twin), ("old/b_copy.txt", twin), ("old/known.txt", known), ("later/c_again.txt", twin)):
        assert b"".join(fold_in.pieces_back(state, f"folded_in/{name}")) == raw
