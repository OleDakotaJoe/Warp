# WARP3/warp2/corpus/tests/test_outside_folders_come_in_through_the_warps_own_keeper.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_outside_folders_come_in_through_the_warps_own_keeper.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/{outside,state_text}.py, warp2/store/store.py.
#  Description:
#    A folder outside the state is kept by the warp's own text keeper as a
#    collection of the text corpus, given back as its very bytes, named in the
#    KG, and only then removed. What is not text stays where it is. Nothing is
#    zipped: the collection is read back by the same door as every other.
#  User intention (Andrew, 2026-11-19 23:35): "It should be using the same
#    system everything else does the same exact system". BUILD_LOG 0220b.
# ============================================================================
"""Outside folders come in through the warp's own keeper of text."""
from __future__ import annotations

import os

from warp2.corpus.convert import outside
from warp2.corpus.convert.state_text import file_back, text_parts
from warp2.corpus.kinds.keep import file_back as kept_back
from warp2.store.store import Store, store_home


def test_a_folder_outside_is_kept_by_the_warps_keeper_proved_named_and_removed(tmp_path):
    state, source = tmp_path / "state", tmp_path / "deep"
    (source / "run" / "blocks").mkdir(parents=True)
    files = {"notes.txt": b"the same line again and again\n" * 4000,
             "run/log.jsonl": b"".join(b'{"n": %d, "what": "a line of the run"}\n' % k for k in range(5000)),
             "run/blocks/block.json": ("[" + ",".join(str(k * 7) for k in range(30000)) + "]").encode()}
    for name, raw in files.items():
        (source / name).write_bytes(raw)
    weights = os.urandom(5000) + b"\x00" * 10
    (source / "weights.bin").write_bytes(weights)
    (source / "run" / "raw_capture.dehydrated.jsonl").write_bytes(b'{"t": [3, 9, 27]}\n' * 900)   # dehydrated already
    (source / "dehydrated").mkdir()
    (source / "dehydrated" / "lane.jsonl").write_bytes(b'{"t": [1, 2, 3]}\n' * 900)
    done = outside.bring_in(state, "deep_storage", source, say=lambda _line: None)
    # Intention (2026-11-21, one door for bringing things in): what is not text comes in too - through the keeper of
    # what is not text; noise no way keeps smaller is kept as it is.
    assert done["files"] == 4 and done["left"] == 2 and done["not_text"] == 1 and done["already_dehydrated"] == 2
    assert done["kept_not_text"] == 1
    assert (source / "run" / "raw_capture.dehydrated.jsonl").exists() and (source / "dehydrated" / "lane.jsonl").exists()
    assert not (source / "weights.bin").exists() and not (source / "run" / "blocks").exists()
    assert kept_back(state, "deep_storage/weights.bin") == weights
    assert done["corpus_bytes"] < sum(len(raw) for raw in files.values())
    for name, raw in files.items():
        assert file_back(state, f"deep_storage/{name}") == raw                             # the same door as every file
    assert sorted(text_parts(state, "deep_storage").where()) == sorted(f"deep_storage/{name}" for name in files)
    store = Store(store_home(state))
    try:
        told = {str(f["attr"]): f["value"] for f in store.current(subject="deep_storage/run/log.jsonl") if f.get("attr")}
    finally:
        store.close()
    assert told["kind"] == "kept_file" and int(told["bytes"]) == len(files["run/log.jsonl"]) and told["kept_in"] == "corpus/text/deep_storage"
    again = outside.bring_in(state, "deep_storage", source, say=lambda _line: None)       # nothing new: nothing done
    assert again["files"] == 0 and again["left"] == 2
