# WARP3/warp2/corpus/tests/test_the_record_leaves_only_its_corpus_in_the_warp.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_the_record_leaves_only_its_corpus_in_the_warp.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/kg.py (keep_kg, kg_parts);
#              warp2/tags/dehydrated/small_to_deep.py (send_small, free_small);
#              warp2/tags/lane.py (TagLane); warp2/tags/dehydrated/whole_lane.py
#              (WholeLane); warp2/record/journal.py.
#  Description:
#    The record's segments wait in their own small files until they fill a
#    part (what one lift can hold with the memory free now), then go into the
#    KG's corpus together; a segment held the same in the corpus has its own
#    small file taken out (1653c: with no copy - the corpus gives back its
#    very bytes), and the lane reads every entry the same from the corpus;
#    a file that the corpus does not give back the same stays; small files
#    sent to deep storage before are taken out of it once the corpus gives
#    each back the same.
#  User intention (Andrew, 2026-11-12 09:38): "The small form of the kg should
#    be the only thing there"; 2026-11-13 20:35: "everything needs to be in
#    and run from a fully dehydrated form." BUILD_LOG 1622c. 2026-11-15 00:56:
#    "if we have the old files ... in exact forms we can free up at least disk
#    space removing the originals" (1653c).
# ============================================================================
"""Intention: the corpus becomes the record's only small form, each file taken out once the corpus gives it back."""
import json

from warp2.corpus.convert import kg as kg_convert
from warp2.corpus.convert.kg import keep_kg, kg_parts
from warp2.record import journal
from warp2.tags.dehydrated.small_to_deep import FOLDER, free_small, send_small
from warp2.tags.dehydrated.whole_lane import WholeLane
from warp2.tags.lane import TagLane


def _record(tmp_path, monkeypatch):
    """Intention: a lane of 300 entries whose closed segments are written small against web tags."""
    monkeypatch.setattr(journal, "ROTATE_AFTER_BYTES", 20000)
    tags = tmp_path / "state" / "store" / "tags"
    lane = TagLane(tags / "tags.jsonl")
    for number in range(300):
        lane.append({"fact": "assert", "row": {"subject": f"part_{number % 7}", "relation": "", "object": "",
                                               "attr": "status", "value": f"built {number % 3}", "confidence": 900,
                                               "valid_from": "2026-11-10T04:53:11.121221+00:00", "run": "web",
                                               "stamp": "6cfebf804e787d7f", "proof": 4}})
    assert WholeLane(tags, say=lambda text: None, form=2).run(seconds=600.0)["done"] >= 2
    return tags, tags / "dehydrated" / "web_tagged"


def test_segments_wait_until_they_fill_a_part(tmp_path, monkeypatch):
    """Intention: with room for far more than the waiting segments nothing is lifted yet; with less, they go in."""
    _tags, home = _record(tmp_path, monkeypatch)
    monkeypatch.setattr(kg_convert, "tags_that_fit", lambda: 10 ** 9)
    waited = keep_kg(home, say=lambda line: None, every=False)
    assert waited["segments"] == 0 and waited["waiting"] >= 2 and not kg_parts(home).files()
    monkeypatch.setattr(kg_convert, "tags_that_fit", lambda: 10)
    kept = keep_kg(home, say=lambda line: None, every=False)
    assert kept["segments"] == waited["waiting"] and kg_parts(home).files()


def test_the_small_files_are_taken_out_and_the_lane_reads_the_same(tmp_path, monkeypatch):
    """Intention: once held the same in the corpus, each small file is taken out with no copy anywhere; the lane gives
    every entry the same."""
    tags, home = _record(tmp_path, monkeypatch)
    before = list(TagLane(tags / "tags.jsonl").entries())
    record = json.loads((home / "done.json").read_text(encoding="utf-8"))
    assert send_small(home, tmp_path / "deep")["left"] == 0   # nothing is in the corpus yet, so nothing is waiting
    keep_kg(home, say=lambda line: None)
    sent = send_small(home, None)
    assert sent == {"sent": len(record), "left": 0, "why": ""}
    assert not list(home.glob("entries-*.bin")) and not (tmp_path / "deep").exists()
    assert list(TagLane(tags / "tags.jsonl").entries()) == before


def test_small_files_sent_to_deep_storage_before_are_taken_out_of_it_once_the_corpus_gives_them_back(tmp_path,
                                                                                                    monkeypatch):
    """Intention: what an earlier turn copied to deep storage freed - each file only once the corpus gives it back."""
    tags, home = _record(tmp_path, monkeypatch)
    before = list(TagLane(tags / "tags.jsonl").entries())
    keep_kg(home, say=lambda line: None)
    deep = tmp_path / "deep" / FOLDER
    deep.mkdir(parents=True)
    files = sorted(home.glob("entries-*.bin"))
    for path in files:
        (deep / path.name).write_bytes(path.read_bytes())
    (deep / files[0].name).write_bytes(files[0].read_bytes() + b"\x01")
    freed = free_small(home, tmp_path / "deep")
    assert freed["removed"] == len(files) - 1 and files[0].name in freed["why"]
    assert [path.name for path in deep.glob("*.bin")] == [files[0].name]
    assert list(TagLane(tags / "tags.jsonl").entries()) == before


def test_a_file_the_corpus_does_not_give_back_the_same_stays(tmp_path, monkeypatch):
    """Intention: a small file that differs from its anchor in the corpus is not sent, and the result says which."""
    _tags, home = _record(tmp_path, monkeypatch)
    keep_kg(home, say=lambda line: None)
    first_file = sorted(home.glob("entries-*.bin"))[0]
    first_file.write_bytes(first_file.read_bytes() + b"\x01")
    sent = send_small(home, tmp_path / "deep")
    assert sent["sent"] == 0 and first_file.name in sent["why"] and first_file.exists()
