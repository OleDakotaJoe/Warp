# WARP3/warp2/corpus/tests/test_numbers_that_follow_a_rule_are_kept_as_their_recipe.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_numbers_that_follow_a_rule_are_kept_as_their_recipe.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/levels.py (keep, unkeep, BOOK), warp2/corpus/columns.py
#              (pack_block, Columns); numpy.
#  Description:
#    The equation book as the corpus's fourth way: numbers that follow a rule
#    (ids in a run, times one after another, a shared factor) are kept as
#    their recipe when that is smallest and come back exactly; numbers with
#    no rule keep today's way; nothing is asked of the book unless the caller
#    asks for recipes; many notations keep their lengths; negative and edge
#    numbers come back; a block of columns uses the book and reads back.
#  User intention (Andrew, 2026-11-14 15:34-17:08): numbers kept as the
#    equations that make them; "The only things that matter are storage space
#    and time to generate from storage." Plan step 3 (BUILD_LOG 1650c).
# ============================================================================
"""Intention: a column of numbers that follows a rule is kept as its recipe, and comes back exactly."""
import numpy as np

from warp2.corpus.columns import Columns, pack_block
from warp2.corpus.levels import BOOK, keep, unkeep


def _back(raw: bytes) -> list:
    return [np.asarray(each) for each in unkeep(raw)]


def test_ids_in_a_run_are_kept_as_the_run_and_come_back_exactly():
    ids = np.arange(5, 200_005, dtype=np.int64)
    without = keep([ids])
    with_recipes = keep([ids], recipes=True)
    assert with_recipes[0] == BOOK
    assert len(with_recipes) < len(without) // 100
    assert np.array_equal(_back(with_recipes)[0], ids)


def test_times_one_after_another_are_kept_smaller_and_come_back_exactly():
    rng = np.random.default_rng(1)
    times = np.cumsum(rng.integers(900_000, 1_100_000, 50_000)).astype(np.int64)
    with_recipes = keep([times], recipes=True)
    assert len(with_recipes) < len(keep([times]))
    assert np.array_equal(_back(with_recipes)[0], times)


def test_numbers_with_no_rule_keep_today_s_way():
    rng = np.random.default_rng(2)
    noise = rng.integers(0, 7, 20_000).astype(np.int64)
    assert keep([noise], recipes=True) == keep([noise])


def test_the_book_is_never_asked_unless_the_caller_asks_for_recipes():
    ids = np.arange(0, 10_000, dtype=np.int64)
    assert keep([ids])[0] != BOOK


def test_many_notations_keep_their_lengths_and_edge_numbers_come_back():
    edges = np.array([-5, 3, -2 ** 63, 2 ** 63 - 1, 0, -1, 7, 7, 7, 7], dtype=np.int64)
    runs = [np.arange(i, i + 400, dtype=np.int64) for i in range(0, 4000, 400)]
    for notations in ([edges], runs, runs + [edges, np.zeros(0, dtype=np.int64)]):
        back = _back(keep(notations, recipes=True))
        assert len(back) == len(notations)
        assert all(np.array_equal(a, b) for a, b in zip(back, notations))


def test_negative_numbers_no_way_gives_back_are_an_error_never_a_wrong_answer():
    # Found 2026-11-14: the plain, smooth and lifted ways do not give back negative numbers; it was silent.
    edges = np.array([-5, 3, -2 ** 63, 2 ** 63 - 1, 0, -1, 7, 7, 7, 7], dtype=np.int64)
    refused = False
    try:
        keep([edges])
    except ValueError:
        refused = True
    assert refused
    assert np.array_equal(_back(keep([edges], recipes=True))[0], edges)
    small = np.array([-5, 3, -2, 0, -1, 7, 7, 7, 7], dtype=np.int64)
    assert np.array_equal(_back(keep([small], recipes=True))[0], small)


def test_a_block_of_columns_keeps_its_ruled_columns_as_recipes_and_reads_back():
    rows = 30_000
    columns = {"id": np.arange(1, rows + 1), "at": np.arange(rows) * 1_000_000 + 1_731_000_000_000_000,
               "subject": np.random.default_rng(3).integers(1, 50, rows)}
    distinct = int(columns["subject"].max()) + 1
    raw = pack_block(columns, ["w%d" % i for i in range(distinct)], {"rows": rows})
    block = Columns(raw)
    for name, numbers in columns.items():
        assert np.array_equal(block.column(name), numbers)
    plain_ids = keep([np.arange(1, rows + 1, dtype=np.int64)])
    assert len(raw) < len(plain_ids)
