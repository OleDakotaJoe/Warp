# WARP2/warp2/corpus/tests/test_the_connection_web_is_kept_in_corpus_form.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/test_the_connection_web_is_kept_in_corpus_form.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/table.py; warp2/corpus/convert/webs.py;
#              warp2/corpus/shelf.py; warp2/webs/home.py (db, folder);
#              (stdlib) sqlite3, math.
#  Description:
#    The connection web over the KG kept the way the KG's facts are: a column
#    of any kind comes back as the same values of the same types (texts,
#    whole numbers past what folds, -0.0, NaN, values of another kind than
#    their column's); a webs database comes back from its corpus form row for
#    row, its tables, views, indexes and triggers the same and its held
#    tables still read and written by name; a webs file that is not there is
#    given back when the webs are next opened; a picture of webs that have
#    not changed is not kept again, and a newer picture moves the one before
#    aside; a table bigger than memory allows is kept in several blocks; the
#    shelf says what the connection web takes in each form.
#  User intention (Andrew, 2026-11-14 11:16): "lets make sure the connection
#    web that should be over it is dehydrated like it is and that it will be
#    there and working when we get the new kg into the warp." BUILD_LOG 1638c.
# ============================================================================
"""Intention: the connection web comes back exactly from its corpus form, and comes back by itself when missing."""
import math
import os
import sqlite3

import numpy as np

from warp2.corpus import table
from warp2.corpus.columns import Columns, pack_block
from warp2.corpus.convert import webs
from warp2.webs.home import db, folder


def _round_trip(values: list) -> list:
    """Intention: one column packed and given back through a block, as the converter does it."""
    words = table.Words()
    sections, how = table.column_of("c", values, words)
    block = Columns(pack_block(sections, [], {}))
    return table.column_back(block, "c", how, [None] + words.texts, len(values))


def test_a_column_of_any_kind_comes_back_as_the_same_values_of_the_same_types():
    """Intention: nothing guessed - every value, its type and its bits, back as it was."""
    columns = [
        ["web:a", None, "web:a", "a\x00b", 7, "é ünï"],
        [3, -2, None, 1 << 62, -(1 << 63), 0, 5.0],
        [5, 6, 7, 8, 9, 10],
        [-0.0, 0.0, float("nan"), float("inf"), 1e-300, None, 2, 0.1 + 0.2],
        [None, None],
        [b"\x00\x01", b"x", None],
        [],
    ]
    for values in columns:
        assert table.same_values(_round_trip(values), values), values
    assert not table.same_values([1], [1.0]) and not table.same_values([0.0], [-0.0])
    assert table.same_values([math.nan], [math.nan])


def _fill(state) -> None:
    """Intention: a webs database as the webs make it, with every kind of table holding something."""
    con = db(state)
    with con:
        con.executemany("INSERT INTO member VALUES (?, ?, ?)",
                        [(f"use:{w}", f"warp2/part_{s}.py", s / 7 - w) for w in range(5) for s in range(40)])
        con.executemany("INSERT INTO term VALUES (?, ?)", [(f"warp2/part_{s}.py", f"phrase:t{s % 6}") for s in range(40)])
        con.executemany("INSERT INTO web_noted VALUES (?, ?)", [("use:1", f"warp2/part_{s}.py") for s in range(9)])
        con.executemany("INSERT INTO link VALUES (?, ?, ?, ?)", [("a", "b", -0.0, 3), ("b", "c", float("nan"), None)])
        con.execute("INSERT INTO web VALUES ('use:1', 'use', 'part web', 9, 0.5, NULL, 1.0, 12)")
        con.execute("INSERT INTO proof VALUES ('warp2/part_1.py', 2, 'done', 'a test passed')")
        con.execute("INSERT INTO decision VALUES ('use:1', 'keep', 3, NULL, 0, 0)")
        con.execute("INSERT INTO meta VALUES ('tick', '41')")
    con.close()


def _all_of(path) -> dict:
    """Intention: every table's rows (as SQLite keeps them, row numbers too) and the database's own words for itself."""
    con = sqlite3.connect(str(path))
    out = {"schema": sorted(con.execute("SELECT type, name, tbl_name, sql FROM sqlite_master"), key=repr)}
    for name, sql in con.execute("SELECT name, sql FROM sqlite_master WHERE type = 'table'").fetchall():
        shown = "*" if "WITHOUT ROWID" in sql.upper() else "rowid, *"
        out[name] = sorted(repr([(type(v).__name__, v.hex() if isinstance(v, float) else v) for v in row])
                           for row in con.execute(f'SELECT {shown} FROM "{name}"'))
    con.close()
    return out


def test_the_webs_come_back_row_for_row_from_their_corpus_form(tmp_path):
    """Intention: every table, row, value and type the same; the held tables still read and written by name."""
    state = tmp_path / "state"
    _fill(state)
    said = webs.keep_webs(state, say=lambda _line: None)
    assert said["rows"] > 0 and (state / "corpus" / "webs" / "now" / webs.KEPT).is_file()
    back = webs.give_back(state, tmp_path / "back.sqlite3", say=lambda _line: None)
    assert _all_of(back) == _all_of(folder(state) / "webs.sqlite3")
    con = sqlite3.connect(str(back))
    assert con.execute("SELECT strength FROM member WHERE web = 'use:2' AND subject = 'warp2/part_14.py'").fetchone()[0] \
        == 14 / 7 - 2
    con.execute("INSERT INTO member VALUES ('use:9', 'warp2/new.py', 1.0)")
    assert con.execute("SELECT subject FROM member WHERE web = 'use:9'").fetchone()[0] == "warp2/new.py"
    con.close()


def test_a_webs_file_that_is_not_there_comes_back_when_the_webs_are_opened(tmp_path):
    """Intention: the webs are there when the warp opens them, as they were kept - not empty."""
    state = tmp_path / "state"
    _fill(state)
    webs.keep_webs(state, say=lambda _line: None)
    path = folder(state) / "webs.sqlite3"
    was = _all_of(path)
    os.replace(path, tmp_path / "moved_away.sqlite3")
    con = db(state)
    assert con.execute("SELECT COUNT(*) FROM member").fetchone()[0] == 200
    con.close()
    assert _all_of(path) == was


def test_unchanged_webs_are_not_kept_again_and_a_newer_picture_moves_the_last_aside(tmp_path):
    """Intention: one picture now; the one before kept in older/, nothing thrown away."""
    state = tmp_path / "state"
    _fill(state)
    first = webs.keep_webs(state, say=lambda _line: None)
    assert webs.keep_webs(state, say=lambda _line: None)["did"] == "already kept"
    con = db(state)
    with con:
        con.execute("INSERT INTO link VALUES ('c', 'd', 0.25, 4)")
    con.close()
    os.utime(folder(state) / "webs.sqlite3", ns=(1, 1))   # Intention: changed, whatever the clock's grain
    second = webs.keep_webs(state, say=lambda _line: None)
    assert second["rows"] == first["rows"] + 1
    older = list((state / "corpus" / "webs" / "older").iterdir())
    assert len(older) == 1 and (older[0] / webs.KEPT).is_file()


def test_a_table_bigger_than_memory_allows_is_kept_in_several_blocks(tmp_path, monkeypatch):
    """Intention: blocks as big as half the free memory - and the whole still comes back."""
    state = tmp_path / "state"
    _fill(state)
    monkeypatch.setattr(webs, "free_bytes", lambda: 2 * 60 * webs._bytes_a_row([(1, 2, 0.5)], 3))
    said = webs.keep_webs(state, say=lambda _line: None)
    assert len(said["tables"]["member_n"]["blocks"]) >= 3
    back = webs.give_back(state, tmp_path / "back.sqlite3", say=lambda _line: None)
    assert _all_of(back) == _all_of(folder(state) / "webs.sqlite3")


def test_the_shelf_says_what_the_connection_web_takes(tmp_path):
    """Intention: the measures carry the connection web as it was and in corpus form."""
    from warp2.corpus.shelf import Shelf
    state = tmp_path / "state"
    _fill(state)
    webs.keep_webs(state, say=lambda _line: None)
    held = Shelf(state).measures()["connection web"]
    assert held["kept_bytes"] > 0 and held["as_it_was_bytes"] == (folder(state) / "webs.sqlite3").stat().st_size
    assert np.int64(held["rows"]) > 0
