# WARP3/warp2/corpus/table.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/table.py
#  Used by   : warp2/corpus/convert/webs.py (the connection web in corpus
#              form); warp2/corpus/tests/.
#  Uses      : warp2/corpus/columns.py (Columns - a packed block read back);
#              numpy.
#  Description:
#    ANY TABLE'S ROWS AS COLUMNS OF NUMBERS OVER ONE SHARED WORD NUMBERING,
#    GIVEN BACK EXACTLY. A database table can hold a different kind of value
#    in every row (SQLite keeps the type with each value), so each column of
#    a block of rows is read for what it mostly holds:
#      text  - each text's number in the shared word numbering (Words): one
#              numbering for every column of every table of a corpus, so a
#              name that is a web in one table and a member in another is
#              the same tag (a cross tag between tables);
#      int   - the whole numbers themselves;
#      real  - each number's place in the column's table of its distinct
#              values, the table kept as the two halves of each value's 64
#              bits (so -0.0, every NaN and every last bit come back);
#      none  - nothing at all is kept.
#    A number column is kept plain or as steps from the row before, whichever
#    is smaller by the bytes its numbers take. A value of another kind than
#    its column's, or a text the word table cannot carry (it holds the byte
#    that joins two words), is kept as itself, an exception at its place -
#    nothing is guessed. Every value comes back as the same type and the same
#    bits (1 is not 1.0).
#  User intention (Andrew, 2026-11-13 20:52): "it should have the other part
#    of the knowledge graph on top of it to connect everything. But all those
#    connections should still be in that kind of structure."; 21:05: "allow
#    cross tags as well of course." BUILD_LOG 1638c.
# ============================================================================
"""A table's rows as columns of numbers over one shared word numbering, every value back exactly."""
from __future__ import annotations

from collections import Counter

import numpy as np

JOIN = "\x00"   # Intention: the byte between two words in a word table (columns.py JOIN) - a word may not hold it


class Words:
    """Intention: one numbering of every text a corpus holds - word n is the n-th seen, counted from 1; 0 is no text."""

    def __init__(self) -> None:
        """Intention: no words yet."""
        self.number: dict = {}
        self.texts: list = []

    def of(self, text: str) -> int:
        """Intention: a text's number, given the first time it is seen."""
        found = self.number.get(text)
        if found is None:
            self.texts.append(text)
            found = self.number[text] = len(self.texts)
        return found


def kind_of(values: list) -> str:
    """Intention: what a column mostly holds - "text", "int" or "real" - or "none" when it holds no value at all."""
    seen = Counter(type(value).__name__ for value in values if value is not None)
    if not seen:
        return "none"
    most = seen.most_common(1)[0][0]
    return {"str": "text", "int": "int", "float": "real"}.get(most, "mixed")


def _folded(numbers: np.ndarray) -> np.ndarray:
    """Intention: whole numbers that may be negative as numbers that are not (0, -1, 1, -2 ... as 0, 1, 2, 3 ...)."""
    return np.where(numbers >= 0, numbers * 2, -numbers * 2 - 1)


def _unfolded(numbers: np.ndarray) -> np.ndarray:
    """Intention: the numbers `_folded` was given."""
    return np.where(numbers % 2 == 0, numbers // 2, -(numbers + 1) // 2)


def _varint_bytes(numbers: np.ndarray) -> int:
    """Intention: how many bytes these numbers take written seven bits a byte - the measure plain and steps are
    chosen by."""
    numbers = np.asarray(numbers, dtype=np.uint64)
    return int(numbers.size + sum(int((numbers >= np.uint64(1 << (7 * k))).sum()) for k in range(1, 9)))


def _smaller(plain: np.ndarray, steps) -> tuple:
    """Intention: ("plain" or "steps", the numbers) - the column as itself or as its steps from the row before,
    whichever is smaller; `steps` is None when steps cannot be used."""
    if steps is None or plain.size < 2:
        return "plain", plain
    return ("steps", steps) if _varint_bytes(steps) < _varint_bytes(plain) else ("plain", plain)


def _exception(value) -> list:
    """Intention: a value kept as itself, as [its type, a form JSON keeps exactly]."""
    if isinstance(value, float):
        return ["float", value.hex()]
    if isinstance(value, (bytes, bytearray, memoryview)):
        return ["bytes", bytes(value).hex()]
    return [type(value).__name__, value]


def _value(kept: list):
    """Intention: a value given back from its exception."""
    kind, said = kept
    if kind == "float":
        return float.fromhex(said)
    if kind == "bytes":
        return bytes.fromhex(said)
    return said


# Intention: the largest whole number that still folds into a 64-bit number; a larger one is kept as an exception.
_FOLDS = 1 << 61


def column_of(name: str, values: list, words: Words) -> tuple:
    """Intention: ({section name: numbers}, how it is kept) for one column of a block - how it is kept is the head's
    part for it: {"kind", "mode", "exceptions"}."""
    kind = kind_of(values)
    found: dict = {}
    sections: dict = {}
    mode = "plain"
    if kind == "text":
        numbers = np.zeros(len(values), dtype=np.int64)
        for place, value in enumerate(values):
            if value is None:
                continue
            if isinstance(value, str) and JOIN not in value:
                numbers[place] = words.of(value)
            else:
                found[str(place)] = _exception(value)
        mode, sections[name] = _smaller(numbers, _folded(np.diff(numbers, prepend=0)))
    elif kind == "int":
        fits = [type(value) is int and -_FOLDS < value < _FOLDS for value in values]
        for place, (value, fit) in enumerate(zip(values, fits)):
            if value is not None and not fit:
                found[str(place)] = _exception(value)
        whole = np.fromiter((value if fit else 0 for value, fit in zip(values, fits)), dtype=np.int64,
                            count=len(values))
        if all(fits):
            steps = np.diff(whole, prepend=0)
            mode, sections[name] = _smaller(_folded(whole), _folded(steps)
                                            if int(np.abs(steps).max(initial=0)) < _FOLDS else None)
        else:
            # Intention: a column with places that hold no whole number keeps every number one up, 0 for those.
            mode, sections[name] = "shifted", np.where(np.asarray(fits, dtype=bool), _folded(whole) + 1, 0)
    elif kind == "real":
        places = [place for place, value in enumerate(values) if type(value) is float]
        for place, value in enumerate(values):
            if value is not None and type(value) is not float:
                found[str(place)] = _exception(value)
        bits = np.asarray([values[place] for place in places], dtype=np.float64).view(np.uint64)
        table, where = np.unique(bits, return_inverse=True)
        numbers = np.zeros(len(values), dtype=np.int64)
        numbers[places] = where.astype(np.int64).ravel() + 1
        sections[name] = numbers
        sections[name + "~high"] = np.diff((table >> np.uint64(32)).astype(np.int64), prepend=0)
        sections[name + "~low"] = (table & np.uint64(0xFFFFFFFF)).astype(np.int64)
    else:
        for place, value in enumerate(values):
            if value is not None:
                found[str(place)] = _exception(value)
        kind = "none"
    return sections, {"kind": kind, "mode": mode, "exceptions": found}


def column_back(block, name: str, how: dict, words: list, rows: int) -> list:
    """Intention: one column's values back from a packed block - `words` the shared word table with None at place 0."""
    kind, mode = how["kind"], how["mode"]
    if kind == "none":
        out = [None] * rows
    elif kind == "real":
        numbers = block.column(name)
        high = np.cumsum(block.column(name + "~high")).astype(np.uint64)
        table = ((high << np.uint64(32)) | block.column(name + "~low").astype(np.uint64)).view(np.float64).tolist()
        out = [None if number == 0 else table[number - 1] for number in numbers.tolist()]
    else:
        numbers = block.column(name)
        if mode == "steps":
            numbers = np.cumsum(_unfolded(numbers))
        if kind == "text":
            out = [words[number] for number in numbers.tolist()]
        elif mode == "shifted":
            out = _unfolded(np.maximum(numbers - 1, 0)).tolist()
            for place in np.flatnonzero(numbers == 0).tolist():
                out[place] = None
        else:
            out = numbers.tolist() if mode == "steps" else _unfolded(numbers).tolist()
    for place, kept in how["exceptions"].items():
        out[int(place)] = _value(kept)
    return out


def same_values(first: list, second: list) -> bool:
    """Intention: two columns equal value for value and type for type - 1 is not 1.0, -0.0 is not 0.0, a NaN is
    itself."""
    if len(first) != len(second):
        return False
    for one, other in zip(first, second):
        if type(one) is not type(other):
            return False
        if isinstance(one, float):
            if one.hex() != other.hex():
                return False
        elif one != other:
            return False
    return True
