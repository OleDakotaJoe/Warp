# WARP2/warp2/corpus/kinds/png_pixels.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/png_pixels.py
#  Used by   : warp2/corpus/kinds/png.py.
#  Uses      : Pillow (WebP, lossless); numpy; (stdlib) io.
#  Description:
#    A PICTURE'S PIXELS KEPT IN WEBP'S LOSSLESS FORM, AND BACK EXACTLY. WebP
#    lossless guesses each pixel from those already seen (many guesses,
#    colour moved between channels, a cache of colours) - far better than
#    PNG's one filter a row. Measured on the warp's pictures (2026-11-15):
#    0.57-0.74 of the PNG file for photographs, at effort 4 (effort 6 came
#    out 0.2-3 percent smaller at two to ten times the time). Only 8-bit
#    grey, grey with alpha, RGB and RGBA - what WebP holds; `exact` keeps
#    the colour under clear pixels too. WebP has no grey: grey is written as
#    RGB and taken back as one channel, and the three must agree. What comes
#    back is compared with the pixels before the form counts (png.py).
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything"; the
#    question of 2026-11-13 (pixels or file bytes) does not arise - the
#    pixels are kept AND the file comes back the same (png.py). BUILD_LOG 1652c.
# ============================================================================
"""A picture's pixels in WebP's lossless form, and back to the very pixels."""
from __future__ import annotations

import io

import numpy as np

# Intention: the PNG colour types whose 8-bit pixels WebP holds, and how many channels each has.
CHANNELS = {0: 1, 4: 2, 2: 3, 6: 4}
# Intention: measured - effort 4 is within a few percent of the most effort at a fraction of its time (2026-11-15).
EFFORT = 4


def webp_of(pixels: np.ndarray) -> bytes:
    """Intention: the pixels (h, w) or (h, w, channels) as lossless WebP."""
    from PIL import Image
    out = io.BytesIO()
    Image.fromarray(np.ascontiguousarray(pixels)).save(out, "WEBP", lossless=True, quality=100, method=EFFORT,
                                                       exact=True)
    return out.getvalue()


def pixels_of(webp: bytes, channels: int) -> np.ndarray:
    """Intention: the pixels again, with as many channels as the picture had; grey taken back from the three equal
    channels WebP wrote it as (and when they are not equal, it is an error)."""
    from PIL import Image
    with Image.open(io.BytesIO(bytes(webp))) as picture:
        picture.load()
        back = np.asarray(picture.convert("RGBA" if channels in (2, 4) else "RGB"))
    if channels == 1:
        grey = back[..., 0]
        if not (np.array_equal(grey, back[..., 1]) and np.array_equal(grey, back[..., 2])):
            raise ValueError("a grey picture came back from WebP with colour in it")
        return np.ascontiguousarray(grey)
    if channels == 2:
        grey = back[..., 0]
        if not (np.array_equal(grey, back[..., 1]) and np.array_equal(grey, back[..., 2])):
            raise ValueError("a grey picture came back from WebP with colour in it")
        return np.ascontiguousarray(np.stack([grey, back[..., 3]], axis=-1))
    return np.ascontiguousarray(back)
