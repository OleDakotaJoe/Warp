# WARP3/warp2/corpus/kinds/lanes.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/lanes.py
#  Used by   : warp2/corpus/kinds/way.py.
#  Uses      : warp2/corpus/kinds/{framing,xz,pieces}.py; numpy.
#  Description:
#    A FILE'S BYTES TAKEN AS VALUES OF W BYTES (2, 4 or 8), each byte lane
#    put together and kept through LZMA on its own. Weights, tensors and
#    arrays hold numbers of a set width, and a number's high byte is much
#    like the next number's high byte - kept together, the lanes come out
#    smaller (measured 2026-11-15: an adapter's weights 0.834 of the file
#    against 0.919 for the file through LZMA whole; a float array 0.661
#    against 0.706). The bytes past the last whole value are kept as they
#    are. Each width is its own way (2, 3 and 4), so which width suits a
#    kind of file is learned like any other choice.
#    2026-11-21 (WARP3 carry item A2): new files keep each lane through the
#    warp's own compression (pieces.py) as ways 7, 8 and 9; the LZMA ways
#    2, 3 and 4 are only read back, so what they kept is never lost.
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything"; 2026-11-19 22:31: "we should not
#    be using zip anywhere we should be using the warps own compression system";
#    2026-11-13 (the byte lanes of the models' corpus, form 5). BUILD_LOG
#    1652c.
# ============================================================================
"""A file's bytes kept as byte lanes of a set width, each lane through its coder (the warp's own, or LZMA read back)."""
from __future__ import annotations

import numpy as np

from warp2.corpus.kinds.framing import apart, joined
from warp2.corpus.kinds import pieces, xz

# Intention: the way numbers of the three widths - fixed, as every kept form names its way by number. The xz lanes
# (2, 3, 4) are only read back now; new files are kept by the warp's own compression (7, 8, 9 - pieces.py).
NUMBERS = {2: 2, 4: 3, 8: 4}
PIECES_NUMBERS = {2: 7, 4: 8, 8: 9}
# Intention: the inner coder of each kind of lanes - what squeezes a lane and what opens it again.
CODERS = {"xz": (xz.squeezed, xz.opened), "pieces": (pieces.squeezed, pieces.opened)}


class Lanes:
    """Intention: ways 2, 3 and 4 (lanes through LZMA, read back only) and 7, 8 and 9 (lanes through the warp's own
    compression) - the file as lanes of 2, 4 or 8 bytes."""

    def __init__(self, width: int, coder: str = "xz") -> None:
        """Intention: how many bytes make one value and which coder keeps each lane; the way's number follows from
        both."""
        self.width = int(width)
        self.coder = coder
        self.number = (PIECES_NUMBERS if coder == "pieces" else NUMBERS)[self.width]
        self.name = f"lanes{self.width}" if coder == "xz" else f"pieces_lanes{self.width}"
        self._squeeze, self._open = CODERS[coder]

    def keep(self, raw, hints: dict) -> tuple | None:
        """Intention: each lane through its coder, then the bytes past the last whole value; None for a file shorter than
        two values (there is nothing to put together)."""
        data = np.frombuffer(bytes(raw), dtype=np.uint8)
        whole = data.size // self.width * self.width
        if whole < 2 * self.width:
            return None
        lanes = data[:whole].reshape(-1, self.width)
        pieces = [self._squeeze(np.ascontiguousarray(lanes[:, i]).tobytes()) for i in range(self.width)]
        return joined(pieces + [data[whole:].tobytes()]), {}

    def back(self, body) -> bytes:
        """Intention: the lanes opened and put back side by side, then the bytes past the last whole value."""
        pieces = apart(body)
        if len(pieces) != self.width + 1:
            raise ValueError(f"a lanes{self.width} form holds {len(pieces)} pieces")
        lanes = [np.frombuffer(self._open(piece), dtype=np.uint8) for piece in pieces[:-1]]
        if len({lane.size for lane in lanes}) != 1:
            raise ValueError("the lanes of a kept form are not all as long")
        return np.stack(lanes, axis=1).tobytes() + pieces[-1]
