# WARP2/warp2/corpus/kinds/png.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/png.py
#  Used by   : warp2/corpus/kinds/way.py (way 5);
#              projects/behemoth_eye/eye/held_small/forms.py (form 6: a
#              picture kept in a tensor book as its bytes - the pictures
#              book - is kept this way too); warp2/tags/media/door.py
#              (pixels_kept, 1653c - its pixels read straight from form 6).
#  Uses      : warp2/corpus/kinds/{framing,png_chunks,png_recipe,png_filters,
#              png_pixels,xz}.py; Pillow (to read the pixels); numpy;
#              (stdlib) io, zlib.
#  Description:
#    A PNG KEPT AS WHAT IT IS MADE OF, GIVING BACK THE VERY FILE. A PNG is
#    its chunks (kept as they are - png_chunks.py) and one stream: the
#    picture's rows, filtered, packed by deflate. The stream is not kept:
#    how it was made is found (png_recipe.py - zlib's settings, or Pillow's
#    level) and it is made again. What is kept of the picture is the
#    smaller of:
#      rows  the filtered rows through LZMA - any PNG (any depth, palette,
#            interlaced); measured 0.31-0.34 of the file on the hypersim
#            16-bit depths (2026-11-15);
#      webp  the pixels in WebP's lossless form, and each row's filter
#            byte (png_pixels.py, png_filters.py) - 8-bit grey, grey and
#            alpha, RGB, RGBA; measured 0.57-0.74 of the file on photographs.
#    Which of the two is tried first, and which recipes, is handed in by
#    the chooser from what won before (hints). A PNG none of the recipes
#    makes again is not kept this way (its stream cannot come back the same)
#    - it is kept by another way, or as it is.
#  User intention (Andrew, 2026-11-14 23:42): "Then we need to adapt it to
#    adapt it to everything". 2026-11-13: the pictures book holds PNG file
#    bytes, two thirds of all that is kept. BUILD_LOG 1652c.
# ============================================================================
"""A PNG kept as its chunks, how its stream was made, and its picture - rows or pixels, the smaller - exactly."""
from __future__ import annotations

import io
import struct
import zlib

import numpy as np

from warp2.corpus.kinds.framing import apart, joined
from warp2.corpus.kinds.png_chunks import chunks_of, from_layout, layout_of, made
from warp2.corpus.kinds.png_filters import refiltered
from warp2.corpus.kinds.png_pixels import CHANNELS, pixels_of, webp_of
from warp2.corpus.kinds.png_recipe import (key_of, made_by, pil_made, pil_matches, pil_tries, recipe_of,
                                           zlib_made, zlib_matches, zlib_tries)
from warp2.corpus.kinds.xz import opened, squeezed

ROWS, WEBP = "rows", "webp"
# Intention (1653c): the chunks that change what a picture's pixels mean - with one, the pixels are read as the file
MEANING = {b"tRNS"}
IHDR = struct.Struct(">IIBBBBB")   # width, height, bit depth, colour type, packing, filtering, interlace


class Png:
    """Intention: way 5 - a PNG as its chunks, its stream's recipe, and its picture."""

    number = 5
    name = "png"

    def keep(self, raw, hints: dict) -> tuple | None:
        """Intention: (body, what was used) - or None when this is not a PNG whose stream a recipe makes again."""
        chunks = chunks_of(raw)
        if not chunks or chunks[0][0] != b"IHDR" or len(chunks[0][1]) != IHDR.size:
            return None
        width, height, depth, colour, _packing, _filtering, interlace = IHDR.unpack(chunks[0][1])
        layout, stream = layout_of(chunks)
        opener = zlib.decompressobj()
        try:
            rows = opener.decompress(stream)
        except zlib.error:  # fault: ok a stream that does not open is not a picture this way can make again
            return None
        if not opener.eof:
            return None
        tail = opener.unused_data
        core = stream[:len(stream) - len(tail)]
        known = list(hints.get("recipes", []))
        recipe = next((each for each in zlib_tries(core, known) if zlib_matches(rows, core, each)), None)
        forms = list(hints.get("forms", [WEBP, ROWS]))
        pixels = None
        if depth == 8 and colour in CHANNELS and not interlace:
            pixels = _pixels(raw, height, width, CHANNELS[colour])
        found = []
        for form in forms + [each for each in (WEBP, ROWS) if each not in forms]:
            if found and form not in forms:
                break
            made_now = self._form(form, rows, pixels, recipe, core, known, CHANNELS.get(colour, 0))
            if made_now is not None:
                found.append(made_now)
        if not found:
            return None
        size, form, recipe_used, picture, extra = min(found, key=lambda each: each[0])
        libraries = ";".join(f"{name}={version}" for name, version in sorted(made_by().items()))
        body = joined([layout, tail, key_of(recipe_used).encode(), libraries.encode(), form.encode(), picture, extra])
        return body, {"recipe": key_of(recipe_used), "form": form, "forms_tried": [each[1] for each in found]}

    def _form(self, form: str, rows: bytes, pixels, recipe, core: bytes, known: list, channels: int):
        """Intention: (size, form, recipe, picture, extra) for one form - None when it cannot give the stream back."""
        if form == ROWS:
            if recipe is None:
                return None
            picture = squeezed(rows)
            return len(picture), ROWS, recipe, picture, b""
        if pixels is None:
            return None
        if recipe is not None:
            step = pixels.shape[1] * channels + 1
            kinds = np.frombuffer(rows, dtype=np.uint8)[0::step]
            if refiltered(pixels.reshape(pixels.shape[0], -1), kinds, channels) != rows:
                return None
            extra = squeezed(kinds.tobytes())
        else:
            recipe = next((each for each in pil_tries(core, known) if pil_matches(pixels, core, each)), None)
            if recipe is None:
                return None
            extra = b""
        picture = webp_of(pixels)
        if not np.array_equal(pixels_of(picture, channels), pixels):
            return None
        return len(picture) + len(extra), WEBP, recipe, picture, extra

    def back(self, body) -> bytes:
        """Intention: the very PNG file: the picture back, its stream made again by its recipe, the chunks around it."""
        layout, tail, key, _libraries, form, picture, extra = apart(body)
        recipe = recipe_of(key.decode())
        width, height, _depth, colour, _packing, _filtering, _interlace = _header(layout)
        if form == ROWS.encode():
            stream = zlib_made(opened(picture), recipe)
        elif form == WEBP.encode():
            channels = CHANNELS[colour]
            pixels = pixels_of(picture, channels)
            if pixels.shape[:2] != (height, width):
                raise ValueError("the kept pixels are not the picture's size")
            if recipe[0] == "zlib":
                kinds = np.frombuffer(opened(extra), dtype=np.uint8)
                stream = zlib_made(refiltered(pixels.reshape(height, -1), kinds, channels), recipe)
            else:
                stream = pil_made(pixels, recipe)
        else:
            raise ValueError(f"no picture form {form!r} is known here: this was kept by newer code")
        return made(from_layout(layout, stream + tail))


def pixels_kept(body):
    """Intention (BUILD_LOG 1653c; Andrew 2026-11-15 01:01: "start working more directly through the kg"): a picture's
    pixels straight from its kept form - (h, w) or (h, w, channels), 8 bits, as Pillow gives them from the file - with
    no PNG made again and decoded; None when it is kept as its rows, or when a chunk changes what its pixels mean
    (a transparent colour, which Pillow carries beside the pixels) - it is then read as its file."""
    layout, _tail, _key, _libraries, form, picture, _extra = apart(body)
    if form != WEBP.encode():
        return None
    letters = set(apart(layout)[0::2])
    if letters & MEANING:
        return None
    _width, _height, _depth, colour, _packing, _filtering, _interlace = _header(layout)
    return pixels_of(picture, CHANNELS[colour])


def _header(layout) -> tuple:
    """Intention: the picture's header (IHDR) from a kept layout - its first chunk."""
    letters, kept = apart(layout)[:2]
    if letters != b"IHDR" or kept[:1] != b"C":
        raise ValueError("a PNG layout that does not begin with its header")
    return IHDR.unpack(kept[1:])


def _pixels(raw, height: int, width: int, channels: int):
    """Intention: the picture's pixels as Pillow reads them - (h, w) or (h, w, channels), 8 bits - or None when
    Pillow cannot read them as such (the picture is then kept by its rows)."""
    from PIL import Image
    try:
        with Image.open(io.BytesIO(bytes(raw))) as picture:
            picture.load()
            pixels = np.asarray(picture)
    except (OSError, ValueError, Image.DecompressionBombError):  # fault: ok a picture Pillow will not read is kept by its rows
        return None
    want = (height, width) if channels == 1 else (height, width, channels)
    if pixels.dtype != np.uint8 or pixels.shape != want:
        return None
    return np.ascontiguousarray(pixels)
