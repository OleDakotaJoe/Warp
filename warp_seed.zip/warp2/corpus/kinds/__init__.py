# WARP2/warp2/corpus/kinds/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/__init__.py
#  Used by   : warp2/corpus/convert/rest.py (each turn's keeping of every
#              kind of file); projects/behemoth_eye/eye/held_small/forms.py
#              (form 6: a picture's bytes kept as its pixels); tests/.
#  Uses      : nothing itself (its modules are imported by name).
#  Description:
#    EVERY KIND OF FILE KEPT ITS LEAST WAY, EXACTLY. The text of the state has
#    its corpus (warp2/corpus/convert/state_text.py); everything else - the
#    pictures, the weights and tensors, the datasets, the databases - is
#    kept here. Each WAY (xz.py, lanes.py, png.py) keeps a file's bytes in a
#    form that gives the very bytes back; which way is tried first for a kind
#    of file is learned from what won before (choose.py), never set; what a
#    file comes to is kept in its collection's packs (packs.py); keep.py runs
#    a turn of it and gives a kept file back (file_back).
#  User intention (Andrew, 2026-11-14 23:42): "Then we need to adapt it to
#    adapt it to everything" - the step that finds what is not dehydrated
#    (BUILD_LOG 1651c) made to keep every kind, not only text. BUILD_LOG 1652c.
# ============================================================================
"""Every kind of file kept its least way, exactly - the ways, what was learned about them, and where it is kept."""
