# WARP2/warp2/corpus/kinds/png_filters.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/png_filters.py
#  Used by   : warp2/corpus/kinds/png.py.
#  Uses      : numpy; psutil (when there is one - the room the work may take).
#  Description:
#    A PNG'S ROWS FILTERED AGAIN FROM ITS PIXELS. Before a PNG's rows are
#    packed, each row is FILTERED: written as how it differs from the pixel
#    to its left (Sub), above (Up), their average (Average), or the Paeth
#    guess - the filter named by the row's first byte. Every filter works on
#    the pixels as they are (never on filtered values), so with the pixels
#    and each row's filter byte the filtered rows come back exactly, all the
#    rows of one filter worked out at once. It is done a band of rows at a
#    time, the band as many rows as half the free memory holds.
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything" - a
#    picture kept as its pixels still gives back its very file. BUILD_LOG 1652c.
# ============================================================================
"""PNG rows filtered again, exactly, from their pixels and each row's filter byte."""
from __future__ import annotations

import numpy as np


def refiltered(rows: np.ndarray, kinds: np.ndarray, step: int) -> bytes:
    """Intention: the filtered rows - each led by its filter byte - from the pixel rows (h, row bytes), the filter of
    each row, and `step`, the bytes from one pixel to the next (the left neighbour). A filter PNG has not got is said."""
    rows = np.ascontiguousarray(rows, dtype=np.uint8)
    kinds = np.asarray(kinds, dtype=np.uint8)
    height, width = rows.shape
    out = np.empty((height, width + 1), dtype=np.uint8)
    out[:, 0] = kinds
    band = _band_rows(width)
    for top in range(0, height, band):
        bottom = min(height, top + band)
        above = rows[top - 1] if top else np.zeros(width, dtype=np.uint8)
        out[top:bottom, 1:] = _band(rows[top:bottom], above, kinds[top:bottom], int(step))
    return out.tobytes()


def _band(rows: np.ndarray, above: np.ndarray, kinds: np.ndarray, step: int) -> np.ndarray:
    """Intention: one band of rows filtered, `above` being the row just over the band (noughts over the first row)."""
    x = rows.astype(np.int16)
    up = np.empty_like(x)
    up[0] = above
    up[1:] = x[:-1]
    left = np.zeros_like(x)
    left[:, step:] = x[:, :-step]
    upleft = np.zeros_like(x)
    upleft[:, step:] = up[:, :-step]
    done = np.empty(x.shape, dtype=np.uint8)
    for kind in np.unique(kinds):
        sel = kinds == kind
        done[sel] = (x[sel] - _guess(int(kind), left[sel], up[sel], upleft[sel])).astype(np.uint8)
    return done


def _guess(kind: int, left: np.ndarray, up: np.ndarray, upleft: np.ndarray):
    """Intention: what a filter takes away from each byte - the PNG standard's five filters, on unfiltered values."""
    if kind == 0:
        return np.zeros_like(left)
    if kind == 1:
        return left
    if kind == 2:
        return up
    if kind == 3:
        return (left + up) >> 1
    if kind == 4:
        p = left + up - upleft
        pa, pb, pc = np.abs(p - left), np.abs(p - up), np.abs(p - upleft)
        return np.where((pa <= pb) & (pa <= pc), left, np.where(pb <= pc, up, upleft))
    raise ValueError(f"no PNG filter {kind}")


def _band_rows(width: int) -> int:
    """Intention: how many rows one band takes - as many as half the free memory holds (the corpus's rule for any
    block), each byte of a row being worked on as about eight 16-bit values at once; every row at once when the free
    memory cannot be asked."""
    try:
        import psutil
    except ImportError:  # fault: ok without psutil the rows are taken all at once, as one band
        return 1 << 62
    free = int(psutil.virtual_memory().available)
    return max(1, free // 2 // max(1, width * 16))
