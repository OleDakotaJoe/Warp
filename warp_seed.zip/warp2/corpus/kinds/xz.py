# WARP2/warp2/corpus/kinds/xz.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/xz.py
#  Used by   : warp2/corpus/kinds/{way,lanes,png}.py.
#  Uses      : (stdlib) lzma.
#  Description:
#    A FILE'S BYTES THROUGH LZMA (the xz format, with its own check). It finds
#    repeats far apart, which the other ways do not; it is the way any file
#    can be tried with. Measured on the warp's own files (2026-11-15):
#    preset 6 and preset 9 "extreme" came out the same to a tenth of a
#    percent on tensors, weights and adapters, and 6 is the faster.
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything".
#    BUILD_LOG 1652c.
# ============================================================================
"""Any file's bytes kept through LZMA, and given back."""
from __future__ import annotations

import lzma

# Intention: measured equal in size to the slowest setting on the warp's own files (2026-11-15), and faster.
PRESET = 6


def squeezed(raw) -> bytes:
    """Intention: the bytes through LZMA - used by the ways that keep a part of a file this way."""
    return lzma.compress(bytes(raw), preset=PRESET)


def opened(body) -> bytes:
    """Intention: what `squeezed` kept, given back; a body that does not open is an error (lzma's own check)."""
    return lzma.decompress(bytes(body))


class Xz:
    """Intention: way 1 - the whole file through LZMA."""

    number = 1
    name = "xz"

    def keep(self, raw, hints: dict) -> tuple | None:
        """Intention: the file through LZMA; it fits every file (whether it is smaller is the chooser's to say)."""
        return squeezed(raw), {}

    def back(self, body) -> bytes:
        """Intention: the file's bytes again."""
        return opened(body)
