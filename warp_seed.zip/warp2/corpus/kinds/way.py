# WARP2/warp2/corpus/kinds/way.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/way.py
#  Used by   : warp2/corpus/kinds/{keep,choose}.py; tests/.
#  Uses      : warp2/corpus/kinds/{xz,lanes,png}.py (the ways themselves).
#  Description:
#    THE WAYS, BY THEIR NUMBER. A kept form is one byte - the number of the
#    way that made it - and then that way's own body, so a new way is a new
#    number and nothing kept before has to change. Every way has the same
#    two doors: keep(raw, hints) gives (body, what it used) or None when it
#    does not fit the file (a picture way on a file that is not a picture);
#    back(body) gives the very bytes back. A way says nothing about whether
#    it is smaller - the chooser compares (choose.py), and the bytes back are
#    checked against the file's sha256 before anything counts (keep.py).
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything";
#    2026-11-14 15:59: "The only things that matter are storage space and time
#    to generate from storage." BUILD_LOG 1652c.
# ============================================================================
"""The ways a file's bytes can be kept, by number: a kept form is the way's number and its body."""
from __future__ import annotations


def ways() -> dict:
    """Intention: every way in use, by its number - the numbers are what kept forms say, so they never change."""
    from warp2.corpus.kinds.lanes import Lanes
    from warp2.corpus.kinds.png import Png
    from warp2.corpus.kinds.xz import Xz
    found = [Xz(), Lanes(2), Lanes(4), Lanes(8), Png()]
    return {way.number: way for way in found}


def kept_form(number: int, body: bytes) -> bytes:
    """Intention: a way's body with the way's number in front - what is written to the packs."""
    return bytes([int(number)]) + bytes(body)


def given_back(kept: bytes, known: dict | None = None) -> bytes:
    """Intention: the bytes a kept form stands for, by the way its first byte names; a number nobody knows is said."""
    known = known if known is not None else ways()
    number = kept[0]
    if number not in known:
        raise KeyError(f"no way {number} is known here: this was kept by newer code")
    return known[number].back(memoryview(kept)[1:])
