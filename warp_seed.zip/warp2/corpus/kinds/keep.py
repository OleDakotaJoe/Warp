# WARP3/warp2/corpus/kinds/keep.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/keep.py
#  Used by   : warp2/corpus/convert/rest.py (each turn: the files the text
#              corpus found not to be text); tests/.
#  Uses      : warp2/corpus/kinds/{way,choose,packs}.py;
#              warp2/corpus/convert/state_text.py (OwnForm - files whose own
#              form is the smallest, noted so they are not tried again until
#              written since); warp2/tags/media/door.py (the pictures book),
#              projects/behemoth_eye/eye/held_small/door.py (the Eye's book),
#              warp2/house/held_small/door.py (the house's book) - what those
#              books already hold is theirs; warp2/vault/mined/touch.py
#              (touched - every file kept and every file given back is told
#              to the vault's mine); (stdlib) hashlib, time.
#  Description:
#    ONE TURN OF KEEPING EVERY FILE THAT IS NOT TEXT (KindsTurn), AND A KEPT
#    FILE GIVEN BACK (file_back). For each file handed in (the text corpus's walk found it not to
#    be text): passed over when it is kept here as it is now, when its own
#    form was found the smallest and it has not been written since, or when
#    another book holds it (the pictures', the Eye's, the house's - their
#    own turns keep them; asked once for each writing of the file, then
#    known from elsewhere.json). A file written since it was last kept is kept
#    again only once it has been still for longer than the time between its
#    last two writings (one that is written over and over is caught when it
#    rests, not every time). The kinds that saved the most a second go
#    first, a kind never seen before ahead of all. Each file: the ways tried
#    in the order learned for its kind (choose.py); the smallest form that
#    gives back the very bytes is put in its collection's packs with its
#    sha256 - or, when no way is smaller than the file, its own form is
#    noted as the smallest. A file whose kind has taken longer a byte than
#    the turn has left waits for the next turn. What was tried and what won
#    is learned either way.
#  User intention (Andrew, 2026-11-14 23:42): "Then we need to adapt it to
#    adapt it to everything"; 22:25: "a system to look for nondehydrated
#    things and dehydrates them and puts them in the smaller kg". BUILD_LOG
#    1652c.
# ============================================================================
"""Every file that is not text kept its least way inside a turn, learned kind by kind; a kept file given back."""
from __future__ import annotations

import hashlib
import time
from pathlib import Path

from warp2.corpus.kinds.choose import Learned
from warp2.corpus.kinds.packs import Packs
from warp2.corpus.kinds.way import given_back, kept_form, keeping_ways, ways

HOME = ("corpus", "kinds")
LEARNED = "learned.json"
ELSEWHERE = "elsewhere.json"   # Intention: files another book was found to hold, by the write time they had then
# Intention: the endings of the files the pictures book keeps (warp2/tags/media) - only these are asked of it.
PICTURES = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}


def kinds_home(state) -> Path:
    """Intention: where every collection's packs and the learned tallies live."""
    return Path(state).joinpath(*HOME)


def packs_of(state, collection: str) -> Packs:
    """Intention: one collection's packs (the files right in state/ are the collection "_top", as in the text corpus)."""
    return Packs(kinds_home(state) / ("_top" if collection == "." else collection))


def kind_of(path) -> str:
    """Intention: a file's kind - its ending, as the learning is kept by (a file with none is "-")."""
    return Path(path).suffix.lower() or "-"


def held_elsewhere(state, path) -> str:
    """Intention: which other book already keeps this file ("" when none): the pictures', the Eye's, the house's."""
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in PICTURES:
        from warp2.tags.media.door import media_door_of, media_home
        if media_door_of(media_home(state)).has(path):
            return "pictures"
    if suffix == ".pt" and "eye" in path.parts:
        from projects.behemoth_eye.eye.held_small.door import has_beside, has_home
        if has_beside(path) or has_home(path):
            return "eye"
    if suffix == ".safetensors":
        from warp2.house.held_small.door import safe, small_home
        if (small_home(state) / safe(path.parent.name) / (safe(path.name) + ".json")).is_file():
            return "house"
    return ""


def settled(last_stamp, seen: int, now_ns: int) -> bool:
    """Intention: whether a file written since it was last kept (or noted) has rested long enough to keep again -
    for longer than the time between its last two writings; a file never kept before always has."""
    if last_stamp is None:
        return True
    return now_ns - int(seen) >= int(seen) - int(last_stamp)


class KindsTurn:
    """Intention: one turn of keeping files that are not text - handed in as many times as the turn walks folders,
    what was learned and noted written back once, at the end."""

    def __init__(self, state, say=print, rng=None) -> None:
        """Intention: the state, where progress is said, and what was learned so far (`rng` draws the chances)."""
        self.state = Path(state)
        self.say = say
        self.began = time.monotonic()
        self.learned = Learned(kinds_home(self.state) / LEARNED, rng)
        self.known = ways()
        # Intention (WARP3 A2): new files are kept only by the ways with the warp's own compression inside; every way
        # stays known so what was kept before is given back.
        self.keeping = keeping_ways()
        self.done = {"files": 0, "bytes_were": 0, "bytes_now": 0, "own_form_smaller": {"files": 0, "bytes": 0},
                     "held": 0, "in_other_books": {}, "still_being_written": 0, "not_looked_at": 0,
                     "waits_for_time": 0, "not_given_back": 0, "by_kind": {}, "seconds": 0.0}
        self.packs, self.owns, self.own_found, self.others, self.other_found = {}, {}, {}, {}, {}
        self.stopped = False   # Intention: whether the last `keep` stopped because the time had come

    def _of(self, collection: str) -> tuple:
        """Intention: a collection's packs and its two notes (own form the smallest; held by another book)."""
        if collection not in self.packs:
            from warp2.corpus.convert.state_text import OwnForm
            self.packs[collection] = packs_of(self.state, collection)
            self.owns[collection] = OwnForm(self.packs[collection].folder)
            self.others[collection] = OwnForm(self.packs[collection].folder, ELSEWHERE)
        return self.packs[collection], self.owns[collection], self.others[collection]

    def keep(self, files, until: float | None = None) -> None:
        """Intention: these files kept their least way while the time lasts - those already kept, noted, held by
        another book or still being written passed over; the kinds that saved the most a second first."""
        done, waiting, now_ns = self.done, [], time.time_ns()
        self.stopped = False
        for collection, name, path, seen, size in files:
            packs, own, others = self._of(collection)
            entry = packs.entry(name)
            own_stamp = own.found.get(name)
            if (entry is not None and int(entry["stamp"]) == int(seen)) or own_stamp == seen:
                done["held"] += 1
                continue
            # Intention: what another book holds is asked of it once for each writing of the file, then known from the
            # note (asking the pictures book of tens of thousands of pictures every turn is a look at the disk each).
            book = "noted before" if others.found.get(name) == seen else held_elsewhere(self.state, path)
            if book:
                done["in_other_books"][book] = done["in_other_books"].get(book, 0) + 1
                if book != "noted before":
                    self.other_found.setdefault(collection, []).append((name, path, seen, size))
                continue
            last = entry["stamp"] if entry is not None else own_stamp
            if not settled(last, seen, now_ns):
                done["still_being_written"] += 1
                continue
            waiting.append((collection, name, path, seen, size, kind_of(path)))
        waiting.sort(key=lambda each: (-self.learned.saved_a_second(each[5]), each[4]))
        for at, (collection, name, path, seen, size, kind) in enumerate(waiting):
            if until is not None and time.monotonic() >= until:
                done["not_looked_at"] += len(waiting) - at
                self.stopped = True
                break
            if until is not None and self.learned.seconds_for(kind, size) > until - time.monotonic():
                done["waits_for_time"] += 1
                continue
            self._one(collection, name, path, seen, kind)

    def _one(self, collection: str, name: str, path: Path, seen: int, kind: str) -> None:
        """Intention: one file kept its least way and put in its collection's packs - or its own form noted as the
        smallest, or (said) left when its smallest form did not give it back."""
        began = time.monotonic()
        kept = _kept_one(path, seen, kind, self.learned, self.known, self.say, self.keeping)
        if kept is None:
            return
        number, form, raw = kept
        done = self.done
        if number is None:
            self.own_found.setdefault(collection, []).append((name, path, seen, len(raw)))
            done["own_form_smaller"]["files"] += 1
            done["own_form_smaller"]["bytes"] += len(raw)
            return
        if number < 0:
            done["not_given_back"] += 1
            return
        self.packs[collection].add(name, kind, number, form, seen, len(raw), hashlib.sha256(raw).hexdigest())
        done["files"] += 1
        done["bytes_were"] += len(raw)
        done["bytes_now"] += len(form)
        files_, were, now = done["by_kind"].get(kind, (0, 0, 0))
        done["by_kind"][kind] = (files_ + 1, were + len(raw), now + len(form))
        # Intention (0345v): a thing saved adds a little to the vault - the mine is told how long the keeping took.
        from warp2.vault.mined.touch import touched
        touched(self.state, time.monotonic() - began, True)

    def close(self) -> dict:
        """Intention: the notes written (one write a collection), the packs closed, what was learned saved; what the
        turn came to."""
        for collection, found in self.own_found.items():
            self.owns[collection].note(found)
        for collection, found in self.other_found.items():
            self.others[collection].note(found)
        self.own_found, self.other_found = {}, {}
        for each in self.packs.values():
            each.close()
        self.learned.save()
        self.done["seconds"] = round(time.monotonic() - self.began, 1)
        return self.done


def _kept_one(path: Path, seen: int, kind: str, learned: Learned, known: dict, say, keeping: dict | None = None):
    """Intention: one file tried with the ways in the order learned for its kind: (way, kept form, the bytes) for
    the smallest form that gives back the very bytes; (None, None, bytes) when no way is smaller than the file;
    (-1, None, bytes) when the smallest did not give the file back (said); None when the file changed or went while
    it was read (the next turn takes it). The ways tried are `keeping` (the warp's own compression inside - WARP3 A2);
    `known` gives the winner back to check it."""
    try:
        raw = path.read_bytes()
        if path.stat().st_mtime_ns != int(seen):
            return None
    except OSError:  # fault: ok a file in use or gone now is the next turn's
        return None
    began = time.monotonic()
    hints = learned.hints(kind)
    tried, used, best = {}, {}, None
    keeping = keeping if keeping is not None else keeping_ways()
    for number, go in learned.order(kind, keeping):
        # Intention: a way drawn not to be tried is still tried while no way so far has fitted the file at all (a
        # picture way drawn first for a file that is no picture must not leave the file untried).
        if not go and any(out is not None for out in tried.values()):
            continue
        got = keeping[number].keep(raw, hints)
        if got is None:
            tried[number] = None
            continue
        body, inside = got
        form = kept_form(number, body)
        tried[number] = len(form)
        used[number] = inside
        if len(form) < len(raw) and (best is None or len(form) < len(best[1])):
            best = (number, form)
    winner = None
    if best is not None and given_back(best[1], known) == raw:
        winner = best[0]
    elif best is not None:
        say(f"  {path.name}: way {best[0]} did not give the very bytes back - kept as it is, and said")
    learned.noted(kind, tried, winner, len(raw), time.monotonic() - began, used)
    if best is not None and winner is None:
        return -1, None, raw
    return (winner, best[1], raw) if winner is not None else (None, None, raw)


def file_back(state, name: str) -> bytes:
    """Intention: a kept file's very bytes from its form - checked against the sha256 it had when kept; a form that
    does not give it back is an error, never a guess."""
    began, collection = time.monotonic(), name.split("/", 1)[0] if "/" in name else "."
    packs = packs_of(state, collection)
    entry = packs.entry(name)
    if entry is None:
        raise KeyError(name)
    raw = given_back(packs.read(name))
    if hashlib.sha256(raw).hexdigest() != entry["sha"]:
        raise ValueError(f"{name}: its kept form does not give back the file it was kept from")
    # Intention (0345v): a thing brought back adds a little to the vault - the mine is told how long the reading took.
    from warp2.vault.mined.touch import touched
    touched(state, time.monotonic() - began, False)
    return raw
