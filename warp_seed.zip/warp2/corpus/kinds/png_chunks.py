# WARP3/warp2/corpus/kinds/png_chunks.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/png_chunks.py
#  Used by   : warp2/corpus/kinds/{png,png_recipe}.py.
#  Uses      : warp2/corpus/kinds/framing.py; (stdlib) struct, zlib.
#  Description:
#    A PNG FILE AS ITS CHUNKS, AND BACK. A PNG is its eight-byte mark and
#    then chunks: a length, four letters, the data, a check (CRC-32) of the
#    letters and data. The picture itself is one zlib stream cut across the
#    IDAT chunks. `layout` keeps everything else as it is - every other
#    chunk whole, and how long each IDAT piece was - so the file comes back
#    the same once the stream is made again; the checks are worked out
#    again, never kept. A file whose checks do not hold is not taken apart
#    (it is not re-made by this way; another way keeps it as it is).
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything" - the
#    pictures, two thirds of what the warp keeps, as what they are made of.
#    BUILD_LOG 1652c.
# ============================================================================
"""A PNG as its chunks: everything but the picture's stream kept as it is, and the file made again from it."""
from __future__ import annotations

import struct
import zlib

from warp2.corpus.kinds.framing import apart, joined

SIGNATURE = b"\x89PNG\r\n\x1a\n"
IDAT = b"IDAT"
HEAD = struct.Struct(">I4s")   # a chunk's length and its four letters


def chunks_of(raw) -> list | None:
    """Intention: the chunks (letters, data) in order, or None when the file is not a whole PNG whose checks hold."""
    raw = memoryview(raw).cast("B")
    if bytes(raw[:len(SIGNATURE)]) != SIGNATURE:
        return None
    found, at = [], len(SIGNATURE)
    while at < len(raw):
        if at + HEAD.size + 4 > len(raw):
            return None
        length, letters = HEAD.unpack_from(raw, at)
        end = at + HEAD.size + length
        if end + 4 > len(raw):
            return None
        data = bytes(raw[at + HEAD.size:end])
        if zlib.crc32(letters + data) != int.from_bytes(raw[end:end + 4], "big"):
            return None
        found.append((letters, data))
        at = end + 4
    return found


def made(chunks) -> bytes:
    """Intention: the PNG file from its chunks, each with its length and its check worked out again."""
    out = [SIGNATURE]
    for letters, data in chunks:
        out.append(HEAD.pack(len(data), letters) + data + zlib.crc32(letters + data).to_bytes(4, "big"))
    return b"".join(out)


def layout_of(chunks) -> tuple:
    """Intention: (the layout, the picture's stream): every chunk but IDAT kept whole; each IDAT only by its length,
    its data being a piece of the one stream, in order."""
    pieces, stream = [], []
    for letters, data in chunks:
        if letters == IDAT:
            pieces += [letters, b"I" + len(data).to_bytes(8, "big")]
            stream.append(data)
        else:
            pieces += [letters, b"C" + data]
    return joined(pieces), b"".join(stream)


def from_layout(layout, stream: bytes) -> list:
    """Intention: the chunks again - every IDAT given its piece of the stream, in order; the stream must be used up."""
    pieces = apart(layout)
    if len(pieces) % 2:
        raise ValueError("a PNG layout holds a chunk with no data")
    chunks, at = [], 0
    for letters, kept in zip(pieces[0::2], pieces[1::2]):
        if kept[:1] == b"I":
            length = int.from_bytes(kept[1:], "big")
            chunks.append((letters, stream[at:at + length]))
            at += length
        else:
            chunks.append((letters, kept[1:]))
    if at != len(stream):
        raise ValueError("the picture's stream does not fill the IDAT chunks it was cut into")
    return chunks
