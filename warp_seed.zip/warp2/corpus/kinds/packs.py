# WARP2/warp2/corpus/kinds/packs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/kinds/packs.py
#  Used by   : warp2/corpus/kinds/keep.py; tests/.
#  Uses      : (stdlib) json, os, pathlib.
#  Description:
#    WHERE ONE COLLECTION'S KEPT FILES LIVE: state/corpus/kinds/<collection>/
#    - pack files (pack-0001.bin, ...) holding the kept forms one after
#    another, and index.jsonl, one line a file kept: its name (from the
#    state), the pack and place of its form, the way, its kind, the write
#    time and size it had, and its sha256. Each turn writes its own new pack
#    (its number claimed by one writer only), so no pack has a set size and
#    no two runs write the same one. A form is on the disk (flushed and
#    synced) before its line is written, so a line never points at bytes
#    that are not there; a pack's tail with no line is only bytes no one
#    reads. A file kept again later has a newer line; the last line of a
#    name is the one that holds. How many bytes are no longer pointed at is
#    counted (`dead`), so it can be seen.
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything";
#    2026-11-14 17:06: "for storage we should store the file as a binary".
#    BUILD_LOG 1652c.
# ============================================================================
"""One collection's kept files: packs of kept forms and an index of where each file's form is."""
from __future__ import annotations

import json
import os
from pathlib import Path

INDEX = "index.jsonl"


class Packs:
    """Intention: one collection's packs and index, the index read once and kept up to date as files are added."""

    def __init__(self, folder) -> None:
        """Intention: the collection's folder (made when the first form is written)."""
        self.folder = Path(folder)
        self._index: dict | None = None
        self._dead = 0
        self._writing = None
        self._pack = ""

    def index(self) -> dict:
        """Intention: every file kept here by its name -> its newest line; lines that do not read are passed over."""
        if self._index is None:
            found, dead = {}, 0
            path = self.folder / INDEX
            if path.is_file():
                with path.open("r", encoding="utf-8") as lines:
                    for line in lines:
                        try:
                            entry = json.loads(line)
                        except ValueError:  # fault: ok a line cut short by a stop mid-write; its form is read by no one
                            continue
                        if entry.get("name") in found:
                            dead += int(found[entry["name"]].get("n", 0))
                        found[entry.get("name")] = entry
            self._index, self._dead = found, dead
        return self._index

    def entry(self, name: str) -> dict | None:
        """Intention: the newest line for this file, or None when it was never kept here."""
        return self.index().get(name)

    def held(self, name: str, seen: int) -> bool:
        """Intention: whether this file is kept here as it is now (`seen`: its write time from the listing)."""
        entry = self.entry(name)
        return entry is not None and int(entry.get("stamp", -1)) == int(seen)

    def dead(self) -> int:
        """Intention: the bytes in the packs that no line points at any more (forms of files kept again since)."""
        self.index()
        return self._dead

    def add(self, name: str, kind: str, way: int, kept: bytes, stamp: int, size: int, sha: str) -> dict:
        """Intention: one kept form put at the end of this turn's pack, synced, then its line written; its line."""
        handle = self._open()
        at = handle.tell()
        handle.write(kept)
        handle.flush()
        os.fsync(handle.fileno())
        entry = {"name": name, "pack": self._pack, "at": at, "n": len(kept), "way": int(way), "kind": kind,
                 "stamp": int(stamp), "size": int(size), "sha": sha}
        with (self.folder / INDEX).open("a", encoding="utf-8") as lines:
            lines.write(json.dumps(entry, separators=(",", ":")) + "\n")
        before = self.index().get(name)
        if before is not None:
            self._dead += int(before.get("n", 0))
        self.index()[name] = entry
        return entry

    def read(self, name: str) -> bytes:
        """Intention: a file's kept form, exactly as written; a file not kept here is said."""
        entry = self.entry(name)
        if entry is None:
            raise KeyError(name)
        with (self.folder / entry["pack"]).open("rb") as pack:
            pack.seek(int(entry["at"]))
            kept = pack.read(int(entry["n"]))
        if len(kept) != int(entry["n"]):
            raise ValueError(f"{name}: its pack ends before its form does")
        return kept

    def _open(self):
        """Intention: this turn's pack, opened for writing the first time a form is added - a new number, claimed."""
        if self._writing is None:
            self.folder.mkdir(parents=True, exist_ok=True)
            number = len(list(self.folder.glob("pack-*.bin"))) + 1
            while True:
                path = self.folder / f"pack-{number:04d}.bin"
                try:
                    self._writing = open(path, "xb")
                    break
                except FileExistsError:  # fault: ok another writer holds this number; the next is tried
                    number += 1
            self._pack = path.name
        return self._writing

    def close(self) -> None:
        """Intention: this turn's pack closed (everything in it is already synced)."""
        if self._writing is not None:
            self._writing.close()
            self._writing = None
