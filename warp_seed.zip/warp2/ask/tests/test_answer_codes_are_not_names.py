# WARP2/warp2/ask/tests/test_answer_codes_are_not_names.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_answer_codes_are_not_names.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/subconcepts.py (AnswerNames).
#  Description:
#    A model that answers with an inside code ("#decide:_gate_accepts:_accept",
#    "#types_of_dam", "#") gives no sub-concept names; words around it still do.
#    On the old reader "decide" became a part of planet earth and of lightship,
#    and "blocks" a part of night and dam (state/visual_learning/
#    subconcept_guesses.json, seen 2026-11-20).
#  User intention (Andrew, muse-476, 2026-10-23): the models guess sub-concepts
#    from "just what is it questions" - names they say, not labels. BUILD_LOG 2150.
# ============================================================================
from __future__ import annotations

from warp2.ask.subconcepts import AnswerNames


def test_a_code_answer_gives_no_names():
    """Intention: the codes seen in the guess book give nothing."""
    reader = AnswerNames()
    for said in ("#decide:_gate_accepts:_accept", "#blocks:_fleet:_wrong", "#types_of_dam", "#", "#lightship"):
        assert reader.read(said, "planet earth") == [], said


def test_words_beside_a_code_are_still_read():
    """Intention: only the coded piece is passed over; plain names in the same answer are kept."""
    reader = AnswerNames()
    assert reader.read("1. Equator\n#blocks:_fleet:_wrong\n2. North pole", "sphere") == ["equator", "north pole"]
