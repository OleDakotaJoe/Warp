# WARP3/warp2/control/tests/test_a_listed_runner_reads_alive.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/control/tests/test_a_listed_runner_reads_alive.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/control/status.py (status, _powershell, identity).
#  Description:
#    A runner whose pid is in the status answer's own process list reads
#    alive, even when the separate start-time ask does not answer
#    (BUILD_LOG 1958). Measured 2026-11-18 17:52 UTC: both lanes beat fresh,
#    both were listed, and the warp still read "critical".
#  User intention (Andrew, 2026-10-02): Claude runs the warp alone while he is
#    away - and needs to see what a person at the machine would see.
# ============================================================================
"""Tests that a listed, beating runner is reported alive and healthy."""
from __future__ import annotations

import time

from warp2.control import status
from warp2.record import processes


def _state(tmp_path, runner_pid, web_pid):
    """Intention: a state folder with fresh beats for both lanes and the run marked expected."""
    state = tmp_path / "state"
    (state / "lanes").mkdir(parents=True)
    (state / "control").mkdir(parents=True)
    (state / "lanes" / "card.beat").write_text(f"{runner_pid} {time.time()}", encoding="utf-8")
    (state / "lanes" / "web.beat").write_text(f"{web_pid} {time.time()}", encoding="utf-8")
    (state / "control" / "run.expected").write_text("", encoding="utf-8")
    return state


def _fake(listed):
    """Intention: PowerShell answers with the given python pids; the others list is empty."""
    def fake(script):
        if "Win32_OperatingSystem" in script:
            return {"FreePhysicalMemory": 1024, "TotalVisibleMemorySize": 2048,
                    "FreeVirtualMemory": 1024, "TotalVirtualMemorySize": 4096}
        if "-notmatch" in script or "CreationDate" in script:
            return []
        return [{"ProcessId": pid, "ParentProcessId": 1, "WorkingSetSize": 0,
                 "PrivatePageCount": 0, "CommandLine": "python"} for pid in listed]
    return fake


def test_a_listed_runner_reads_alive_when_the_start_time_ask_fails(tmp_path, monkeypatch):
    """Intention: the old code said critical here; the listed pids settle alive."""
    state = _state(tmp_path, 14960, 14936)
    monkeypatch.setattr(status, "_powershell", _fake([14960, 14936]))
    monkeypatch.setattr(processes, "identity", lambda pid: None)
    work = status.status(state)["workload"]
    assert work["runner"]["alive"] is True and work["web"]["alive"] is True
    assert work["overall"] in ("healthy", "overdue")


def test_a_runner_missing_from_the_list_and_unknown_reads_dead(tmp_path, monkeypatch):
    """Intention: not listed and no start time means not alive - the fix does not hide a dead runner."""
    state = _state(tmp_path, 14960, 14936)
    monkeypatch.setattr(status, "_powershell", _fake([999]))
    monkeypatch.setattr(processes, "identity", lambda pid: None)
    work = status.status(state)["workload"]
    assert work["runner"]["alive"] is False and work["overall"] == "critical"
