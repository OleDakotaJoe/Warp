# WARP3/warp2/control/tests/test_a_long_main_step_reads_overdue.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/control/tests/test_a_long_main_step_reads_overdue.py
#  Used by   : run_tests.py, CHECK_FIXES.bat.
#  Uses      : warp2/control/overdue.py (step_in_flight, next_main_verb),
#              warp2/record/deadline.py (the deadlines file's shape); (stdlib)
#              json, os, time, pathlib, tempfile, unittest.
#  Description:
#    BUILD_LOG 1961. On 2026-11-18 the main lane's do_work ran 6720 s against
#    a usual 3548 s while status said "healthy": only side steps were timed.
#    Now, when no side step started after the journal's last line, the verb
#    that has most often followed the last verb is the step in flight, and it
#    is timed by its own measured budget.
#  User intention (Andrew, 2026-10-31: "I want you to fix everything that is
#    wrong").
# ============================================================================
from __future__ import annotations

import json
import os
import tempfile
import time
import unittest
from pathlib import Path

from warp2.control.overdue import next_main_verb, step_in_flight


class LongMainStepReadsOverdue(unittest.TestCase):
    """A main-lane step far past its own usual time reads overdue; a habit-less journal names nothing."""

    def _state(self, verbs: list, since_ago: float) -> Path:
        """Intention: a state with a journal of these verbs, last written `since_ago` seconds back, and a measured
        do_work budget of 100 s (mean 60, spread 10, times 4)."""
        state = Path(tempfile.mkdtemp())
        (state / "journals").mkdir()
        journal = state / "journals" / "continuous.jsonl"
        journal.write_text("".join(json.dumps({"verb": v, "seq": i}) + "\n" for i, v in enumerate(verbs)),
                           encoding="utf-8")
        then = time.time() - since_ago
        os.utime(journal, (then, then))
        (state / "deadlines.json").write_text(json.dumps(
            {"do_work": {"mean": 60.0, "spread": 10.0, "n": 50, "max": 120.0}}), encoding="utf-8")
        return state

    def test_main_step_past_its_budget_is_overdue(self) -> None:
        """Intention: the old code said verb None and never overdue for this; the new one names do_work, overdue."""
        state = self._state(["build_context", "do_work", "record_kg_lookups"] * 5 + ["build_context"], 500)
        step = step_in_flight(state)
        self.assertEqual(step.get("verb"), "do_work")
        self.assertEqual(step.get("lane"), "main")
        self.assertTrue(step.get("overdue"))

    def test_main_step_inside_its_budget_is_not_overdue(self) -> None:
        """Intention: a main step still inside its usual time is named, not called overdue."""
        state = self._state(["build_context", "do_work"] * 5 + ["build_context"], 20)
        step = step_in_flight(state)
        self.assertEqual(step.get("verb"), "do_work")
        self.assertFalse(step.get("overdue"))

    def test_no_habit_names_nothing(self) -> None:
        """Intention: when no verb follows the last one more than half the time, nothing is guessed."""
        state = self._state(["a", "b", "a", "c", "a", "d", "a"], 500)
        self.assertIsNone(next_main_verb(state / "journals" / "continuous.jsonl"))
        self.assertFalse(step_in_flight(state).get("overdue"))


if __name__ == "__main__":
    unittest.main()
