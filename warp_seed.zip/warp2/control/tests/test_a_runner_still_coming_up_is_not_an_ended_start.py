# WARP3/warp2/control/tests/test_a_runner_still_coming_up_is_not_an_ended_start.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/control/tests/test_a_runner_still_coming_up_is_not_an_ended_start.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/control/restart.py (Restart, RUNNER_COMMANDS),
#              warp2/control/windows.py (WindowsHands.launcher_of, with its
#              process look stood in for - no process is touched).
#  Description:
#    BUILD_LOG 2164. (1) A start whose gate has ended but whose runner is
#    still opening its session is waited for and answered "restarted", not
#    "start_ended_no_beat" (restart.last.json 2026-11-21 21:49 CST said the
#    second for a good restart). A start with no gate and no runner is still
#    seen to have ended. (2) The bat loop is found when it is WARP3.bat.
#  User intention (Andrew, 2026-10-02): a restart Claude can trust to do alone.
# ============================================================================
from __future__ import annotations

from warp2.control.restart import RUNNER_COMMANDS, WAIT_STARTED, Restart
from warp2.control.windows import WindowsHands


class Clock:
    """Intention: time that moves only when slept, so waits are instant and exact."""

    def __init__(self):
        """Intention: start at zero."""
        self.now = 0.0

    def __call__(self):
        """Intention: the time now."""
        return self.now

    def sleep(self, seconds):
        """Intention: move time on."""
        self.now += seconds


class ComingUpHands:
    """Intention: a pretend Windows with no old warp; the launched start's gate ends at once, its runner beats late."""

    def __init__(self, state, clock, runner_beats_at=None):
        """Intention: the runner process is there from the launch and beats at `runner_beats_at` (None: never there)."""
        self.state, self.clock, self.runner_beats_at = state, clock, runner_beats_at
        self.launched = False

    def registered(self):
        """Intention: no old runner or lane."""
        return []

    def by_command(self, fragments):
        """Intention: the new runner process, when asked for runners and it is there; nothing else."""
        if self.launched and self.runner_beats_at is not None and any(f in RUNNER_COMMANDS for f in fragments):
            if self.clock() >= self.runner_beats_at:
                (self.state / "lanes" / "card.beat").write_text("99 1.0")
            return [99]
        return []

    def starting(self):
        """Intention: the gate has already passed."""
        return []

    def launcher_of(self, pid):
        """Intention: no loop."""
        return None

    def alive(self, pid):
        """Intention: nothing old is alive."""
        return False

    def end(self, pid, force, tree):
        """Intention: nothing to end."""
        return ""

    def launch(self, root, *, headless=False):
        """Intention: the start is launched."""
        self.launched = True
        return 77


def _state(tmp_path, monkeypatch):
    """Intention: a state folder with no beats yet."""
    monkeypatch.setenv("WARP3_RUNTIME_DIR", str(tmp_path / "runtime"))
    monkeypatch.setenv("WARP2_RUNTIME_DIR", str(tmp_path / "runtime"))
    state = tmp_path / "state"
    (state / "lanes").mkdir(parents=True)
    return state


def test_a_runner_opening_its_session_is_waited_for(tmp_path, monkeypatch):
    """Intention: gate passed, runner there and beating at 500 s - the answer is "restarted"."""
    state = _state(tmp_path, monkeypatch)
    clock = Clock()
    hands = ComingUpHands(state, clock, runner_beats_at=500.0)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "test", "automatic": True})
    assert said["outcome"] == "restarted"
    assert not any(step["step"] == "start_ended" for step in said["steps"])


def test_no_gate_and_no_runner_is_still_an_ended_start(tmp_path, monkeypatch):
    """Intention: nothing left of the start - it is seen to have ended well inside the wait."""
    state = _state(tmp_path, monkeypatch)
    clock = Clock()
    hands = ComingUpHands(state, clock, runner_beats_at=None)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "test", "automatic": True})
    assert said["outcome"] == "start_ended_no_beat"
    assert clock.now < 200.0 < WAIT_STARTED


def test_the_loop_of_warp3_bat_is_found(monkeypatch):
    """Intention: runner <- py.exe <- cmd.exe running WARP3.bat: that cmd is the loop."""
    tree = {
        11: {"ProcessId": 11, "ParentProcessId": 12, "Name": "python.exe", "CommandLine": "python -B -m warp2.run go"},
        12: {"ProcessId": 12, "ParentProcessId": 13, "Name": "cmd.exe",
             "CommandLine": 'C:\\WINDOWS\\system32\\cmd.exe /c ""C:\\Users\\x\\APEX\\WARP3\\WARP3.bat" "'},
    }
    monkeypatch.setattr(WindowsHands, "_process", lambda self, pid: tree.get(int(pid)))
    assert WindowsHands().launcher_of(11) == 12
