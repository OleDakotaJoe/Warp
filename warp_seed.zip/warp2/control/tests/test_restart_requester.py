# Pathway: warp2/control/tests/test_restart_requester.py
# Used by: pytest; CHECK_FIXES.bat.
# Uses: control restart/supervisor/watcher; stand-in hands and clocks.
# Description: requester identity survives success, refusal and failed handling.
# User intention: restart attribution without guessing; codex-480.
import json
import pytest
from warp2.control.tests.test_restart import _setup, Clock, Hands
from warp2.control.restart import Restart
from warp2.control.files import ControlFiles


@pytest.mark.parametrize("who", ["Codex", None])
def test_restart_records_the_stated_requester_or_unknown(tmp_path, monkeypatch, who):
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    hands = Hands(state, runner_quits_after=30, clock=clock)
    answer = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why":"test", "who":who})
    assert answer["who"] == who
    assert json.loads(ControlFiles(state).last.read_text())["who"] == who


def test_supervisor_names_its_own_request(tmp_path, monkeypatch):
    from warp2.control.supervisor import RunnerSupervisor, MISSING_OBSERVATIONS
    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state); files.ready(); files.expected.write_text("expected")
    hands = Hands(state); hands.live.clear()
    clock = Clock(); clock.now = 1000
    supervisor = RunnerSupervisor(clock=clock)
    for _ in range(MISSING_OBSERVATIONS):
        request = supervisor.observe(files, hands)
    assert request["who"] == "supervisor"


def test_failed_request_keeps_its_asker(tmp_path, monkeypatch):
    from warp2.control.watcher import watch
    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state); files.ready()
    files.request.write_text(json.dumps({"who":"Claude", "why":"test"}))
    def fail(self, asked):
        raise RuntimeError("test failure")
    monkeypatch.setattr(Restart, "run", fail)
    assert watch(tmp_path, once=True) == 0
    assert json.loads(files.last.read_text())["who"] == "Claude"
