# WARP3/warp2/house/held_small/tests/test_an_answer_reads_each_weight_once_while_there_is_room.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/house/held_small/tests/test_an_answer_reads_each_weight_once_while_there_is_room.py
#  Used by   : CHECK_FIXES.bat; pytest.
#  Uses      : warp2/house/held_small/book_linear.py (BookLinear, held_for_an_answer); torch.
#  Description:
#    BUILD_LOG 1951h. A BookLinear read its weight off the book for every token, so one qwen3-1.7b answer took
#    4,000-5,000 s (61% reading pages, 28% copying to the card - py-spy, 2026-11-20 00:59 UTC). Inside
#    held_for_an_answer a weight is read once and held while the device keeps half the room it began with; with
#    no room it is read each time as before; everything is let go when the answer ends; the answer is the same.
#  User intention (Andrew, 2026-11-11 18:40): "the important thing is that ours are faster than normal files".
#    2026-11-09 18:37: "If it has more, it needs to adjust to that."
# ============================================================================
"""Inside one answer a book-backed layer reads its weight once while there is room; outside, every time."""
import torch

from warp2.house.held_small.book_linear import BookLinear, held_for_an_answer


class CountingDoor:
    """Intention: a book door that gives a fixed weight and counts how often it is asked."""

    def __init__(self, weight) -> None:
        """Intention: the weight to give back; no reads yet."""
        self.weight, self.reads = weight, 0

    def tensor(self, kept):
        """Intention: the weight, counted."""
        self.reads += 1
        return self.weight.clone()


def _layer():
    """Intention: one book-backed 4x3 layer with its counting door."""
    torch.manual_seed(0)
    ordinary = torch.nn.Linear(3, 4)
    door = CountingDoor(ordinary.weight.detach().clone())
    return BookLinear(door, {"place": "x"}, ordinary, torch.float32, "cpu"), door, ordinary


def test_a_weight_is_read_once_in_an_answer_with_room():
    layer, door, ordinary = _layer()
    x = torch.randn(2, 3)
    with torch.no_grad(), held_for_an_answer(layer, room=lambda device: 10 ** 9):
        outs = [layer(x) for _ in range(5)]
    assert door.reads == 1
    for out in outs:
        assert torch.equal(out, ordinary(x).detach())


def test_with_no_room_the_weight_is_read_every_time():
    layer, door, _ = _layer()
    rooms = iter([1000] + [400] * 10)   # starts with 1000 bytes; then 400, under the floor of 500 with a 48-byte weight
    with torch.no_grad(), held_for_an_answer(layer, room=lambda device: next(rooms)):
        for _ in range(3):
            layer(torch.randn(1, 3))
    assert door.reads == 3


def test_everything_held_is_let_go_after_the_answer_and_outside_it_nothing_is_held():
    layer, door, _ = _layer()
    with torch.no_grad(), held_for_an_answer(layer, room=lambda device: 10 ** 9):
        layer(torch.randn(1, 3))
    assert layer.held is None and layer.hold is None
    layer(torch.randn(1, 3))
    layer(torch.randn(1, 3))
    assert door.reads == 3


def test_a_room_that_cannot_be_read_holds_nothing():
    layer, door, _ = _layer()
    with torch.no_grad(), held_for_an_answer(layer, room=lambda device: None):
        layer(torch.randn(1, 3))
        layer(torch.randn(1, 3))
    assert door.reads == 2
