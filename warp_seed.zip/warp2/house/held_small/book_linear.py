# WARP3/warp2/house/held_small/book_linear.py
#
# Pathway   : warp2/house/held_small/book_linear.py
# Used by   : house/held_small/small_fill.py for exact forms without row arithmetic.
# Uses      : torch; the tensor-book door supplied by the loader.
# Description: A frozen linear base reads its exact stored operand only while computing; backward reads it again.
# User intention: Andrew, 2026-11-19: stored parts remain remembered and the working footprint stays small.
# BUILD_LOG 1951h (Claude, hourly run, 2026-11-20): WHILE ONE ANSWER IS BEING MADE, A WEIGHT ONCE READ IS KEPT
#   ON ITS DEVICE, AS FAR AS THE ROOM GOES. Measured 2026-11-20 00:59 UTC (py-spy, state/control/commands/out/
#   house_raw_0110.txt): of the house's time on a qwen3-1.7b answer, 61% was reading each layer's bytes off the
#   book's pages and 28% putting them on the card - again for every token - so answers of usually 71 s took
#   4,000-5,000 s and the main lane waited hours. Now `held_for_an_answer(model)` holds each weight it reads for
#   the rest of that answer while the device keeps at least half the room it had when the answer began (the
#   room the device has, not a set number); every held weight is let go when the answer ends. Between answers,
#   and in training (backward), nothing is held - as before.
#   Andrew 2026-11-10 20:09: "This should dramaticly shorten everything that uses them in the time they take."
#   2026-11-11 18:40: "the important thing is that ours are faster than normal files".
#   2026-11-09 18:37: "if it doesn't have enough, it needs to adjust. If it has more, it needs to adjust to that."
"""A linear layer backed by its exact book form, without a persistent dense weight."""
from __future__ import annotations

from contextlib import contextmanager

import torch


def room_on(device) -> int | None:
    """Intention: the bytes free on a device now - the card's own count, or the machine's free memory; None when
    it cannot be read (then nothing is held)."""
    device = torch.device(device)
    try:
        if device.type == "cuda":
            return int(torch.cuda.mem_get_info(device)[0])
        import psutil
        return int(psutil.virtual_memory().available)
    except Exception:  # fault: ok - a room that cannot be read holds nothing; the layer reads its weight each time
        return None


class AnswerHold:
    """Intention: the weights held during one answer, and the room each device must keep - half its room at the
    start."""

    def __init__(self, room=room_on) -> None:
        """Intention: nothing held; the room reader is given so a test can say the room."""
        self.room, self.floor, self.layers = room, {}, []

    def keeps(self, device, size: int) -> bool:
        """Intention: whether a weight of `size` bytes may be held on `device` and leave it its floor."""
        key = str(torch.device(device))
        if key not in self.floor:
            start = self.room(device)
            self.floor[key] = None if start is None else start // 2
        floor, now = self.floor[key], self.room(device)
        return floor is not None and now is not None and now - int(size) >= floor

    def let_go(self) -> None:
        """Intention: every weight held for this answer let go."""
        for layer in self.layers:
            layer.held = None
        self.layers = []


@contextmanager
def held_for_an_answer(model, room=room_on):
    """Intention: during the `with`, each BookLinear in `model` keeps the weight it read while there is room; all
    let go at the end, whatever happened."""
    hold = AnswerHold(room)
    layers = [m for m in model.modules() if isinstance(m, BookLinear)] if model is not None else []
    for layer in layers:
        layer.hold, layer.held = hold, None
    try:
        yield hold
    finally:
        hold.let_go()
        for layer in layers:
            layer.hold = None


class _LinearFromBook(torch.autograd.Function):
    """Intention: backward retains a book reference, not every expanded base weight in the model."""

    @staticmethod
    def forward(ctx, inputs, layer):
        """Intention: the exact ordinary linear operation, with only this layer's weight reconstructed."""
        ctx.layer = layer
        ctx.device_type = inputs.device.type
        ctx.autocast_enabled = torch.is_autocast_enabled(ctx.device_type)
        ctx.autocast_dtype = torch.get_autocast_dtype(ctx.device_type)
        return torch.nn.functional.linear(inputs, layer.weight)

    @staticmethod
    def backward(ctx, gradient):
        """Intention: propagate the same input gradient through a frozen base without retaining its dense weight."""
        with torch.autocast(ctx.device_type, enabled=ctx.autocast_enabled, dtype=ctx.autocast_dtype):
            return torch.matmul(gradient, ctx.layer.weight), None


class BookLinear(torch.nn.Linear):
    """Intention: keep the tensor's book reference and reconstruct only the current arithmetic operand."""

    def __init__(self, door, kept: dict, ordinary, kind, device) -> None:
        """Intention: the same linear contract and bias, with a zero-sized device marker instead of base weights."""
        torch.nn.Module.__init__(self)
        self.door, self.reference = door, kept
        self.in_features, self.out_features = ordinary.in_features, ordinary.out_features
        self.bias = ordinary.bias
        self.register_buffer('_location', torch.empty(0, dtype=kind, device=device), persistent=False)
        self.hold = self.held = None   # BUILD_LOG 1951h: set only inside held_for_an_answer

    @property
    def weight(self):
        """Intention: exact values from the stored form, on this layer's current device; never cached whole - except
        held for the rest of one answer while the device has room (BUILD_LOG 1951h)."""
        held = getattr(self, "held", None)
        if held is not None:
            return held
        weight = self.door.tensor(self.reference).to(device=self._location.device, dtype=self._location.dtype)
        hold = getattr(self, "hold", None)
        if hold is not None and hold.keeps(weight.device, weight.numel() * weight.element_size()):
            self.held = weight
            hold.layers.append(self)
        return weight

    def forward(self, inputs):
        """Intention: inference and adapter training use the stored base without holding expanded weights for backward."""
        result = _LinearFromBook.apply(inputs, self)
        return result if self.bias is None else result + self.bias

    def _save_to_state_dict(self, destination, prefix, keep_vars):
        """Intention: explicit model checkpoints still contain every original weight with its ordinary name."""
        super()._save_to_state_dict(destination, prefix, keep_vars)
        destination[prefix + 'weight'] = self.weight
