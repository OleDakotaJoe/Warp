# WARP2/warp2/house/held_small/book_linear.py
#
# Pathway   : warp2/house/held_small/book_linear.py
# Used by   : house/held_small/small_fill.py for exact forms without row arithmetic.
# Uses      : torch; the tensor-book door supplied by the loader.
# Description: A frozen linear base reads its exact stored operand only while computing; backward reads it again.
# User intention: Andrew, 2026-11-19: stored parts remain remembered and the working footprint stays small.
"""A linear layer backed by its exact book form, without a persistent dense weight."""
from __future__ import annotations

import torch


class _LinearFromBook(torch.autograd.Function):
    """Intention: backward retains a book reference, not every expanded base weight in the model."""

    @staticmethod
    def forward(ctx, inputs, layer):
        """Intention: the exact ordinary linear operation, with only this layer's weight reconstructed."""
        ctx.layer = layer
        ctx.device_type = inputs.device.type
        ctx.autocast_enabled = torch.is_autocast_enabled(ctx.device_type)
        ctx.autocast_dtype = torch.get_autocast_dtype(ctx.device_type)
        return torch.nn.functional.linear(inputs, layer.weight)

    @staticmethod
    def backward(ctx, gradient):
        """Intention: propagate the same input gradient through a frozen base without retaining its dense weight."""
        with torch.autocast(ctx.device_type, enabled=ctx.autocast_enabled, dtype=ctx.autocast_dtype):
            return torch.matmul(gradient, ctx.layer.weight), None


class BookLinear(torch.nn.Linear):
    """Intention: keep the tensor's book reference and reconstruct only the current arithmetic operand."""

    def __init__(self, door, kept: dict, ordinary, kind, device) -> None:
        """Intention: the same linear contract and bias, with a zero-sized device marker instead of base weights."""
        torch.nn.Module.__init__(self)
        self.door, self.reference = door, kept
        self.in_features, self.out_features = ordinary.in_features, ordinary.out_features
        self.bias = ordinary.bias
        self.register_buffer('_location', torch.empty(0, dtype=kind, device=device), persistent=False)

    @property
    def weight(self):
        """Intention: exact values from the stored form, on this layer's current device; never cached whole."""
        return self.door.tensor(self.reference).to(device=self._location.device, dtype=self._location.dtype)

    def forward(self, inputs):
        """Intention: inference and adapter training use the stored base without holding expanded weights for backward."""
        result = _LinearFromBook.apply(inputs, self)
        return result if self.bias is None else result + self.bias

    def _save_to_state_dict(self, destination, prefix, keep_vars):
        """Intention: explicit model checkpoints still contain every original weight with its ordinary name."""
        super()._save_to_state_dict(destination, prefix, keep_vars)
        destination[prefix + 'weight'] = self.weight
