# Pathway: warp2/house/tests/owned_house.py
# Used by: failed-start house test and test_test_house_processes_are_owned.py.
# Uses: contextlib, subprocess, HouseClient; existing cancellation grace.
# Description: reap exact process handles started by one test on every exit path.
# User intention: prevent test service leftovers without touching live services; codex-483.
from contextlib import contextmanager, ExitStack
import subprocess
from warp2.house.client import HouseClient
from warp2.record.supervisor import GRACE_SECONDS


def _reap(process):
    """Only a Popen handle captured by this test is eligible for cleanup."""
    if process.poll() is None:
        process.terminate()
    try:
        process.wait(timeout=GRACE_SECONDS)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


@contextmanager
def owned_house_processes(monkeypatch):
    """Restore the launch method and reap owned processes even after assertion failure."""
    spawn = HouseClient._spawn
    with monkeypatch.context() as patch, ExitStack() as cleanup:
        def owned(self, log):
            process = spawn(self, log)
            cleanup.callback(_reap, process)
            return process
        patch.setattr(HouseClient, "_spawn", owned)
        yield
