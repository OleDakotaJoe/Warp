# Pathway: warp2/house/tests/test_test_house_processes_are_owned.py
# Used by: pytest; CHECK_FIXES.bat.
# Uses: tests.owned_house, HouseClient, stand-in process handles.
# Description: a failed test reaps only servers it started.
# User intention: keep test services from outliving failed assertions; codex-483.
import subprocess
import pytest
from warp2.house.client import HouseClient


class Process:
    def __init__(self, ended=False, slow=False):
        self.ended, self.slow, self.calls = ended, slow, []

    def poll(self):
        return 0 if self.ended else None

    def terminate(self):
        self.calls.append("terminate")

    def kill(self):
        self.calls.append("kill")
        self.ended = True

    def wait(self, timeout=None):
        self.calls.append("wait")
        if self.slow:
            self.slow = False
            raise subprocess.TimeoutExpired("owned fake house", timeout)
        self.ended = True
        return 0


def test_failed_assertion_reaps_only_the_process_this_test_started(monkeypatch, tmp_path):
    from warp2.house.tests.owned_house import owned_house_processes
    mine, unrelated = Process(), Process()
    monkeypatch.setattr(HouseClient, "_spawn", lambda self, log: mine)
    with pytest.raises(AssertionError, match="unexpected success"):
        with owned_house_processes(monkeypatch):
            HouseClient(tmp_path, tmp_path)._spawn(None)
            raise AssertionError("unexpected success")
    assert mine.calls == ["terminate", "wait"]
    assert unrelated.calls == []


def test_already_ended_process_is_reaped_without_signals(monkeypatch, tmp_path):
    from warp2.house.tests.owned_house import owned_house_processes
    mine = Process(ended=True)
    monkeypatch.setattr(HouseClient, "_spawn", lambda self, log: mine)
    with owned_house_processes(monkeypatch):
        HouseClient(tmp_path, tmp_path)._spawn(None)
    assert mine.calls == ["wait"]


def test_unresponsive_owned_process_is_reaped_after_termination_grace(monkeypatch, tmp_path):
    from warp2.house.tests.owned_house import owned_house_processes
    mine = Process(slow=True)
    monkeypatch.setattr(HouseClient, "_spawn", lambda self, log: mine)
    with owned_house_processes(monkeypatch):
        HouseClient(tmp_path, tmp_path)._spawn(None)
    assert mine.calls == ["terminate", "wait", "kill", "wait"]
