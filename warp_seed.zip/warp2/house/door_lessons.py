# WARP2/warp2/house/door_lessons.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/door_lessons.py
#  Used by   : warp2/house/tag_lessons.py (the house models' lessons).
#  Uses      : warp2/train/outputs.py (every answer any model gave, kept with
#              what it was asked), warp2/models/tag_door.py (as_answer_tags),
#              warp2/record/evidence.py, warp2/store/store.py (store_home:
#              where the kept bytes are).
#  Description:
#    THE LORAS TEACH THE MODELS TO WORK IN DEHYDRATED TAGS. Every model the
#    warp asks is asked in dehydrated tags and only its tags are taken
#    (warp2/models/tag_door.py), and each exchange is kept as it went (kind
#    "door"). Each becomes a lesson: what the model was given (tags) in, and
#    the answer in the tag form it should take out - the model's own answer
#    when it was tags, its answer put into tags when it was not. The newest
#    exchanges are taken, so each turn's lessons are what the warp has most
#    lately asked.
#  User intention (Andrew, 2026-11-15 13:59): "That is the reason why the
#    [LoRAs] were put back in. It was not to make the models better. It was to
#    make the models work with the dehydrated tag system." (2026-11-09 19:05):
#    "add back in loras and training those new models to give adaptation to at
#    least run from compressed tags".
# ============================================================================
"""Lessons from every exchange the warp had with a model: tags in, tags out."""
from __future__ import annotations

import json
from pathlib import Path

# Intention: how far back from the end of the kept answers the lessons are read - the newest exchanges, a tail of
# the record (it grows for ever, and the tag LoRA takes only what is new each turn).
TAIL_BYTES = 4 * 2**20


def _tail_lines(path: Path) -> list:
    """Intention: the whole lines of the last TAIL_BYTES of a file."""
    try:
        size = path.stat().st_size
    except OSError:  # fault: ok no answers kept yet: no lessons
        return []
    with open(path, "rb") as handle:
        handle.seek(max(0, size - TAIL_BYTES))
        block = handle.read()
    lines = block.split(b"\n")
    return [line for line in (lines[1:] if size > TAIL_BYTES else lines) if line.strip()]


class DoorLessons:
    """Intention: the lessons the kept exchanges give."""

    def __init__(self, state) -> None:
        """Intention: the state folder whose kept answers (training/outputs.jsonl) are read."""
        self.state = Path(state)

    def lessons(self) -> list:
        """Intention: [{key, prompt, answer, kind}] - one for each kept exchange with something asked and answered."""
        from warp2.house.tag_lessons import key
        from warp2.models.tag_door import as_answer_tags
        from warp2.record.evidence import Evidence
        from warp2.store.store import store_home
        evidence = Evidence(store_home(self.state) / "evidence")
        out, seen = [], set()
        for line in _tail_lines(self.state / "training" / "outputs.jsonl"):
            try:
                row = json.loads(line)
            except ValueError:  # fault: ok a torn line at the cut is not a lesson
                continue
            if row.get("e") != "kept" or row.get("kind") != "door" or not row.get("prompt") or not row.get("answer"):
                continue
            try:
                asked, said = evidence.text(row["prompt"]), evidence.text(row["answer"])
            except (OSError, KeyError, ValueError):  # fault: ok an answer whose bytes are gone is not a lesson
                continue
            if not said.strip() or key(asked) in seen:
                continue
            seen.add(key(asked))
            out.append({"key": key(asked), "prompt": asked, "answer": as_answer_tags(said),
                        "kind": "tags to tags (door)"})
        return out
