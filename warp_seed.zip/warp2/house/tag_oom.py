# WARP2/warp2/house/tag_oom.py
# Used by tag_lora.py; tested by tests/test_a_house_oom_keeps_its_lesson.py.
# Uses torch CUDA counters, nvidia-smi, and record/kept_file.py.
"""Intention: retain evidence for receipt 19202's unaccounted CUDA OOM.

Measurements only: no retry, placement change, training input or memory policy.
"""
from datetime import datetime, timezone
import os


def memory(device):
    """Intention: timestamp measured device counters; CPU has no CUDA measurement."""
    import torch
    result = {"at": datetime.now(timezone.utc).isoformat(), "device": str(device), "cuda": None}
    if device.type == "cuda":
        try:
            free, total = torch.cuda.mem_get_info(device)
            result["cuda"] = {"allocated_bytes": torch.cuda.memory_allocated(device),
                              "reserved_bytes": torch.cuda.memory_reserved(device),
                              "free_bytes": free, "total_bytes": total}
        except RuntimeError as exc:
            result["cuda_error"] = f"{type(exc).__name__}: {exc}"
    return result


def processes():
    """Intention: error-time GPU process evidence; unavailable probes say why, never zero occupancy."""
    import subprocess
    result = {"at": datetime.now(timezone.utc).isoformat()}
    try:
        read = subprocess.run(["nvidia-smi", "--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory",
                               "--format=csv"], capture_output=True, text=True, check=True,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        result["csv"] = read.stdout
    except (OSError, subprocess.SubprocessError) as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def keep(lora, lesson, before_backward, device, error):
    """Intention: write one whole diagnostic per failed child, without lesson text or tensor contents."""
    from warp2.record.kept_file import write_kept
    result = {"at": datetime.now(timezone.utc).isoformat(), "pid": os.getpid(),
              "turn": getattr(lora, "_turn", None), "model": lora.entry["name"],
              "lesson": getattr(lora, "_oom_lesson", {"key": lesson["key"]}),
              "before_backward": before_backward, "at_error": memory(device),
              "gpu_processes_at_error": processes(), "error": f"{type(error).__name__}: {error}"}
    stamp = result["at"].replace(":", "-")
    write_kept(lora.state / "diagnostics" / "house_tag_oom" / f"{stamp}-{os.getpid()}.json", result)
