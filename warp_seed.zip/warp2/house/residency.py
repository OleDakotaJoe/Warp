# WARP2/warp2/house/residency.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/residency.py
#  Used by   : warp2/house/server.py (one line after every request it answers).
#  Uses      : warp2/house/keeper.py (own_bytes); stdlib json, os, time, pathlib.
#  Description:
#    THE HOUSE'S OWN RECORD OF WHAT IT HELD. After each request the house
#    writes one line to state/house/residency/<YYYY-MM-DD>.jsonl (UTC day):
#    when, what was asked (path and model), how it went (status), where the
#    model ran (the runner's own "where": CPU/GPU placement), every model
#    then held with its size and idle time, and the house process's working
#    set in MB. One file a day; nothing is ever overwritten or removed.
#    Each line also carries the house's own process id and the time the ask
#    came in beside the time it was answered, so a line can be tied to the
#    one house process and the one request it speaks for (BUILD_LOG 1974).
#    A line that cannot be written never stops the house from answering.
#  User intention (Andrew, 2026-10-16): get everything in working order.
#    The 17:57-18:55 UTC house growth to 15-20 GB on 2026-11-18 could not be
#    explained: no record said which model the house held, or where (Grok's
#    open question, carried by Muse-2021/2024). BUILD_LOG 1972.
# ============================================================================
"""One line per house request: what was asked, where it ran, what was held, how big the house was."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path


class Residency:
    """Writes the house's residency line for each request it answers."""

    def __init__(self, state, own=None, clock=time.time, pid=None) -> None:
        """Intention: the folder the lines go in, how the house's size is read, the clock, and whose house this is."""
        if own is None:
            from warp2.house.keeper import own_bytes
            own = own_bytes
        self.folder = Path(state) / "house" / "residency"
        self.own, self.clock = own, clock
        self.pid = int(os.getpid() if pid is None else pid)

    def file_for(self, at: float) -> Path:
        """Intention: the day's file (UTC), so no file grows without end and none is overwritten."""
        return self.folder / (time.strftime("%Y-%m-%d", time.gmtime(at)) + ".jsonl")

    def note(self, path: str, model: str, status: int, where, held: list, asked_at=None) -> bool:
        """Intention: one line for one answered request; False (and the house goes on) when it cannot be written.
        `at` is when it was answered, `asked_at` when the ask came in (None when not given), `pid` the house's own."""
        at = self.clock()
        line = {"at": round(at, 3), "when": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(at)),
                "asked_at": None if asked_at is None else round(float(asked_at), 3), "pid": self.pid,
                "path": str(path), "model": str(model or ""), "status": int(status),
                "where": where if isinstance(where, (str, int, float, list, dict, type(None))) else str(where),
                "held": list(held or []), "house_mb": round(int(self.own() or 0) / 2 ** 20, 1)}
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            with open(self.file_for(at), "a", encoding="utf-8") as out:
                out.write(json.dumps(line, default=str) + "\n")
            return True
        except Exception:  # fault: ok - a record that cannot be kept must not stop the house answering
            return False
