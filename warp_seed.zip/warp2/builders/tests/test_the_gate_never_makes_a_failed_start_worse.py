# WARP3/warp2/builders/tests/test_the_gate_never_makes_a_failed_start_worse.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/builders/tests/test_the_gate_never_makes_a_failed_start_worse.py
#  Used by   : pytest.
#  Uses      : warp2/builders/{triage,entries,last_good,scores}.py;
#              warp2/integrity/source_watch.py (SourceWatch);
#              warp2/builders/tests/test_builders_are_scored_and_set_aside_by_score.py (its scratch tree).
#  Description:
#    A failed start is never made worse by the triage: a set-aside that
#    leaves more tests failing, or tests that can no longer be gathered, is
#    put back at once, as it was, and the triage stops; the gate's counts are
#    read from its own output; an entry written in a builder's own series
#    ("## 1638c.") is read, and what came after the last good start is read
#    from where the log ended then, not from the numbers.
#  User intention (Andrew, 2026-11-14 12:41): "something happened to the warp
#    what it going on there"; (2026-09-18) "when fixing loose ends, build the
#    prevention into the system so they cannot recur". BUILD_LOG 1641c.
# ============================================================================
"""Intention: the gate's triage never leaves a failed start worse than it found it."""
from __future__ import annotations

import json

from warp2.builders.entries import LogEntries
from warp2.builders.last_good import LastGood
from warp2.builders.scores import Scores
from warp2.builders.tests.test_builders_are_scored_and_set_aside_by_score import LOG, _tree
from warp2.builders.triage import Attribution, Triage, gate_standing, worse


def _last_good_start(root, state) -> None:
    """Intention: a good start with both files kept, the log at entry 10, then the two builders' changes."""
    from warp2.integrity.source_watch import SourceWatch
    watch = SourceWatch(root, state)
    (root / "docs" / "BUILD_LOG.md").write_text(LOG.split("## 11.")[0], encoding="utf-8")
    (root / "warp2" / "a.py").write_text("A = 1\n", encoding="utf-8")
    (root / "warp2" / "b.py").write_text("B = 1\n", encoding="utf-8")
    LastGood(root, state).keep(["warp2/a.py", "warp2/b.py"])
    watch.remember(watch.now())
    (state / "builders").mkdir(parents=True, exist_ok=True)
    (state / "builders" / "last_sitting.json").write_text(json.dumps({"entry": 10}), encoding="utf-8")
    (root / "docs" / "BUILD_LOG.md").write_text(LOG, encoding="utf-8")
    (root / "warp2" / "a.py").write_text("A = 2\n", encoding="utf-8")
    (root / "warp2" / "b.py").write_text("B = 2  # needed by a.py now\n", encoding="utf-8")
    Scores(root, state).refresh()


def test_a_set_aside_that_makes_the_gate_worse_is_put_back_and_the_triage_stops(tmp_path):
    """Intention: one failing test before; after setting b.py aside nothing can be gathered - b.py goes back as it was,
    nothing else is set aside, and the log says so."""
    root, state = _tree(tmp_path)
    _last_good_start(root, state)
    readings = iter([(1, False), (2, True)])
    gates = []
    report = Triage(root, state).run(lambda: gates.append(1) or False, standing=lambda: next(readings))
    assert len(gates) == 1, "the triage stopped after the set-aside that made it worse"
    assert report["passed"] is False and report["set_aside"] == []
    assert report["put_back"] and report["put_back"][0]["by"] == "Antigravity"
    assert (root / "warp2" / "b.py").read_text(encoding="utf-8") == "B = 2  # needed by a.py now\n", "back as it was"
    assert (root / "warp2" / "a.py").read_text(encoding="utf-8") == "A = 2\n", "nothing else was touched"
    assert not list((root / "archive" / "set_aside_by_gate").rglob("b.py")), "the file is not left in the archive"
    assert "put back at once" in (root / "docs" / "BUILD_LOG.md").read_text(encoding="utf-8")


def test_a_set_aside_that_does_not_make_it_worse_goes_on_as_before(tmp_path):
    """Intention: the same failure after a set-aside is not worse - the triage goes on to the next builder."""
    root, state = _tree(tmp_path)
    _last_good_start(root, state)
    report = Triage(root, state).run(lambda: False, standing=lambda: (1, False))
    assert [row["by"] for row in report["set_aside"]] == ["Antigravity", "Claude"] and not report["put_back"]


def test_the_gates_counts_are_read_from_its_own_output(tmp_path):
    """Intention: failing tests from the gate's last count; a run that could not gather its tests is said so."""
    out = tmp_path / "state" / "diagnostics" / "tests.out.txt"
    out.parent.mkdir(parents=True)
    assert gate_standing(tmp_path) == (0, False)
    out.write_text("[  1.0 min] 50 passed, 0 failed, 0 skipped\n[  1.9 min] 131 passed, 1 failed, 0 skipped\n",
                   encoding="utf-8")
    assert gate_standing(tmp_path) == (1, False)
    out.write_text("ERROR collecting warp2/ask/tests/test_picture_judge.py\n!!! Interrupted: 1 error during collection !!!\n"
                   "[  0.3 min] 0 passed, 2 failed, 0 skipped\n", encoding="utf-8")
    assert gate_standing(tmp_path) == (2, True)
    assert worse((1, False), (2, True)) and worse((1, False), (2, False)) and worse((1, False), (0, True))
    assert not worse((1, False), (1, False)) and not worse((2, True), (2, True)) and not worse((3, False), (1, False))


def test_an_entry_in_a_builders_own_series_is_read_and_after_means_below_the_last_good_line(tmp_path):
    """Intention: "## 1638c." is entry 1638 by its writer; written below the last good start's line it names its files,
    whatever its number against entries from other series."""
    root, state = _tree(tmp_path)
    log = root / "docs" / "BUILD_LOG.md"
    log.write_text("# log\n\n## 1650. Codex hourly Eye Relay 471 - 2026-11-14 (Codex)\n\nRead `warp2/b.py`.\n",
                   encoding="utf-8")
    entries = LogEntries(root)
    (state / "builders").mkdir(parents=True, exist_ok=True)
    (state / "builders" / "last_sitting.json").write_text(json.dumps({"entry": 1650, "line": entries.lines()}),
                                                          encoding="utf-8")
    with log.open("a", encoding="utf-8") as out:
        out.write("\n## 1638c. The connection web in corpus form - 2026-11-14 (Claude)\n\nChanged `warp2/a.py`.\n")
    found = [entry for entry in entries.all() if entry.number == 1638]
    assert found and found[0].author == "Claude" and found[0].files(root) == ["warp2/a.py"]
    assert Attribution(root, state).of(["warp2/a.py", "warp2/b.py"]) == {"warp2/a.py": "Claude", "warp2/b.py": "unknown"}
