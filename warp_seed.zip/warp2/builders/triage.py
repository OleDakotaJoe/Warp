# WARP3/warp2/builders/triage.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/builders/triage.py
#  Used by   : warp2/control/preflight.py (when the gate fails),
#              warp2/builders/tests/.
#  Uses      : warp2/integrity/source_watch.py (SourceWatch — what changed
#              since the last good start), warp2/builders/entries.py (who
#              named the changed files), warp2/builders/scores.py,
#              warp2/builders/ability.py, warp2/builders/last_good.py;
#              docs/BUILD_LOG.md (an entry by the gate);
#              state/diagnostics/tests.out.txt (how the gate failed - its
#              own counts, BUILD_LOG 1641c); warp2/record/kept_file.py
#              (read_kept - the last good start's line); (stdlib) json, re,
#              shutil, time.
#  Description:
#    When the start gate fails, the changes since the last good start are
#    set aside builder by builder — the lowest-scoring builder's first — and
#    the gate tried again, until it passes or nothing is left to set aside.
#    A set-aside file is moved to archive/set_aside_by_gate/<when>/<builder>/
#    (nothing is deleted) and its last good copy put back; a file that was
#    never kept good is left where it is (it cannot be put back). Who changed
#    a file is the newest entry since the last good start that names it;
#    a file no entry names is "unknown". Every set-aside is written to
#    state/builders/set_aside.jsonl and to the build log, by the gate, so the
#    builder sees what to prove again.
#    NEVER WORSE (BUILD_LOG 1641c): a set-aside that leaves the gate failing
#    worse than before it - more tests failing, or tests that can no longer
#    be gathered at all - is put back at once, as it was, and the triage
#    stops there. Seen 2026-11-14 12:05: the gate failed on one test of 132;
#    the first set-aside moved 81 files, among them modules other files still
#    imported, and the gate then failed at gathering, so every later try set
#    aside more - the warp stayed down until the files were put back by hand.
#    Who changed a file is read from the entries written below the line where
#    the log ended at the last good start (the builders' numbers interleave).
#  User intention (Andrew, 2026-10-31): "reduce ability based of of said
#    scores"; (2026-09-25) "they just have to prove the new parts in a
#    project first ... proven changes are swapped in at restart". BUILD_LOG
#    1004.
# ============================================================================
"""When the start fails: set aside the lowest-scoring builder's changes first, and try the gate again."""
from __future__ import annotations

import json
import re
import shutil
import time
from pathlib import Path

from warp2.builders.ability import Ability
from warp2.builders.entries import LogEntries
from warp2.builders.last_good import LastGood
from warp2.builders.scores import UNKNOWN, Scores

LOG = "docs/BUILD_LOG.md"
THE_GATE = "the gate"


class Attribution:
    """Intention: who changed each file since the last good start, by the entries that name it."""

    def __init__(self, root, state) -> None:
        """Intention: the tree and the state folder that holds the last good start's entry number."""
        self.root, self.state = Path(root), Path(state)

    def last_entry(self) -> int:
        """Intention: the highest entry number at the last good start (written by the source check); 0 when unknown."""
        try:
            return int(json.loads((self.state / "builders" / "last_sitting.json").read_text(encoding="utf-8"))["entry"])
        except (OSError, ValueError, KeyError, TypeError):
            return 0

    def last_line(self):
        """Intention (BUILD_LOG 1641c): the log's length at the last good start (written by the source check), or None
        when a start before 1641c wrote only its entry number."""
        from warp2.record.kept_file import read_kept
        line = read_kept(self.state / "builders" / "last_sitting.json", dict).get("line")
        if line is None:
            return None
        return int(line)

    def of(self, files) -> dict:
        """Intention: {file: author} — the newest entry since the last good start naming the file, else "unknown".
        Since the last good start means written below where the log ended then (1641c); by number when that is not
        known."""
        entries = LogEntries(self.root)
        line = self.last_line()
        since = entries.after_line(line) if line is not None else entries.since(self.last_entry())
        out = {}
        for rel in files:
            author = UNKNOWN
            for entry in since:
                if rel in entry.files(self.root):
                    author = entry.author
            out[rel] = author
        return out


class Triage:
    """Intention: the failed start, set right by setting aside the least-trusted changes first."""

    def __init__(self, root, state) -> None:
        """Intention: the tree and its state folder."""
        self.root, self.state = Path(root), Path(state)
        self.good = LastGood(root, state)
        self.home = self.state / "builders"

    def run(self, gate, standing=None) -> dict:
        """Intention: `gate()` says whether the start gate passes now. Builders' changes are set aside lowest score
        first, the gate tried after each; the report says what was set aside and whether the gate passed.
        `standing()` says how the gate failed - (tests failing, whether tests could not be gathered) - read from the
        gate's own output when not given; a set-aside that leaves it worse is put back and the triage stops
        (BUILD_LOG 1641c)."""
        standing = standing or (lambda: gate_standing(self.root))
        from warp2.integrity.source_watch import SourceWatch
        seen = SourceWatch(self.root, self.state).changed()
        files = list(seen.get("files", []))
        report = {"changed": files, "set_aside": [], "passed": False, "skipped": [], "put_back": []}
        if not files:
            return report
        before = standing()
        who = Attribution(self.root, self.state).of(files)
        scores = Scores(self.root, self.state).read().get("builders", {})
        ability = Ability({a: r.get("score", 0.0) for a, r in scores.items()})
        stamp = time.strftime("%Y-%m-%d_%H%M%S")
        for author in ability.order(who.values()):
            mine = [rel for rel, by in who.items() if by == author]
            moved = []
            for rel in mine:
                if self.good.has(rel) or not self._existed_before(rel):
                    self._set_aside(rel, author, stamp)
                    moved.append(rel)
                else:
                    report["skipped"].append({"file": rel, "by": author, "why": "no good copy kept yet"})
            if not moved:
                continue
            report["set_aside"].append({"by": author, "score": ability.score(author), "files": moved})
            self._record(report["set_aside"][-1], stamp)
            if gate():
                report["passed"] = True
                break
            after = standing()
            if worse(before, after):
                for rel in moved:
                    self._put_back(rel, author, stamp)
                report["set_aside"].pop()
                report["put_back"].append({"by": author, "files": moved, "before": list(before), "after": list(after)})
                self._record({"by": author, "files": moved, "put_back": True, "why": "the gate failed worse"}, stamp)
                break
        self._log(report, stamp)
        return report

    def _existed_before(self, rel: str) -> bool:
        """Intention: whether the file was in the tree at the last good start (a new file can be set aside whole)."""
        try:
            before = json.loads((self.state / "locks" / "source_seen.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return True
        return rel in before

    def _set_aside(self, rel: str, author: str, stamp: str) -> None:
        """Intention: the changed file moved to the archive (kept), and its good copy put back when there is one."""
        source = self.root / rel
        aside = self.root / "archive" / "set_aside_by_gate" / stamp / author.replace(" ", "_") / rel
        aside.parent.mkdir(parents=True, exist_ok=True)
        if source.is_file():
            shutil.move(str(source), str(aside))
        self.good.restore(rel)

    def _put_back(self, rel: str, author: str, stamp: str) -> None:
        """Intention (BUILD_LOG 1641c): a set-aside file moved back where it was, as it was - over the good copy that had
        been put in its place."""
        aside = self.root / "archive" / "set_aside_by_gate" / stamp / author.replace(" ", "_") / rel
        if aside.is_file():
            target = self.root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(aside), str(target))

    def _record(self, row: dict, stamp: str) -> None:
        """Intention: one line per set-aside, where the builders and the scores can read it."""
        self.home.mkdir(parents=True, exist_ok=True)
        with (self.home / "set_aside.jsonl").open("a", encoding="utf-8") as out:
            out.write(json.dumps(dict(row, at=stamp)) + "\n")

    def _log(self, report: dict, stamp: str) -> None:
        """Intention: the build log says what the gate did, so the builder sees what to prove again."""
        if not report["set_aside"] and not report.get("put_back"):
            return
        number = max([e.number for e in LogEntries(self.root).all()] or [0]) + 1
        lines = [f"\n## {number}. The start gate failed; changes set aside, lowest-scoring builder first - "
                 f"{time.strftime('%Y-%m-%d')} ({THE_GATE})\n"]
        lines.append("Why: the prestart regression gate failed on the tree as it stood (state/diagnostics/tests.out.txt). "
                     "The changes since the last good start were set aside builder by builder, lowest score first "
                     "(warp2/builders/), each put back to its last good copy, and the gate tried again.\n")
        for row in report["set_aside"]:
            lines.append(f"- {row['by']} (score {row['score']:+.3f}): " + ", ".join(f"`{f}`" for f in row["files"])
                         + f" -> archive/set_aside_by_gate/{stamp}/")
        lines.append(f"- gate after: {'passed' if report['passed'] else 'still failing'}."
                     + (" A set-aside change is not lost: prove it (its tests pass in the shadow tree) and put it back."))
        for row in report.get("put_back", []):
            lines.append(f"- put back at once, as it was, and the triage stopped: {row['by']}'s "
                         + ", ".join(f"`{f}`" for f in row["files"])
                         + f" - setting them aside left the gate failing worse (failing, not gathered: {row['before']}"
                         f" -> {row['after']}); the gate's first failure is the one to mend.")
        for skip in report["skipped"]:
            lines.append(f"- left in place ({skip['why']}): `{skip['file']}` ({skip['by']})")
        with (self.root / LOG).open("a", encoding="utf-8") as log:
            log.write("\n".join(lines) + "\n")


# Intention (BUILD_LOG 1641c): the gate's own output (run_tests.py writes it) - where its counts are read from.
GATE_OUTPUT = Path("state") / "diagnostics" / "tests.out.txt"
COUNTS = re.compile(r"\]\s+(\d+) passed, (\d+) failed")
NOT_GATHERED = ("Interrupted:", "error during collection", "ERROR collecting")


def gate_standing(root) -> tuple:
    """Intention (BUILD_LOG 1641c): (tests failing, whether tests could not be gathered) from the gate's last output -
    (0, False) when there is no output to read, so nothing is ever called worse on nothing."""
    try:
        text = (Path(root) / GATE_OUTPUT).read_text(encoding="utf-8", errors="replace")
    except OSError:  # fault: ok no output - (0, False) says nothing was seen failing
        return 0, False
    counts = COUNTS.findall(text)
    failed = int(counts[-1][1]) if counts else 0
    return failed, any(words in text for words in NOT_GATHERED)


def worse(before: tuple, after: tuple) -> bool:
    """Intention (BUILD_LOG 1641c): whether the gate fails worse now - tests that could be gathered no longer can, or
    more of them fail."""
    return (after[1] and not before[1]) or after[0] > before[0]
