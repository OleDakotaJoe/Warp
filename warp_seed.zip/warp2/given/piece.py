# WARP3/warp2/given/piece.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/piece.py
#  Used by   : warp2/given/giver.py (what the skill concepts and the
#              give-or-hold action pair read about the work).
#  Uses      : stdlib re.
#  Description:
#    The work as named numbers, no text: its kind and each word of its
#    target (the path's folders and name split at anything not a letter or
#    digit), each a tag of strength one.
#  User intention (Andrew, 2026-09-18): action models that never use text;
#    (2026-11-14) each skill done is a concept the Eye learns to tell apart.
# ============================================================================
"""The work a skill was done on, as tags."""
from __future__ import annotations

import re


def piece_of(item: dict) -> dict:
    """Intention: the unit's kind and every word of its target, as tags of strength one."""
    kind = str(item.get("kind") or "")
    target = str(item.get("target") or item.get("item") or "")
    tags = {f"kind: {kind}": 1.0} if kind else {}
    for word in re.split(r"[^a-z0-9]+", target.lower()):
        if word:
            tags[f"target: {word}"] = 1.0
    return tags
