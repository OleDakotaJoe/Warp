# WARP3/warp2/given/skill_tree.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/skill_tree.py
#  Used by   : warp2/given/giver.py (the path of every skill done, kept at
#              each skill on it by skill_concepts.py).
#  Uses      : warp2/train/bible.py (named - each skill's `after`).
#  Description:
#    THE HIERARCHY OF SKILLS DONE. A sub-task is a skill: a kind of work is
#    the bible's skill of that name, and practice is the skill it practises.
#    Its path runs from the root of the skill bible's tree down to it, over
#    the `after` links: syntax at the root; testing, repair, data_processing,
#    cookbook and every kind of work under it; architecture under testing;
#    net_tokens under data_processing. A skill that comes after more than
#    one is placed under the deepest of them (the most specific), ties by
#    name, so the tree is one tree. A sub-task the bible does not describe
#    is a root of its own. This is only where the tree starts: each skill is
#    a concept of the WARP's Eye, and the Eye's own hierarchy (what fires
#    together) can regroup it.
#  User intention (Andrew, 2026-11-14 20:56): "the concept side should be a
#    hierarchy of of skills done". Chose: start from the bible's tree plus
#    every sub-task done; the Eye refines it.
# ============================================================================
"""The path of a skill done, from the root of the skill bible's tree."""
from __future__ import annotations

from warp2.train import bible


def skill_of(key: str) -> str:
    """Intention: the skill a sub-task is - the skill practised, or the kind of work itself."""
    key = str(key)
    return key.split(":", 1)[1].strip() if key.startswith("practice:") else key.strip()


def path_of(key: str) -> list:
    """Intention: the skills from the root down to this sub-task's skill, over the bible's `after` links."""
    return _path(skill_of(key), frozenset())


def _path(name: str, seen: frozenset) -> list:
    """Intention: one skill's path - under its deepest `after` (ties by name); itself alone when undescribed or in a loop."""
    skill = bible.named(name)
    if skill is None or name in seen:
        return [name]
    above = [_path(str(parent), seen | {name}) for parent in skill.after if str(parent) != name]
    if not above:
        return [name]
    deepest = sorted(above, key=lambda path: (-len(path), path))[0]
    return deepest + [name]
