# WARP3/warp2/given/tags.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tags.py
#  Used by   : warp2/given/giver.py (what the give-or-hold action pair reads
#              of the counts, beside the work itself, piece.py).
#  Uses      : warp2/given/arms.py (read through the Arms handed in).
#  Description:
#    The tags one try is read as - named numbers, no text: the model, both
#    pass rates, how much each arm has been tried (n / (n + 2), 0..1, as the
#    rule counts it) and the room the part takes.
#  User intention (Andrew, 2026-09-18): action models that never use text;
#    (2026-11-14) the verdict is the model's own, so the model is a tag.
# ============================================================================
"""What one try of a skill part is read as."""
from __future__ import annotations


def tags_of(model: str, arms, cost: float) -> dict:
    """Intention: the try as named numbers - the model, both rates, how tried each arm is, and the part's cost."""
    a, _ = arms.rate(True)
    u, _ = arms.rate(False)
    given, held = arms.tries(True), arms.tries(False)
    return {f"model: {model}": 1.0, "with rate": a, "without rate": u,
            "with tries": given / (given + 2.0), "without tries": held / (held + 2.0),
            "room taken": float(cost)}
