# WARP3/warp2/given/tests/test_a_skill_part_is_held_once_the_model_does_as_well_without_it.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tests/test_a_skill_part_is_held_once_the_model_does_as_well_without_it.py
#  Used by   : pytest.
#  Uses      : warp2/given/arms.py, rule.py, states.py, label.py, tags.py,
#              parts.py.
#  Description:
#    The counting rule across the four states: nothing held before it has
#    been tried; works -> given; taken in -> held (the room it takes tips
#    it); hurts -> held; not covered -> given. Old tries fade, so a part
#    held back long ago is tried again; the states add up to one; the label
#    and the tags say what the giver teaches; the names are file-safe.
#  User intention (Andrew, 2026-11-14): skills a model has taken in, or that
#    hurt it, are not kept being given; never dropped where nothing covers
#    the work.
# ============================================================================
from __future__ import annotations

from warp2.given.arms import Arms
from warp2.given.label import hold_right
from warp2.given.parts import key_of, point_name
from warp2.given.rule import cost_of, hold_share
from warp2.given.states import HURTS, NOT_COVERED, STATES, TAKEN_IN, WORKS, memberships
from warp2.given.tags import tags_of


def _arms(given_pass: int, given_fail: int, held_pass: int, held_fail: int) -> Arms:
    arms = Arms()
    groups = [[(True, True)] * given_pass, [(True, False)] * given_fail,
              [(False, True)] * held_pass, [(False, False)] * held_fail]
    # The four kinds of try dealt out through each other, as live tries come.
    while any(groups):
        for group in groups:
            if group:
                arms.add(*group.pop())
    return arms


def test_nothing_is_held_before_the_part_has_been_tried_given():
    assert hold_share(Arms(), 0.0) == 0.0


def test_a_part_that_works_is_given_and_one_taken_in_or_hurting_is_held():
    works = hold_share(_arms(40, 2, 1, 12), 0.0)
    taken_in = hold_share(_arms(40, 2, 40, 2), 0.1)
    hurts = hold_share(_arms(3, 40, 20, 2), 0.0)
    not_covered = hold_share(_arms(1, 40, 1, 20), 0.0)
    assert works < 0.05, works
    assert taken_in > 0.8, taken_in
    assert hurts > 0.75, hurts
    assert not_covered < 0.15, not_covered


def test_the_room_a_part_takes_tips_a_tie_toward_holding_it():
    tie = _arms(30, 1, 30, 1)
    assert hold_share(tie, 0.2) > hold_share(tie, 0.0)
    assert cost_of(500, 2000) == 0.25 and cost_of(500, 0) == 0.0 and cost_of(5000, 2000) == 1.0


def test_old_tries_fade_so_a_part_held_back_long_ago_is_tried_again():
    arms = _arms(10, 0, 0, 10)
    soon = hold_share(arms, 0.0)
    later_tries = 300
    for _ in range(later_tries):
        arms.add(True, True)
    later = hold_share(arms, 0.0)
    assert later > soon, (soon, later)
    passes, fails = arms.counts(False)
    assert passes + fails < 1.0


def test_the_four_states_add_up_to_one_and_name_the_corners():
    for a, u in ((0.9, 0.1), (0.9, 0.9), (0.1, 0.1), (0.1, 0.9), (0.5, 0.5)):
        shares = memberships(a, u)
        assert set(shares) == set(STATES)
        assert abs(sum(shares.values()) - 1.0) < 1e-9
    corners = {(1.0, 0.0): WORKS, (1.0, 1.0): TAKEN_IN, (0.0, 0.0): NOT_COVERED, (0.0, 1.0): HURTS}
    for (a, u), state in corners.items():
        shares = memberships(a, u)
        assert max(shares, key=shares.get) == state


def test_a_held_try_teaches_for_certain_and_a_given_one_teaches_the_held_rate():
    assert hold_right(False, True, 0.3) == 1.0
    assert hold_right(False, False, 0.3) == 0.0
    assert hold_right(True, True, 0.3) == 0.3
    assert hold_right(True, False, 0.7) == 0.7


def test_a_try_is_read_as_named_numbers_with_the_model_as_a_tag():
    tags = tags_of("qwen-small", _arms(5, 1, 2, 2), 0.1)
    assert tags["model: qwen-small"] == 1.0
    assert set(tags) == {"model: qwen-small", "with rate", "without rate", "with tries",
                         "without tries", "room taken"}
    assert all(0.0 <= value <= 1.0 for value in tags.values())


def test_each_skill_is_its_own_sub_task_and_its_point_name_is_file_safe():
    assert key_of({"kind": "practice", "target": "skill:syntax"}) == "practice: syntax"
    assert key_of({"kind": "build", "target": "projects/x.py"}) == "build"
    assert point_name("practice: syntax", "skill line") == "give_practice_syntax_skill_line"
    assert point_name("build", "coding rules") == "give_build_coding_rules"
