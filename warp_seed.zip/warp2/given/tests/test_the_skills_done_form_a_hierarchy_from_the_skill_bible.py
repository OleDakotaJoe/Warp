# WARP3/warp2/given/tests/test_the_skills_done_form_a_hierarchy_from_the_skill_bible.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tests/test_the_skills_done_form_a_hierarchy_from_the_skill_bible.py
#  Used by   : pytest.
#  Uses      : warp2/given/skill_tree.py, warp2/given/piece.py,
#              warp2/train/bible.py.
#  Description:
#    The path of a skill done runs from the root of the skill bible's tree:
#    syntax over testing over architecture, syntax over data_processing over
#    net_tokens, every kind of work under syntax; a skill after more than one
#    sits under the deepest; practice is the skill practised; a sub-task the
#    bible does not describe is its own root. The work is read as tags.
#  User intention (Andrew, 2026-11-14 20:56): "the concept side should be a
#    hierarchy of of skills done" - starting from the bible's tree, the Eye
#    refining it.
# ============================================================================
from __future__ import annotations

from warp2.given.piece import piece_of
from warp2.given.skill_tree import path_of, skill_of


def test_a_skill_done_runs_from_the_root_of_the_bible_s_tree():
    assert path_of("practice: syntax") == ["syntax"]
    assert path_of("practice: testing") == ["syntax", "testing"]
    assert path_of("practice: net_tokens") == ["syntax", "data_processing", "net_tokens"]
    assert path_of("build") == ["syntax", "build"]
    assert path_of("test") == ["syntax", "test"]


def test_a_skill_after_more_than_one_sits_under_the_deepest():
    # architecture comes after syntax and testing; testing is under syntax.
    assert path_of("practice: architecture") == ["syntax", "testing", "architecture"]


def test_practice_is_the_skill_practised_and_an_undescribed_sub_task_is_its_own_root():
    assert skill_of("practice: repair") == "repair"
    assert skill_of("build") == "build"
    assert path_of("a kind nobody described") == ["a kind nobody described"]


def test_the_work_is_read_as_its_kind_and_the_words_of_its_target():
    tags = piece_of({"kind": "build", "target": "warp2/gate/checks.py"})
    assert tags == {"kind: build": 1.0, "target: warp2": 1.0, "target: gate": 1.0,
                    "target: checks": 1.0, "target: py": 1.0}
    assert piece_of({}) == {}
