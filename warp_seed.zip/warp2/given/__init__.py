# WARP3/warp2/given/__init__.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/__init__.py
#  Used by   : warp2/models/worker.py (parts.py), warp2/work/loop.py and
#              warp2/run.py (giver.py).
#  Uses      : nothing.
#  Description:
#    WHAT A MODEL IS GIVEN WITH ITS WORK, chosen and measured. Some lines of a
#    model's prompt are skill text - the skill's own line, a hint, the general
#    coding rules, the test rules, the part's connection web. Research
#    (claude/skills_help_hurt_research_2026_11_14.md) found such text helps a
#    model only while it has not learned it, sometimes hurts, and must be
#    measured per skill and per model. Here each such part is given or held
#    for each try, and the tries are counted with it and without it. In the
#    WARP's Eye, the concept side is a hierarchy of the skills done (each
#    skill its own concept pairs, parent over child), and each part at each
#    sub-task has its own action pair (give or hold - a thing the computer
#    does).
#  User intention (Andrew, 2026-11-14 18:35): "skills not always helping
#    models and sometimes hurting them when the models has internalized the
#    skill we need to adapt our setup for skills to handle this while we
#    speclize to task and break them down into smaller task this should
#    happen and work in the models like the concept pairs and they should all
#    have their own concept pairs". 18:47: "Action pairs are meant to be
#    things that the computer does, so I guess that should be the defining
#    line. Let's get it all in there and get it working." 20:56: "the
#    concept side should be a hierarchy of of skills done".
# ============================================================================
"""What a model is given with its work, chosen and measured."""
