# WARP2/warp2/given/rule.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/given/rule.py
#  Used by   : warp2/given/giver.py (the counting rule's share; the Eye's
#              action pair takes over only once it is surely better).
#  Uses      : warp2/given/arms.py (the two rates), warp2/given/states.py
#              (not covered); stdlib math.
#  Description:
#    HOW OFTEN TO HOLD A PART BACK, from its two arms - a share, never a cut:
#      hold = P(held does as well as given, less what the part costs)
#             x (1 - not covered) x how much it has been tried given
#    * P(...) is the chance the held rate u is at least the given rate a
#      less the part's cost, from both rates and how unsure each is. Unsure
#      arms hold near half the time, so both keep being measured; a sure
#      answer moves it toward nought or one.
#    * The cost is the room the part takes: its characters over the
#      characters this model can be given (nought when it declares none).
#      Where both arms pass, the cost tips it to holding - the model has
#      taken the skill in, and the part is only noise and room.
#    * Not covered (fails either way) keeps the part given: neither the
#      model nor the part does it, and dropping the part would mark the
#      skill as learned when it is not.
#    * Until the part has been tried given, nothing is held - the WARP keeps
#      the way it worked before. n / (n + 2) uses the same two tries the
#      rates' Beta(1, 1) start counts as.
#  User intention (Andrew, 2026-11-14): skills given only while they help
#    the model, held once it has learned them or when they hurt, never
#    dropped where nothing covers the work. Research: SKILL0 (arXiv
#    2604.02268, skills withdrawn as they are learned), The Regression Tax
#    (arXiv 2607.22520, skills break work the model could already do),
#    Beyond Gain (arXiv 2610.32322, never retire what is not covered).
# ============================================================================
"""How often a part is held back, from its two arms."""
from __future__ import annotations

import math

from warp2.given.states import NOT_COVERED, memberships


def cost_of(chars: int, room: int) -> float:
    """Intention: the share of this model's room the part takes, 0..1; nought when the model declares no room."""
    if room <= 0 or chars <= 0:
        return 0.0
    return min(1.0, float(chars) / float(room))


def held_as_good(arms, cost: float) -> float:
    """Intention: the chance the held rate is at least the given rate less the cost, read from both rates and how unsure each is."""
    a, va = arms.rate(True)
    u, vu = arms.rate(False)
    spread = math.sqrt(va + vu)
    return 0.5 * math.erfc(-(u - a + float(cost)) / (spread * math.sqrt(2.0)))


def hold_share(arms, cost: float) -> float:
    """How often to hold the part back now, 0..1.

    Intention: the three factors in the file's heading - as good without it,
    not where nothing covers the work, and only once it has been tried given.
    """
    a, _ = arms.rate(True)
    u, _ = arms.rate(False)
    covered = 1.0 - memberships(a, u)[NOT_COVERED]
    tried = arms.tries(True)
    return held_as_good(arms, cost) * covered * (tried / (tried + 2.0))
