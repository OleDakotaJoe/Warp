# WARP3/warp2/given/states.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/states.py
#  Used by   : warp2/given/giver.py (the strongest state for `run skills`),
#              warp2/given/rule.py (not covered).
#  Uses      : nothing.
#  Description:
#    The four states of a skill part for one model, from its two pass rates
#    (given a, held u), as smooth shares that add up to one - never a cut:
#      works       a(1 - u)        passes with it, fails without it
#      taken in    a * u           passes either way - the model has learned it
#      not covered (1 - a)(1 - u)  fails either way - neither supplies it
#      hurts       (1 - a) * u     passes only without it
#  User intention (Andrew, 2026-11-14): the states are counts the rule and
#    the give-or-hold action pair read - not concepts (20:56: "the concept
#    side should be a hierarchy of of skills done"). Research: Beyond Gain
#    (arXiv 2610.32322) names these four from with/without runs and warns
#    that taken in and not covered look the same by gain alone.
# ============================================================================
"""The four states of a skill part, as shares."""
from __future__ import annotations

WORKS = "works"
TAKEN_IN = "taken in"
NOT_COVERED = "not covered"
HURTS = "hurts"
STATES = (WORKS, TAKEN_IN, NOT_COVERED, HURTS)


def memberships(given_rate: float, held_rate: float) -> dict:
    """Intention: how much the part is in each state, from the given rate a and the held rate u; the four add up to one."""
    a, u = float(given_rate), float(held_rate)
    return {WORKS: a * (1.0 - u), TAKEN_IN: a * u, NOT_COVERED: (1.0 - a) * (1.0 - u), HURTS: (1.0 - a) * u}
