# WARP2/warp2/given/giver.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/given/giver.py
#  Used by   : warp2/work/loop.py (Loop.giver - made once, handed to the
#              worker at use), warp2/models/worker.py (choose before a part
#              goes into a prompt; saw / dropped after the try),
#              warp2/run.py (`skills` - what each model is given and why).
#  Uses      : warp2/given/arms.py, rule.py, label.py, tags.py, tries.py,
#              states.py, parts.py, piece.py, skill_tree.py,
#              skill_concepts.py; warp2/decide/ (a Decider per point - the
#              action pair, through the WARP's Eye); warp2/record/swallowed.py
#              (noted); stdlib random, pathlib.
#  Description:
#    WHETHER EACH SKILL PART GOES TO THE MODEL, try by try.
#    * choose(): the counting rule (rule.py) says how often to hold the part
#      for this sub-task and model. The part's ACTION PAIR - a decision point
#      "give_<sub-task>_<part>" with choices give and hold, a part of the
#      WARP's Eye like every decision (warp2/decide/) - is asked every time,
#      reading the work (piece.py) and the counts (tags.py), and shadows the
#      rule; once it is surely better than the rule (graduated: two standard
#      errors, the decide/ standard) its share is used instead. The choice is
#      drawn from the share, so both arms keep being measured while either
#      is unsure.
#    * saw(): after the try is judged, each part's arms are counted, the try
#      is written down, the action pair is settled with what the try showed
#      (label.py), and the skill done is kept once at every skill on its
#      path - THE CONCEPT SIDE, a hierarchy of skills done (skill_tree.py,
#      skill_concepts.py), trained at the WARP's Eye step. The four states
#      (states.py) are counts the rule and the action pair read, not
#      concepts.
#    * dropped(): a model that was never reached saw nothing; its asks are
#      let go and nothing is counted.
#    What follows from the states, without anything else to decide:
#      taken in -> held more and more (the cost tips it);
#      hurts -> held; works -> given; not covered -> given, and the work
#      stays a training need through the standing it already has.
#  User intention (Andrew, 2026-11-14 18:35-18:47): skills that a model has
#    taken in, or that hurt it, must not keep being given; specialise to the
#    task and break it into smaller ones; each with its own concept pairs;
#    "Action pairs are meant to be things that the computer does". 20:56:
#    "the concept side should be a hierarchy of of skills done". Research:
#    claude/skills_help_hurt_research_2026_11_14.md.
# ============================================================================
"""Whether each skill part goes to the model, chosen try by try and learned from."""
from __future__ import annotations

import random
from pathlib import Path

from warp2.given.arms import Arms
from warp2.given.label import hold_right
from warp2.given.parts import point_name
from warp2.given.piece import piece_of
from warp2.given.rule import cost_of, hold_share
from warp2.given.skill_concepts import SkillConcepts
from warp2.given.skill_tree import path_of
from warp2.given.states import memberships
from warp2.given.tags import tags_of
from warp2.given.tries import Tries
from warp2.record.swallowed import noted

GIVE = "give"
HOLD = "hold"
CHOICES = (GIVE, HOLD)


class Giver:
    """Chooses what goes into a model's prompt part by part, and learns from how the work went."""

    def __init__(self, state, decisions=None, rng=None) -> None:
        """Every try written so far counted back in.

        Intention: `decisions` is the machine's registry (warp2/decide/);
        without it the counting rule alone decides and nothing goes to the
        Eye - which is how `run skills` reads the table.
        """
        self.state = Path(state)
        self.tries = Tries(self.state)
        self.decisions = decisions
        self.rng = rng if rng is not None else random.Random()
        self.skills = SkillConcepts(self.state) if decisions is not None else None
        self.arms = {}
        for row in self.tries.rows():
            self._arms(row.get("key"), row.get("part"), row.get("model")).add(
                bool(row.get("given")), bool(row.get("passed")))

    def _arms(self, key, part, model) -> Arms:
        """Intention: the arms of one part, at one sub-task, for one model - made the first time."""
        return self.arms.setdefault((str(key), str(part), str(model)), Arms())

    def _point(self, key: str, part: str):
        """Intention: the part's action pair at this sub-task (its decision point), or None with no registry or when it cannot be made."""
        if self.decisions is None:
            return None
        try:
            return self.decisions.get(point_name(key, part), CHOICES)
        except Exception as exc:
            noted("warp2/given/giver.py:Giver._point", exc)
            return None

    def choose(self, key: str, part: str, model: str, chars: int, room: int, item: dict | None = None) -> dict:
        """Give or hold this part for this model now; the ticket to hand back after the try.

        Intention: the rule's share unless the action pair has graduated
        past it; drawn, never cut, so an unsure part keeps being tried both
        ways. `item` is the unit of work, read as tags (piece.py) by the
        action pair and kept for the skill concepts.
        """
        arms = self._arms(key, part, model)
        cost = cost_of(int(chars), int(room))
        rule = hold_share(arms, cost)
        hold, by, row_id = rule, "count", ""
        piece = piece_of(item) if item else {}
        point = self._point(key, part)
        if point is not None:
            try:
                asked = point.ask({**tags_of(model, arms, cost), **piece}, {GIVE: 1.0 - rule, HOLD: rule})
                row_id = str(asked.get("id") or "")
                if asked.get("graduated"):
                    hold, by = float(asked["probabilities"][HOLD]), "eye"
            except Exception as exc:
                noted("warp2/given/giver.py:Giver.choose", exc)
        return {"key": str(key), "part": str(part), "model": str(model),
                "given": self.rng.random() >= hold, "hold": round(hold, 4),
                "by": by, "cost": round(cost, 4), "id": row_id, "piece": piece}

    def saw(self, tickets: list, passed: bool) -> int:
        """How the work went, for every part chosen for it: counted, written down, taught.

        Intention: the held rate is read BEFORE this try is counted, so the
        action pair is taught only what was known when it chose. The skill
        done is kept once a try, however many parts were chosen for it.
        """
        for ticket in tickets:
            arms = self._arms(ticket["key"], ticket["part"], ticket["model"])
            held_rate = arms.rate(False)[0]
            arms.add(bool(ticket["given"]), bool(passed))
            self.tries.add({"key": ticket["key"], "part": ticket["part"], "model": ticket["model"],
                            "given": bool(ticket["given"]), "passed": bool(passed),
                            "hold": ticket["hold"], "by": ticket["by"]})
            self._settle(ticket, hold_right(bool(ticket["given"]), bool(passed), held_rate))
        if tickets:
            self._keep_skill(tickets[0])
        return len(tickets)

    def _settle(self, ticket: dict, right: float) -> None:
        """Intention: the action pair taught hold or give, drawn by the chance holding was right (seeded by the ask, so a replay draws the same)."""
        point = self._point(ticket["key"], ticket["part"]) if ticket.get("id") else None
        if point is None:
            return
        outcome = HOLD if random.Random(ticket["id"]).random() < right else GIVE
        try:
            point.settle(ticket["id"], outcome)
        except Exception as exc:
            noted("warp2/given/giver.py:Giver._settle", exc)

    def _keep_skill(self, ticket: dict) -> None:
        """Intention: the skill done kept at every skill on its path in the Eye (the concept side); nothing without the Eye or the work."""
        if self.skills is None or not ticket.get("piece"):
            return
        try:
            self.skills.keep(path_of(ticket["key"]), ticket["piece"])
        except Exception as exc:
            noted("warp2/given/giver.py:Giver._keep_skill", exc)

    def dropped(self, tickets: list) -> int:
        """Intention: a try that never reached its model - its asks let go, nothing counted."""
        for ticket in tickets:
            point = self._point(ticket["key"], ticket["part"]) if ticket.get("id") else None
            if point is not None:
                point.drop(ticket["id"])
        return len(tickets)

    def says(self) -> list:
        """Every part at every sub-task for every model: how tried, both rates, the strongest state, and how often it is held now.

        Intention: what `run skills` prints - the person sees what each
        model is given and why. The hold share is read with no cost (the
        model's room is not known here).
        """
        out = []
        for (key, part, model), arms in sorted(self.arms.items()):
            a, u = arms.rate(True)[0], arms.rate(False)[0]
            shares = memberships(a, u)
            out.append({"key": key, "part": part, "model": model,
                        "given": round(arms.tries(True), 2), "held": round(arms.tries(False), 2),
                        "with": round(a, 3), "without": round(u, 3),
                        "state": max(shares, key=shares.get), "hold": round(hold_share(arms, 0.0), 3)})
        return out
