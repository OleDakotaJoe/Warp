# WARP3/warp2/given/skill_concepts.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/skill_concepts.py
#  Used by   : warp2/given/giver.py (each skill done kept once a try).
#  Uses      : projects/behemoth_eye/eye/warp_eye.py (WarpEye - part, keep;
#              EVERYTHING - the master is kept each example too),
#              projects/behemoth_eye/eye/heads (WEB), projects/behemoth_eye/
#              pairs/fronts.py (VECTOR); warp2/given/skill_tree.py (the path,
#              handed in).
#  Description:
#    THE CONCEPT SIDE: A HIERARCHY OF SKILLS DONE, as concept pairs of the
#    WARP's Eye. Each skill on the tree is a part of the Eye, "skill: <name>",
#    whose classes are the skills done under it and itself - so
#    "skill: syntax: testing" is the concept pair for testing work within
#    syntax, and "skill: testing: testing" for testing itself. Each part is
#    also an Eye task with its own task concept and action thing. A skill
#    done is kept at every skill on its path - at each, as the next skill
#    down, and at its own as itself - and for the master, named with its
#    part. The WARP's Eye step trains them at its own measured pace (the
#    WARP trains the Eye); nothing is taught in the middle of a model's work.
#    A new skill done joins its parent's part as a new class, keeping what
#    the others learned. The Eye's own hierarchy, from what fires together,
#    can regroup them.
#  User intention (Andrew, 2026-11-14 20:56): "the concept side should be a
#    hierarchy of of skills done"; 18:35 "they should all have their own
#    concept pairs". Chose: the bible's tree plus every sub-task done, the
#    Eye refines it.
# ============================================================================
"""Each skill done kept as concept pairs of the WARP's Eye, parent over child."""
from __future__ import annotations


class SkillConcepts:
    """The Eye part of every skill on the tree, its examples kept for the Eye step."""

    def __init__(self, state) -> None:
        """Intention: the Eye of this state folder, opened the first time a skill done is kept."""
        self.state = state
        self.warp = None

    def _warp(self):
        """Intention: the WARP's one Eye, opened once."""
        if self.warp is None:
            from projects.behemoth_eye.eye.warp_eye import WarpEye
            self.warp = WarpEye.for_state(self.state)
        return self.warp

    def keep(self, path: list, piece: dict) -> list:
        """One skill done kept at every skill on its path; the concept names kept.

        Intention: at each skill the label is the next skill down, and at the
        last the skill itself; the master is given each, named with its part,
        as the KG's blocks are (WarpEye.sync_from_kg_blocks).
        """
        from projects.behemoth_eye.eye.heads import WEB
        from projects.behemoth_eye.eye.warp_eye import EVERYTHING
        from projects.behemoth_eye.pairs.fronts import VECTOR
        warp = self._warp()
        kept = []
        for at, skill in enumerate(path):
            label = str(path[at + 1]) if at + 1 < len(path) else str(skill)
            name = f"skill: {skill}"
            warp.part(name, [label], VECTOR)
            warp.keep(name, dict(piece), WEB, label, 1.0)
            warp.keep(f"{EVERYTHING}: {WEB}", dict(piece), WEB, f"{name}: {label}", 1.0)
            kept.append(f"{name}: {label}")
        return kept
