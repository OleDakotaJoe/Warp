# WARP3/warp2/equation_book/rules/insert.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/insert.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/{rule,price}.py; numpy.
#  Description:
#    INSERTS. Some digits are taken out of the list so the rest can be made by a
#    further rule, and put back in when the list is read. Three kinds: PLACED (the
#    gaps between them and the digits are kept), TRIGGERED (they stand right after
#    every digit of one set value in the rest - only that value and the digits are
#    kept), REPEAT (each is a copy of the digit before it - only the gaps are kept).
#  User intention (Andrew, 2026-11-16 16:52): "is this with the triggered and other kinds of
#    inserts as well"; 00:34: "triggers for repeats to add in data blocks"; 15:17: the
#    function system inserted in the numbers wherever we want through inserts.
# ============================================================================
"""Digits taken out and put back in when read: placed, triggered by a set value, or repeats of the one before."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.price import price_of, width_of
from warp2.equation_book.rules.rule import Fit, Rule

PLACED, TRIGGERED, REPEAT = 0, 1, 2


def _wide_ones(x: np.ndarray):
    """Intention: the digits that need more bits than the rest - the ones worth taking out - or None."""
    n = x.size
    mid = int(np.partition(x, n // 2)[n // 2])
    with np.errstate(over="ignore"):
        apart = np.abs((x - np.int64(mid)).astype(np.float64))
    bits = np.ceil(np.log2(apart + 1)).astype(np.int64)
    gap_bits = max(1, int(n).bit_length())
    best = None
    for limit in np.unique(bits)[:-1]:
        out = bits > limit
        price = int((~out).sum()) * (int(limit) + 1) + int(out.sum()) * (width_of(x[out]) + gap_bits)
        if best is None or price < best[0]:
            best = (price, out)
    if best is None or best[0] >= price_of(x) or not best[1].any() or best[1].all():
        return None
    return best[1]


class Insert(Rule):
    """Intention: Andrew's inserts - digits put into the made list, by place, by trigger, or as repeats."""
    ident = 15
    name = "insert"

    def fit(self, x, hints):
        """Intention: repeats first (they keep nothing but gaps); else the wide digits, triggered when they stand
        exactly after every digit of one value in the rest, placed otherwise."""
        n = x.size
        if n < 16:
            return None
        same = np.concatenate([[False], x[1:] == x[:-1]])
        if same.sum() * 4 >= n and not same[1:].all():
            places = np.flatnonzero(same)
            gaps = np.diff(np.concatenate([[-1], places])) - 1
            return Fit([REPEAT, n], [x[~same], gaps.astype(np.int64)], follow=0)
        out = _wide_ones(x)
        if out is None or out[0]:
            return None
        rest, taken = x[~out], x[out]
        places = np.flatnonzero(out)
        before = x[places - 1]
        if not out[places - 1].any() and np.unique(before).size == 1 and int((rest == before[0]).sum()) == places.size:
            return Fit([TRIGGERED, int(before[0])], [rest, taken], follow=0)
        gaps = np.diff(np.concatenate([[-1], places])) - 1
        return Fit([PLACED, n], [rest, gaps.astype(np.int64), taken], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the taken-out digits back in their places among the rest."""
        kind, value = settings
        rest = parts[0]
        if kind == TRIGGERED:
            taken = parts[1]
            after = np.flatnonzero(rest == value)
            return np.insert(rest, after + 1, taken)
        places = np.cumsum(parts[1] + 1) - 1
        out = np.empty(value, dtype=np.int64)
        mask = np.zeros(value, dtype=bool)
        mask[places] = True
        out[~mask] = rest
        if kind == PLACED:
            out[mask] = parts[2]
            return out
        for at in places.tolist():           # REPEAT: each a copy of the digit before it, in order
            out[at] = out[at - 1]
        return out
