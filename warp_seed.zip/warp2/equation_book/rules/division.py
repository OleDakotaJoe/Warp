# WARP3/warp2/equation_book/rules/division.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/division.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/{rule,price}.py; numpy.
#  Description:
#    THE CHAIN OF DIVISION. The digits are those of r divided by b, worked out
#    digit by digit: each step the remainder times the digit base is divided by b,
#    the whole part is the digit and the remainder goes on. Kept are b, the
#    remainder it starts on, the digit width, and what is left (noughts when the
#    digits follow the division all the way).
#  User intention (Andrew, 2026-11-15 20:57): "You store the number in the point in the
#    equation in the long division that leads to the next number ... We are basically
#    following chains of division"; 21:08: the divisor and the remainder are the two
#    numbers.
# ============================================================================
"""The digits of r divided by b, by long division in the digits' own base; b, r and what is left are kept."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.price import price_of
from warp2.equation_book.rules.rule import Fit, Rule

DIVISORS = range(2, 1024)
PROOF_BITS = 48                             # Intention: the opening digits that must match hold at least this many bits, so a
                                            # division that is not the list's own almost never passes (there are about 2^19 to try)
TRIES = 2                                   # Intention: divisions worked all the way before the rule gives up on a list


def _digits(b: int, r: int, base: int, count: int) -> list:
    """Intention: the first `count` digits of r / b in this base, by long division."""
    out = []
    for _ in range(count):
        r *= base
        out.append(r // b)
        r %= b
    return out


class Division(Rule):
    """Intention: Andrew's chains of division - two small numbers and the digits come for nothing."""
    ident = 17
    name = "division"

    def fit(self, x, hints):
        """Intention: for each divisor, the remainders that give the first digit; the first whose opening digits all
        match is worked all the way and kept if what is left is below the list as it stands."""
        n, width = x.size, hints.width
        if n == 0 or not 8 <= width <= 32 or int(x.min()) < 0 or int(x.max()) >> width:
            return None
        proof = -(-PROOF_BITS // width)
        if n < 2 * proof:
            return None
        base = 1 << width
        head = [int(v) for v in x[:proof]]
        tries = 0
        for b in DIVISORS:
            lo = -(-head[0] * b // base)
            hi = min(b - 1, ((head[0] + 1) * b - 1) // base)
            for r in range(max(lo, 1), hi + 1):
                if _digits(b, r, base, proof) == head:
                    left = x - np.array(_digits(b, r, base, n), dtype=np.int64)
                    if price_of(left) < price_of(x):
                        return Fit([b, r, width], [left], follow=0)
                    tries += 1
                    if tries >= TRIES:
                        return None
        return None

    def rebuild(self, settings, parts):
        """Intention: the division worked again, and what is left put back on."""
        b, r, width = settings
        left = parts[0]
        return left + np.array(_digits(b, r, 1 << width, left.size), dtype=np.int64)
