# WARP2/warp2/equation_book/rules/swap.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/swap.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    BYTE SWAP - the same digit with its bytes the other way round. A file's
#    binary is read as one number from its first byte, but most files on
#    Windows and from numpy write each value's lowest byte first; read as
#    one number, every such value's bytes come out reversed and no run or
#    repeat shows. Swapping each 16, 32 or 64-bit digit's bytes back opens
#    the rules that follow (it gains nothing alone, so the search prices it
#    by the whole chain after it). Swapping twice gives the digit back.
#  User intention (Andrew, 2026-11-14 16:11): "We also don't need to be
#    limited to standard numbers or representations"; 17:08: "the binary as
#    a number".
# ============================================================================
"""Byte swap: each digit's bytes the other way round (a lowest-byte-first value read as one number)."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule

# Intention: the digit widths that are whole numbers of bytes numpy can swap at once.
SWAPPABLE = {16: np.uint16, 32: np.uint32, 64: np.uint64}


def swapped(values: np.ndarray, width: int) -> np.ndarray:
    """Intention: each digit's bytes reversed (the digit's own bits only), as int64."""
    kind = SWAPPABLE[width]
    return values.view(np.uint64).astype(kind).byteswap().astype(np.uint64).view(np.int64)


class ByteSwap(Rule):
    """Intention: the digits with their bytes reversed."""
    ident = 10
    name = "byte_swap"
    opens = True
    rank = 1

    def fit(self, x, hints):
        """Intention: only for digits two, four or eight bytes wide."""
        if hints.width not in SWAPPABLE or x.size < 2:
            return None
        return Fit([hints.width], [swapped(x, hints.width)], follow=0)

    def rebuild(self, settings, parts):
        """Intention: swapping back is swapping again."""
        return swapped(parts[0], settings[0])
