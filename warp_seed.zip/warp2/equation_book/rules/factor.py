# WARP3/warp2/equation_book/rules/factor.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/factor.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    A SHARED FACTOR. Every digit is the lowest digit plus a common factor
#    times a smaller number (the shape stretched); kept are the lowest, the
#    factor, and the smaller numbers (the part a further rule may make).
#  User intention (Andrew, 2026-11-14 15:42): "use the shape of equations and
#    shift them to where we need them" - a stretch is one such shift.
# ============================================================================
"""A shared factor: every digit is the lowest plus a factor times a smaller number."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule


class Factor(Rule):
    """Intention: the digits as a stretched copy of smaller numbers."""
    ident = 8
    name = "factor"

    def fit(self, x, hints):
        """Intention: the lowest digit and the greatest factor all the distances above it share (only when above 1)."""
        if x.size < 2:
            return None
        low = int(x.min())
        above = x - np.int64(low)
        if (above < 0).any():
            return None
        factor = int(np.gcd.reduce(above))
        if factor < 2:
            return None
        return Fit([low, factor], [above // np.int64(factor)], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the smaller numbers stretched back and moved up to the lowest digit."""
        low, factor = settings
        return parts[0] * np.int64(factor) + np.int64(low)
