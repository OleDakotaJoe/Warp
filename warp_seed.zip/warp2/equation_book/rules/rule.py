# WARP3/warp2/equation_book/rules/rule.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/rule.py
#  Used by   : every rule in warp2/equation_book/rules/; warp2/equation_book/
#              {search,written}.py.
#  Uses      : numpy.
#  Description:
#    What every rule of the equation book is: a way to make a list of digits
#    from smaller parts. `fit` takes the digits and gives the rule's settings
#    and its parts (one of which - `follow` - the search may go on to make
#    from a further rule: rules applied one on another's output); `rebuild`
#    takes the settings and the parts and gives the digits back exactly. A
#    rule's id is its one byte in the binary file, so ids never change once
#    given.
#  User intention (Andrew, 2026-11-14 15:42): "we can nest them where several
#    can exist in one and then fold out like a file system"; 16:16
#    "transformations after equations".
# ============================================================================
"""The shape every rule of the equation book has: fit (digits to parts) and rebuild (parts to digits)."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class Fit:
    """Intention: one rule fitted to some digits - its settings, its parts, and which part (if any) may be made by a
    further rule."""
    settings: list
    parts: list
    follow: int | None = None
    notes: dict = field(default_factory=dict)


@dataclass
class Hints:
    """Intention: what the search knows about the digits it is fitting - the width of one digit in bits and the
    distances at which digits repeat most (found from the digits themselves)."""
    width: int
    periods: list


class Rule:
    """Intention: the base of every rule - an id (its byte in the file), a name, fit and rebuild."""
    ident = 0
    name = "rule"
    opens = False   # Intention: a rule that only rewrites the digits one for one (it gains nothing alone, only what
                    # follows it can) - the search prices it by what can be made after it.
    rank = 0        # Intention: for such rules, their order in a chain - byte order (1) before a reading (2), each
                    # rank once - so the search tries each sensible order and no other.

    def fit(self, x: np.ndarray, hints: Hints):
        """Intention: the rule's settings and parts for these digits, or None when the rule cannot be used."""
        raise NotImplementedError

    def rebuild(self, settings: list, parts: list) -> np.ndarray:
        """Intention: the digits back, exactly, from the rule's settings and parts."""
        raise NotImplementedError
