# WARP2/warp2/equation_book/rules/signed.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/signed.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    SIGNED READING - the same digit read as a signed whole number (two's
#    complement): a digit whose top bit is set is the digit less 2^w. In the
#    file-as-one-number view every digit is unsigned, so a value and its
#    negative are far apart (900 and 64,636 for 16 bits); read signed they
#    are 900 and -900, and the rules after it (minus the one before, a run)
#    see what they are. Like float order it is a READING: one reading per
#    chain, after any byte swap; it gains nothing alone and is priced by the
#    chain that can follow it.
#  User intention (Andrew, 2026-11-14 16:11): "We also don't need to be
#    limited to standard numbers or representations".
# ============================================================================
"""Signed reading: a digit with its top bit set read as the digit less 2^w."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule

# Intention: the digit widths a signed whole number is stored in below 64 (a 64-bit digit is already read signed).
SIGNED_WIDTHS = (8, 16, 32)


class Signed(Rule):
    """Intention: the digits read as two's complement signed numbers."""
    ident = 11
    name = "signed"
    opens = True
    rank = 2

    def fit(self, x, hints):
        """Intention: digits with the top bit set taken down by 2^w."""
        if hints.width not in SIGNED_WIDTHS or x.size < 2:
            return None
        top = np.int64(1) << np.int64(hints.width - 1)
        return Fit([hints.width], [np.where(x >= top, x - 2 * top, x)], follow=0)

    def rebuild(self, settings, parts):
        """Intention: negative readings back to the digit (plus 2^w)."""
        (width,), held = settings, parts[0]
        return np.where(held < 0, held + (np.int64(1) << np.int64(width)), held)
