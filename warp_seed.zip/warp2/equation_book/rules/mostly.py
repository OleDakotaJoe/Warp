# WARP2/warp2/equation_book/rules/mostly.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/mostly.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    MOSTLY ONE DIGIT. The commonest digit stands everywhere except at a few
#    places; kept are that digit, the gaps between the places that differ,
#    and what stands there (the part a further rule may make).
#  User intention (Andrew, 2026-11-14 15:42): "systems were a part of the
#    output is taken and had a equation done to them" - the places that
#    differ are taken out and made on their own.
# ============================================================================
"""Mostly one digit: that digit, the gaps between the places that differ, and what stands there."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule


class Mostly(Rule):
    """Intention: one digit almost everywhere, and the few places that differ."""
    ident = 7
    name = "mostly"

    def fit(self, x, hints):
        """Intention: the commonest digit, the gaps between the other places, and what stands at them."""
        if x.size < 2:
            return None
        found, counts = np.unique(x, return_counts=True)
        common = int(found[np.argmax(counts)])
        where = np.flatnonzero(x != common)
        if where.size * 2 > x.size:
            return None
        gaps = np.diff(where, prepend=np.int64(-1)) - 1
        return Fit([common, x.size], [gaps.astype(np.int64), x[where]], follow=1)

    def rebuild(self, settings, parts):
        """Intention: the common digit everywhere, then each kept digit at its place."""
        common, n = settings
        gaps, held = parts
        out = np.full(n, common, dtype=np.int64)
        out[np.cumsum(gaps + 1) - 1] = held
        return out
