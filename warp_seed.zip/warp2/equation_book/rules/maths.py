# WARP2/warp2/equation_book/rules/maths.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/maths.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/{rule,price}.py; numpy.
#  Description:
#    THE OTHER MATHS BETWEEN BOXES. Each digit is made from the two before it by
#    one operation - their product, the one before times a set number, its square,
#    their difference, the bigger, the smaller - and which operation is used
#    follows a repeating pattern (length 1 to 3). Kept are the pattern, the set
#    number, and what is left (the starters and the adjustments).
#  User intention (Andrew, 2026-11-16 15:39): "it can use any math rules to any combination
#    of the boxes to create the next boxes and can be stored as a signature for it or
#    as a repeating pattern"; 16:20: "test it with all other math operations".
# ============================================================================
"""Each digit from the two before it by a product, a multiple, a square, a difference, the bigger or the smaller."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.price import price_of, width_of, wrapped
from warp2.equation_book.rules.rule import Fit, Rule

BACK = 2
TIMES = tuple(range(2, 17))                 # Intention: the set numbers tried for "the one before times k"
PRODUCT, SQUARE, APART, BIGGER, SMALLER, MULTIPLE = 0, 1, 2, 3, 4, 5
LONGEST = 3


def _one(way: int, a: int, b: int) -> int:
    """Intention: one box made from the one before (a) and the one before that (b), as whole numbers."""
    if way == PRODUCT:
        return a * b
    if way == SQUARE:
        return a * a
    if way == APART:
        return abs(wrapped(a - b))          # Intention: the difference wraps first, as the file's 64 bits do
    if way == BIGGER:
        return max(a, b)
    if way == SMALLER:
        return min(a, b)
    return a * (way - MULTIPLE + TIMES[0])


def _all(way: int, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Intention: the same for every place at once, wrapping as the file's 64 bits do."""
    with np.errstate(over="ignore"):
        if way == PRODUCT:
            return a * b
        if way == SQUARE:
            return a * a
        if way == APART:
            return np.abs(a - b)
        if way == BIGGER:
            return np.maximum(a, b)
        if way == SMALLER:
            return np.minimum(a, b)
        return a * np.int64(way - MULTIPLE + TIMES[0])


WAYS = tuple(range(MULTIPLE + len(TIMES)))


class Maths(Rule):
    """Intention: any of the other operations between the boxes, the operation following a repeating pattern."""
    ident = 16
    name = "maths"

    def fit(self, x, hints):
        """Intention: each place of the pattern takes the operation with the lowest quick price there; the cheapest
        pattern length is kept when it is below the list as it stands."""
        n = x.size
        if n < 16:
            return None
        a, b = x[1:-1], x[:-2]
        with np.errstate(over="ignore"):
            lefts = [x[BACK:] - _all(way, a, b) for way in WAYS]
        plain = price_of(x[BACK:])
        best = None
        for length in range(1, LONGEST + 1):
            total, ways = 8 * length, []
            for place in range(length):
                widths = [width_of(left[place::length]) for left in lefts]
                way = int(np.argmin(widths))
                ways.append(way)
                total += widths[way] * lefts[way][place::length].size
            if best is None or total < best[0]:
                best = (total, ways)
        if best[0] >= plain:
            return None
        ways = best[1]
        left = x.copy()
        for place, way in enumerate(ways):
            left[BACK + place::len(ways)] = lefts[way][place::len(ways)]
        return Fit(ways, [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the two starters as they stand, then each digit = what is left there + the operation on the two
        before it."""
        left = parts[0]
        out = [int(v) for v in left[:BACK]]
        for i in range(BACK, left.size):
            made = wrapped(_one(settings[(i - BACK) % len(settings)], out[i - 1], out[i - 2]))
            out.append(wrapped(int(left[i]) + made))
        return np.array(out, dtype=np.int64)
