# WARP2/warp2/equation_book/rules/runs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/runs.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py, warp2/equation_book/
#              packed.py (size_of); numpy.
#  Description:
#    A RUN FROM A TO B. Digit i is a + i * step, the step a fraction with a
#    power-of-two bottom (top / 2^k), and what is kept is the run's settings
#    and each digit's difference from the run. The step is found from the
#    digits (least squares); the bottom is whichever of a few powers of two
#    leaves the smallest difference, priced exactly.
#  User intention (Andrew, 2026-11-14 15:42): "the continual results of a
#    linear equation form point a to b with an amount add or subtracted".
# ============================================================================
"""A run from a to b: digit i is a + i * top / 2^k, plus what is left over."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.packed import size_of
from warp2.equation_book.rules.rule import Fit, Rule

# Intention: the powers of two tried as the step's bottom - every fourth power up to 2^32 is enough to place a
# step finely, and each is priced exactly; the cheapest wins.
BOTTOMS = tuple(range(0, 33, 4))


def _run(n: int, k: int, top: int, a: int) -> np.ndarray:
    """Intention: the run's own digits - a + i * top / 2^k, rounded down - wrapping as int64 does."""
    i = np.arange(n, dtype=np.int64)
    return ((i * np.int64(top)) >> np.int64(k)) + np.int64(a)


class Run(Rule):
    """Intention: a run from a to b (any straight line through the digits)."""
    ident = 1
    name = "run"

    def fit(self, x, hints):
        """Intention: the straight run that leaves the smallest difference, and that difference."""
        n = x.size
        if n < 3:
            return None
        i = np.arange(n, dtype=np.float64)
        slope = float(np.polyfit(i, x.astype(np.float64), 1)[0])
        best = None
        for k in BOTTOMS:
            top = int(round(slope * (1 << k)))
            if abs(top) >= 1 << 62:
                continue
            base = _run(n, k, top, 0)
            a = int(np.median(x - base))
            left = x - base - np.int64(a)
            size = size_of(left)
            if best is None or size < best[0]:
                best = (size, k, top, a, left)
        if best is None:
            return None
        _, k, top, a, left = best
        return Fit([k, top, a], [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the run plus what was left over."""
        k, top, a = settings
        left = parts[0]
        return left + _run(left.size, k, top, a)
