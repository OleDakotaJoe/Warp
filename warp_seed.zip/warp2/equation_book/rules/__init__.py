# WARP2/warp2/equation_book/rules/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/__init__.py
#  Used by   : warp2/equation_book/rules/* (the package).
#  Uses      : nothing.
#  Description:
#    THE EQUATION BOOK'S RULES - each one a way to make a list of digits from
#    smaller parts, one file a family:
#      rule.py       - what every rule is (fit, rebuild, id) and its hints
#      runs.py       - a run from a to b
#      earlier.py    - each digit from the one p places before (minus, or XOR)
#      end.py        - end transforms on that rule's output (negated, masked)
#      book.py       - a book of the distinct digits and the entry at each place
#      mostly.py     - mostly one digit, and the places that differ
#      factor.py     - a shared factor (the shape stretched)
#      order.py      - float order (the same digit written another way)
#      swap.py       - byte swap (a lowest-byte-first value read the right way)
#      signed.py     - signed reading (two's complement)
#      vocabulary.py - every rule by id, and the hints rules are fitted with
#  User intention (Andrew, 2026-11-14 15:52): "We just start with the obvious
#    and lead into the more exotic as we go and keep track of the cheapest to
#    a known point."
# ============================================================================
"""The equation book's rules."""
