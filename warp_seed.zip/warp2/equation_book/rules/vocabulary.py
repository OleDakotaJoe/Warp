# WARP2/warp2/equation_book/rules/vocabulary.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/vocabulary.py
#  Used by   : warp2/equation_book/{search,written}.py.
#  Uses      : warp2/equation_book/rules/{rule,runs,earlier,end,book,mostly,
#              factor,order,swap,signed}.py; numpy.
#  Description:
#    THE VOCABULARY - every rule the book can use, found by its id (its byte
#    in the binary file), and the hints a search gives the rules: the width
#    of one digit and the distances at which the digits repeat most. Those
#    distances come from the digits themselves (the autocorrelation of the
#    digits and of their steps, each worked out once by FFT): the distance 1,
#    and every peak that stands above a typical distance by more than chance,
#    at least half as far as the strongest, and is not a multiple of a nearer
#    peak - so a row's width or a block's length is found without being told. A new rule joins
#    by being listed here with a new id; ids already given never change.
#  User intention (Andrew, 2026-11-14 15:52): "We just start with the obvious
#    and lead into the more exotic as we go"; 16:11 "Any alteration".
# ============================================================================
"""Every rule the equation book can use, by id, and the hints the rules are fitted with."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.book import Book
from warp2.equation_book.rules.earlier import Earlier, XorEarlier
from warp2.equation_book.rules.end import Masked, Negated
from warp2.equation_book.rules.factor import Factor
from warp2.equation_book.rules.mostly import Mostly
from warp2.equation_book.rules.order import FloatOrder
from warp2.equation_book.rules.rule import Hints
from warp2.equation_book.rules.signed import Signed
from warp2.equation_book.rules.runs import Run
from warp2.equation_book.rules.swap import ByteSwap

RULES = (Run(), Earlier(), XorEarlier(), Negated(), Masked(), Book(), Mostly(), Factor(), FloatOrder(), ByteSwap(), Signed())
BY_ID = {rule.ident: rule for rule in RULES}


def _standing_out(signal: np.ndarray) -> dict:
    """{distance: how far its autocorrelation stands above a typical distance's} for the peaks that count.

    Intention: worked out once by FFT. Even a list with no repeat shows peaks by chance; the largest chance peak
    among n/2 distances is about sqrt(2 ln n / n). A peak says something only when it stands that far above a
    TYPICAL distance (the median over all distances) - so a flat autocorrelation with ripples, or one that is high
    everywhere because the values climb, offers no distance at all.
    """
    n = signal.size
    if n < 4:
        return {}
    centred = signal.astype(np.float64) - float(signal.astype(np.float64).mean())
    size = 1 << int(2 * n - 1).bit_length()
    spectrum = np.fft.rfft(centred, size)
    corr = np.fft.irfft(spectrum * np.conj(spectrum), size)[:n // 2 + 1]
    if corr[0] <= 0:
        return {}
    corr = corr / corr[0]
    inner = corr[1:-1]
    peaks = np.flatnonzero((inner > corr[:-2]) & (inner >= corr[2:])) + 1
    chance = float(np.sqrt(2.0 * np.log(n) / n))
    above = corr - float(np.median(corr[1:]))
    peaks = peaks[(peaks >= 2) & (above[peaks] > chance)]
    return {int(p): float(above[p]) for p in peaks}


def periods_of(x: np.ndarray) -> list:
    """The distances at which these digits repeat most: 1, then the peaks that stand out in the autocorrelation of
    the digits or of their steps, the strongest first.

    Intention: both are measured - a row that repeats shows in the digits and in their steps; digits that climb
    show nothing in the digits (alike at every distance) but their steps still show a repeat. A peak counts when it
    is at least half as far above a typical distance as the strongest one of its own measure, and is not a multiple
    of a nearer peak already taken (the multiples of a row's width say nothing new).
    """
    x = np.asarray(x, dtype=np.int64)
    found = {}
    for signal in (x, np.diff(x)):
        out = _standing_out(signal)
        if out:
            strongest = max(out.values())
            for p, rise in out.items():
                if rise >= strongest / 2:
                    found[p] = max(rise, found.get(p, 0.0))
    taken = [1]
    for p in sorted(found, key=lambda q: -found[q]):
        if not any(p % q == 0 for q in taken if q > 1):
            taken.append(p)
    return taken


def hints_for(x: np.ndarray, width: int) -> Hints:
    """Intention: the hints for one list of digits of this width."""
    return Hints(width=width, periods=periods_of(x))
