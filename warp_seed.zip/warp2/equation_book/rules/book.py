# WARP2/warp2/equation_book/rules/book.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/rules/book.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    A BOOK OF THE DISTINCT DIGITS. Every distinct digit once, in order (kept
#    as the steps between them), and which entry stands at each place. The
#    places are the part a further rule may make (they often run or repeat).
#  User intention (Andrew, 2026-11-14 15:34): "keep a book of the best" - at
#    the smallest scale, a book of the values themselves.
# ============================================================================
"""A book of the distinct digits, and which entry stands at each place."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule


class Book(Rule):
    """Intention: every distinct digit once, and its entry number at each place."""
    ident = 6
    name = "book"

    def fit(self, x, hints):
        """Intention: the distinct digits as steps from the one before, and each place's entry number."""
        if x.size < 2:
            return None
        found, places = np.unique(x, return_inverse=True)
        if found.size == x.size:
            return None
        steps = np.diff(found, prepend=np.int64(0))
        return Fit([], [steps, places.astype(np.int64)], follow=1)

    def rebuild(self, settings, parts):
        """Intention: the book back from its steps, then each place's entry."""
        steps, places = parts
        return np.cumsum(steps)[places]
