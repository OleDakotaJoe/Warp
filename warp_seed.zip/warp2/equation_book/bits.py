# WARP2/warp2/equation_book/bits.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/bits.py
#  Used by   : warp2/equation_book/{packed,written,keep}.py; tests.
#  Uses      : numpy.
#  Description:
#    The small measures everything else counts with: a signed whole number
#    folded to an unsigned one (0, -1, 1, -2 ... as 0, 1, 2, 3 ...) and back;
#    how many bits each unsigned number needs; and whole numbers of any size
#    written seven bits a byte (put / take) - the corpus's varint stops at 63
#    bits, and a 64-bit digit's setting can need all 64. Whole numbers are
#    int64 and wrap the way two's complement does, so a rule that wraps on
#    the way in wraps back the same way on the way out - exact.
#  User intention (Andrew, 2026-11-14 15:59): "The only things that matter
#    are storage space and time to generate from storage" - space is counted
#    in bits, by these.
# ============================================================================
"""Folding signed numbers and counting the bits numbers need."""
from __future__ import annotations

import numpy as np


def fold(values) -> np.ndarray:
    """Intention: signed int64 as unsigned, small either side of nought staying small (0,-1,1,-2 -> 0,1,2,3)."""
    v = np.asarray(values, dtype=np.int64)
    return ((v << np.int64(1)) ^ (v >> np.int64(63))).view(np.uint64)


def unfold(values) -> np.ndarray:
    """Intention: the signed numbers `fold` was given."""
    u = np.asarray(values, dtype=np.uint64)
    return ((u >> np.uint64(1)) ^ (np.uint64(0) - (u & np.uint64(1)))).view(np.int64)


def widths(values) -> np.ndarray:
    """How many bits each unsigned number needs (nought needs none).

    Intention: read from the float exponent in one pass, then made exact: a float holds 53 bits, so a number
    above 2**53 can round up to the next power of two and read one bit too wide - for those, the bit the
    exponent claims is checked, and the count taken down when it is not there.
    """
    u = np.asarray(values, dtype=np.uint64)
    out = np.frexp(u.astype(np.float64))[1].astype(np.int64)
    big = np.flatnonzero(out > 53)
    if big.size:
        claimed = out[big]
        out[big] = claimed - ((u[big] >> (claimed - 1).astype(np.uint64)) == 0)
    return out


def put(numbers) -> bytes:
    """Intention: whole numbers that are not negative, of any size, seven bits a byte (the top bit says more
    follows)."""
    out = bytearray()
    for number in numbers:
        number = int(number)
        while True:
            low = number & 0x7F
            number >>= 7
            if number:
                out.append(low | 0x80)
            else:
                out.append(low)
                break
    return bytes(out)


def take(view, at: int) -> tuple:
    """Intention: (the number written by `put` at `at`, where the next thing starts)."""
    number = shift = 0
    while True:
        byte = view[at]
        at += 1
        number |= (byte & 0x7F) << shift
        shift += 7
        if not byte & 0x80:
            return number, at
