# WARP2/warp2/equation_book/written.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/written.py
#  Used by   : warp2/equation_book/{keep,search}.py; tests.
#  Uses      : warp2/equation_book/{bits,packed}.py,
#              warp2/equation_book/rules/vocabulary.py (BY_ID); numpy.
#  Description:
#    A CHAIN OF RULES AS BINARY, AND BACK. Layout: how many steps; then each
#    step - its rule's id (one byte), how many settings and each setting
#    (folded, seven bits a byte), how many parts, which part a further rule makes
#    (+1; 0 for none), and every other part bit-packed (packed.py); then,
#    when the last step leaves a part to be made (or there is no step), that
#    leftover bit-packed. Read back: the leftover is put in its step's place,
#    the step rebuilds its digits, and so on back to the first step - the
#    same digits, exactly. step_size prices a step in exactly the bytes it
#    is written in, so the search compares what will really be kept.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store
#    the file as a binary".
# ============================================================================
"""A chain of rules and its parts written as binary, and read back to the digits."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.bits import fold, put, take, unfold
from warp2.equation_book.packed import pack, size_of, unpack
from warp2.equation_book.rules.vocabulary import BY_ID


def _settings_bytes(settings: list) -> bytes:
    """Intention: how many settings, then each one folded, seven bits a byte."""
    folded = fold(np.array(settings, dtype=np.int64)).tolist() if settings else []
    return put([len(settings)] + folded)


def step_size(rule, fit) -> int:
    """Intention: the bytes one step is written in, without the part a further rule makes."""
    kept = sum(size_of(part) for at, part in enumerate(fit.parts) if at != fit.follow)
    follow = 0 if fit.follow is None else fit.follow + 1
    return 1 + len(_settings_bytes(fit.settings)) + len(put([len(fit.parts), follow])) + kept


def write_chain(chain: list, left) -> bytes:
    """Intention: the steps in order, then the leftover the last one leaves (when it leaves one)."""
    out = [put([len(chain)])]
    for rule, fit in chain:
        follow = 0 if fit.follow is None else fit.follow + 1
        out.append(bytes([rule.ident]) + _settings_bytes(fit.settings) + put([len(fit.parts), follow]))
        out.extend(pack(part) for at, part in enumerate(fit.parts) if at != fit.follow)
    if not chain or chain[-1][1].follow is not None:
        out.append(pack(left))
    return b"".join(out)


def _read_numbers(view, at: int, count: int) -> tuple:
    """Intention: `count` numbers written by `put`, from `at`, and where they end."""
    numbers = []
    for _ in range(count):
        value, at = take(view, at)
        numbers.append(value)
    return numbers, at


def read_chain(raw, at: int = 0) -> tuple:
    """(the digits, where the chain ended) - every step rebuilt from the last back to the first.

    Intention: the exact inverse of write_chain.
    """
    view = memoryview(raw)
    (steps,), at = _read_numbers(view, at, 1)
    read = []
    for _ in range(steps):
        rule = BY_ID[view[at]]
        at += 1
        (count,), at = _read_numbers(view, at, 1)
        settings, at = _read_numbers(view, at, count)
        settings = unfold(np.array(settings, dtype=np.uint64)).tolist() if settings else []
        (parts, follow), at = _read_numbers(view, at, 2)
        kept = []
        for place in range(parts):
            if place == follow - 1:
                kept.append(None)
                continue
            part, at = unpack(raw, at)
            kept.append(part)
        read.append((rule, settings, kept, follow - 1))
    digits = None
    if not read or read[-1][3] >= 0:
        digits, at = unpack(raw, at)
    for rule, settings, kept, follow in reversed(read):
        if follow >= 0:
            kept[follow] = digits
        digits = rule.rebuild(settings, kept)
    return digits, at
