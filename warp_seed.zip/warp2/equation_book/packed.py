# WARP2/warp2/equation_book/packed.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/packed.py
#  Used by   : warp2/equation_book/{search,written}.py; tests.
#  Uses      : warp2/equation_book/bits.py (fold, unfold, widths, put,
#              take); numpy.
#  Description:
#    A LIST OF WHOLE NUMBERS AS BINARY, BIT-PACKED IN BLOCKS. Each number is
#    kept as how far it is above the list's lowest number (the lowest kept
#    once), in blocks of B numbers, each block at the width its widest
#    number needs - so a run of small leftovers takes few bits and a run of
#    noughts takes none. B is whichever power of two makes the whole
#    smallest, worked out before anything is written (size_of), so the
#    search can price a leftover without writing it. Read back exactly.
#    Layout: count; lowest (folded); B; one byte per block (its width); then
#    every number's bits, highest first, end to end, padded to a byte.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store
#    the file as a binary" - the leftover of every recipe is kept this way.
# ============================================================================
"""Whole numbers bit-packed in blocks, each at the width its widest number needs, and back."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.bits import fold, put, take, unfold, widths


def _above_lowest(values: np.ndarray) -> tuple:
    """Intention: (the lowest number, every number's distance above it as unsigned) - wrapping as int64 does."""
    v = np.asarray(values, dtype=np.int64)
    low = int(v.min())
    return low, (v - np.int64(low)).view(np.uint64)


def _block_widths(each: np.ndarray, block: int) -> np.ndarray:
    """Intention: each block's width - the most bits any of its numbers needs."""
    blocks = -(-each.size // block)
    padded = np.zeros(blocks * block, dtype=np.int64)
    padded[:each.size] = each
    return padded.reshape(blocks, block).max(axis=1)


def _best_block(each: np.ndarray) -> tuple:
    """(bytes, block size) for the block size, a power of two, that makes the whole smallest.

    Intention: every power of two up to the list's own length is priced exactly (one byte a block for its width,
    the bits themselves rounded up to a byte, the block size's own varint) - nothing is set. Each size's block
    widths come from the size before it (the wider of each two neighbouring blocks), so all sizes together cost
    about two passes over the list.
    """
    best = None
    block = 1
    tops = each.copy()
    while True:
        last = each.size - (tops.size - 1) * block
        bits = int(tops[:-1].sum()) * block + int(tops[-1]) * last
        size = tops.size + -(-bits // 8) + len(put([block]))
        if best is None or size < best[0]:
            best = (size, block)
        if block >= each.size:
            return best
        if tops.size % 2:
            tops = np.append(tops, 0)
        tops = np.maximum(tops[0::2], tops[1::2])
        block *= 2


def size_of(values) -> int:
    """Intention: the bytes `pack` will write for these numbers, without writing them."""
    v = np.asarray(values, dtype=np.int64)
    if v.size == 0:
        return len(put([0]))
    low, above = _above_lowest(v)
    size, _ = _best_block(widths(above))
    return len(put([v.size, int(fold(np.array([low]))[0])])) + size


def pack(values) -> bytes:
    """Intention: the numbers as binary - count, lowest, block size, block widths, then the bits."""
    v = np.asarray(values, dtype=np.int64)
    if v.size == 0:
        return put([0])
    low, above = _above_lowest(v)
    each = widths(above)
    _, block = _best_block(each)
    tops = _block_widths(each, block)
    per = np.repeat(tops, block)[:v.size]
    head = put([v.size, int(fold(np.array([low]))[0]), block])
    return head + tops.astype(np.uint8).tobytes() + _bits_out(above, per)


def _bits_out(above: np.ndarray, per: np.ndarray) -> bytes:
    """Intention: every number at its block's width, highest bit first, end to end, packed eight to a byte."""
    total = int(per.sum())
    out = np.zeros(total, dtype=np.uint8)
    starts = np.cumsum(per) - per
    for width in np.unique(per[per > 0]).tolist():
        at = np.flatnonzero(per == width)
        shifts = np.arange(width - 1, -1, -1, dtype=np.uint64)
        bits = ((above[at, None] >> shifts) & np.uint64(1)).astype(np.uint8)
        out[(starts[at, None] + np.arange(width)).ravel()] = bits.ravel()
    return np.packbits(out).tobytes()


def unpack(raw, at: int = 0) -> tuple:
    """(the numbers, where the next thing in `raw` starts) - the exact inverse of `pack`.

    Intention: a packed list can sit among other things in one binary file, so it reads only its own bytes and
    says where it ended.
    """
    view = memoryview(raw)
    count, at = take(view, at)
    if count == 0:
        return np.zeros(0, dtype=np.int64), at
    folded, at = take(view, at)
    low = int(unfold(np.array([folded], dtype=np.uint64))[0])
    block, at = take(view, at)
    blocks = -(-count // block)
    tops = np.frombuffer(view[at:at + blocks], dtype=np.uint8).astype(np.int64)
    at += blocks
    per = np.repeat(tops, block)[:count]
    total = int(per.sum())
    nbytes = -(-total // 8)
    bits = np.unpackbits(np.frombuffer(view[at:at + nbytes], dtype=np.uint8))[:total]
    at += nbytes
    above = np.zeros(count, dtype=np.uint64)
    starts = np.cumsum(per) - per
    for width in np.unique(per[per > 0]).tolist():
        where = np.flatnonzero(per == width)
        got = bits[(starts[where, None] + np.arange(width))].astype(np.uint64)
        value = np.zeros(where.size, dtype=np.uint64)
        for column in range(width):
            value = (value << np.uint64(1)) | got[:, column]
        above[where] = value
    return (above + np.uint64(low & 0xFFFFFFFFFFFFFFFF)).view(np.int64), at
