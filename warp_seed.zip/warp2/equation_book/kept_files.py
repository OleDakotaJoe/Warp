# WARP2/warp2/equation_book/kept_files.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/kept_files.py
#  Used by   : warp2/store/small_kg/{pack,names,build}.py (every file of the
#              small KG), warp2/tags/dehydrated/book.py (the book's pages),
#              warp2/tags/dehydrated/small_bytes.py (a segment's own file).
#  Uses      : warp2/equation_book/keep.py, warp2/util.py (atomic_write_bytes);
#              warp2/pieces_book/one_file.py (back_one - only when a file bears the pieces book's mark).
#  Description:
#    A FILE KEPT BY FUNCTION, UNDER ITS OWN NAME. `write` keeps a file's bytes
#    as the function book's recipe for the one number they are (keep_bytes) and
#    puts that in place of the file; `read` gives the bytes back - unfolding a
#    kept file, or reading a file not kept yet as it is, so every reader works
#    the same before, during and after the files are kept. A file bigger than
#    a CHUNK is not taken as one number: it is cut into chunks, each kept as its
#    own number, written one after another (the numbers side by side make the
#    whole - Andrew 2026-11-15 13:31: "It shouldn't try to do it all in one
#    chunk. At first, it should use smaller chunks"), so no file needs more
#    memory or time than a chunk does, and the chunks can be kept at once by
#    several processes. BUILD_LOG 1520d: a file held in the pieces book's form
#    (its own mark, warp2/pieces_book/one_file.py) is unfolded here too, so the
#    warp reads it through the same door (Andrew 2026-11-18 17:45: "it needs to
#    have the warp hold them in that form").
#  User intention (Andrew, 2026-11-15 13:23): "The dehydrated smaller kg should
#    be stored in the functions by compression by function system that we
#    already made." (13:25): "taking the raw binaries of the files ... then
#    turning them into numbers, then storing that number with a function."
# ============================================================================
"""Files kept by the function book under their own names, read back exactly."""
from __future__ import annotations

import struct
from pathlib import Path

from warp2.equation_book.keep import MAGIC, bytes_back, keep_bytes
from warp2.util import atomic_write_bytes

# Intention: the mark of a file kept as chunks, and the most bytes one chunk takes - what keep_bytes handles in about
# a second and a few MB of memory (measured: 50 KB in 0.7 s; every digit width is tried, the 1-bit one holding 64
# bytes a byte).
CHUNKED = b"EQC\x01"
# Intention (1520d): the mark of a file held in the pieces book's form (warp2/pieces_book/one_file.py).
PIECES = b"PCB\x01"
CHUNK = 65536
_SIZE = struct.Struct("<I")


def is_kept(raw: bytes) -> bool:
    """Intention: whether these bytes are a file kept by the function book (they start with its mark, whole or in
    chunks)."""
    head = bytes(raw[:len(MAGIC)])
    return head in (MAGIC, CHUNKED, PIECES)


def back(kept: bytes) -> bytes:
    """Intention: a kept file's bytes given back - one recipe, or its chunks' recipes one after another, or the
    pieces book's form read back (1520d)."""
    if bytes(kept[:len(PIECES)]) == PIECES:
        # Intention (1520d): brought in only when such a file is met - the pieces book itself reads files through here.
        from warp2.pieces_book.one_file import back_one
        return back_one(kept)
    if bytes(kept[:len(CHUNKED)]) != CHUNKED:
        return bytes_back(kept)
    view, at = memoryview(kept), len(CHUNKED)
    (count,) = _SIZE.unpack_from(view, at)
    at += _SIZE.size
    out = []
    for _ in range(count):
        (length,) = _SIZE.unpack_from(view, at)
        at += _SIZE.size
        out.append(bytes_back(bytes(view[at:at + length])))
        at += length
    return b"".join(out)


def read(path) -> bytes:
    """Intention: a file's bytes - unfolded when it is kept by function, as they are when it is not kept yet."""
    raw = Path(path).read_bytes()
    return back(raw) if is_kept(raw) else raw


def chunks_of(raw: bytes) -> list:
    """Intention: the chunks a file is kept as (one when it is no bigger than a CHUNK)."""
    raw = bytes(raw)
    return [raw[at:at + CHUNK] for at in range(0, len(raw), CHUNK)] or [b""]


def joined(kept_chunks: list) -> bytes:
    """Intention: kept chunks written as one kept file (a single chunk is the plain recipe)."""
    if len(kept_chunks) == 1:
        return kept_chunks[0]
    out = [CHUNKED, _SIZE.pack(len(kept_chunks))]
    for kept in kept_chunks:
        out += [_SIZE.pack(len(kept)), kept]
    return b"".join(out)


def write(path, raw: bytes, keep_each=None) -> int:
    """Intention: these bytes kept by function in place of the file (written whole, then moved in); what is on disk.
    `keep_each(chunks)` may keep the chunks at once (a pool); by default one after another. Read back and checked
    before it replaces the file. A file whose own bytes start with the book's mark is kept too, so it is never read
    back as a recipe."""
    pieces = chunks_of(raw)
    kept = joined(list(keep_each(pieces)) if keep_each is not None else [keep_bytes(piece) for piece in pieces])
    if back(kept) != bytes(raw):
        raise ValueError(f"{Path(path).name} did not come back the same from its kept form - nothing replaced")
    atomic_write_bytes(Path(path), kept)
    return len(kept)

