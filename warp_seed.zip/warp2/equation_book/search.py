# WARP2/warp2/equation_book/search.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/search.py
#  Used by   : warp2/equation_book/keep.py; tests.
#  Uses      : warp2/equation_book/{packed,written}.py,
#              warp2/equation_book/rules/vocabulary.py; numpy.
#  Description:
#    THE CHEAPEST CHAIN OF RULES. Every rule is fitted to the digits and
#    priced exactly in the bytes it would be written in (its id, settings,
#    the parts it keeps, and the part a further rule may make, as it stands).
#    The cheapest is taken only when it is smaller than the digits kept
#    plain; then the same is done to the part it leaves to be made, and so
#    on, each rule on the last one's output, for as long as that gains. A
#    rule that only rewrites the digits one for one (float order) is priced
#    by the whole chain that can follow it, since it gains nothing alone.
#    Nothing is set: it ends because every step must leave a smaller part
#    than the one it was given.
#  User intention (Andrew, 2026-11-14 15:52): "start with the obvious and
#    lead into the more exotic as we go and keep track of the cheapest to a
#    known point"; 15:59: "The only things that matter are storage space and
#    time to generate from storage."
# ============================================================================
"""The cheapest chain of rules for a list of digits, each on the last one's leftover, while it gains."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.packed import size_of
from warp2.equation_book.rules.vocabulary import RULES, hints_for
from warp2.equation_book.written import step_size


def best_chain(x: np.ndarray, width: int, opened: int = 0) -> tuple:
    """(bytes, [(rule, fit), ...], the leftover the last rule leaves - or the digits themselves when no rule gains).

    Intention: `width` is the bit width of one digit of the file's number. A rule that only rewrites the digits
    (byte swap, a reading) keeps them the file's own digits, so what follows it keeps the width - in rank order,
    each rank once (`opened` is the highest rank used so far); the digits any other rule leaves are no longer the
    file's own, so below it the search goes on with no width.
    """
    x = np.asarray(x, dtype=np.int64)
    plain = size_of(x)
    hints = hints_for(x, width)
    best = None
    for rule in RULES:
        if rule.opens and rule.rank <= opened:
            continue
        fit = rule.fit(x, hints)
        if fit is None:
            continue
        head = step_size(rule, fit)
        if fit.follow is None:
            priced = (head, [(rule, fit)], None)
        elif rule.opens:
            size, chain, left = best_chain(fit.parts[fit.follow], width, rule.rank)
            priced = (head + size, [(rule, fit)] + chain, left)
        else:
            priced = (head + size_of(fit.parts[fit.follow]), [(rule, fit)], fit.parts[fit.follow])
        if best is None or priced[0] < best[0]:
            best = priced
    if best is None or best[0] >= plain:
        return plain, [], x
    size, chain, left = best
    rule, fit = chain[-1]
    if len(chain) == 1 and fit.follow is not None and not rule.opens:
        deeper, more, last = best_chain(left, 0, opened)
        if more:
            return size - size_of(left) + deeper, chain + more, last
    return best
