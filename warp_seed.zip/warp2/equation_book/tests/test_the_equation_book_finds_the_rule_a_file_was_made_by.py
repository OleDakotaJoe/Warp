# WARP3/warp2/equation_book/tests/test_the_equation_book_finds_the_rule_a_file_was_made_by.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/tests/test_the_equation_book_finds_the_rule_a_file_was_made_by.py
#  Used by   : the test suite.
#  Uses      : warp2/equation_book/{keep,search,digits}.py; numpy;
#              (stdlib) random.
#  Description:
#    A file made by a rule is kept as that rule: noughts, a run written
#    lowest byte first (byte swap, then a run), repeated text, a run that
#    flips sign every step (an end transform: negated), rows that flip the
#    same bits every time (an end transform: masked), mostly-nought floats.
#    Random bytes stay as they are - nothing to find.
#  User intention (Andrew, 2026-11-14 16:16): "have them transformed at the
#    end. And if that equals out to the number, then it fits."
# ============================================================================
from __future__ import annotations

import random

import numpy as np

from warp2.equation_book import digits, keep
from warp2.equation_book.search import best_chain


def _names(raw, width):
    """Intention: the rule names of the cheapest chain for a file read in digits of this width."""
    _, chain, _ = best_chain(digits.digits_of(raw, width), width)
    return [rule.name for rule, _ in chain]


def test_noughts_and_repeated_text_become_almost_nothing():
    assert len(keep.keep_bytes(bytes(20_000))) < 40
    assert len(keep.keep_bytes(b"the warp keeps the KG small " * 700)) < 100


def test_a_run_written_lowest_byte_first_is_found_after_a_byte_swap():
    raw = (np.arange(5000, dtype=np.int64) * 7 + 3).astype("<i4").tobytes()
    assert len(keep.keep_bytes(raw)) < 60
    assert _names(raw, 32)[:2] == ["byte_swap", "run"]


def test_a_run_that_flips_sign_every_step_is_an_end_transform():
    rng = np.random.default_rng(7)
    values = np.empty(6000, dtype=np.int64)
    values[0] = 900
    for i in range(1, values.size):
        values[i] = -values[i - 1] + int(rng.integers(-1, 2))
    raw = values.astype(">i2").tobytes()
    assert "negated" in _names(raw, 16)
    assert len(keep.keep_bytes(raw)) < len(raw) // 5


def test_rows_that_flip_the_same_bits_every_time_are_an_end_transform():
    rng = np.random.default_rng(8)
    row = rng.integers(0, 2**16, 64)
    rows = [row]
    for _ in range(80):
        rows.append(rows[-1] ^ 0x5A5A)
    raw = np.concatenate(rows).astype(">u2").tobytes()
    assert "masked" in _names(raw, 16)
    assert len(keep.keep_bytes(raw)) < 400


def test_mostly_nought_floats_keep_only_what_differs():
    rng = np.random.default_rng(9)
    values = np.zeros(20_000, dtype="<f4")
    values[rng.choice(20_000, 300, replace=False)] = rng.standard_normal(300)
    raw = values.tobytes()
    assert len(keep.keep_bytes(raw)) < len(raw) // 10


def test_random_bytes_stay_as_they_are():
    raw = random.Random(10).randbytes(8000)
    kept = keep.keep_bytes(raw)
    assert kept[len(keep.MAGIC)] == keep.AS_IT_IS and keep.bytes_back(kept) == raw
