# WARP2/warp2/equation_book/tests/test_each_rule_of_the_equation_book_rebuilds_what_it_fitted.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/equation_book/tests/test_each_rule_of_the_equation_book_rebuilds_what_it_fitted.py
#  Used by   : the test suite.
#  Uses      : warp2/equation_book/rules/vocabulary.py, warp2/equation_book/
#              {written,packed}.py; numpy.
#  Description:
#    Every rule in the vocabulary, fitted to digits it applies to, rebuilds
#    exactly those digits from its settings and parts - on small values, on
#    values that wrap at the int64 edges, and as a written chain read back.
#    Rule ids are unique (each is a byte in the file), and the repeat
#    distances are found from the digits themselves (a row's width).
#  User intention (Andrew, 2026-11-14 15:42): "we can nest them where several
#    can exist in one and then fold out like a file system".
# ============================================================================
from __future__ import annotations

import numpy as np

from warp2.equation_book.packed import size_of
from warp2.equation_book.rules.rule import Hints
from warp2.equation_book.rules.vocabulary import BY_ID, RULES, periods_of
from warp2.equation_book.written import read_chain, step_size, write_chain


def _cases():
    """Intention: digits each rule applies to - rows with structure, a sparse list, a stretched list, float bits."""
    rng = np.random.default_rng(11)
    rows = np.tile(rng.integers(0, 1000, 48), 40) + np.repeat(np.arange(40), 48)
    sparse = np.zeros(3000, dtype=np.int64)
    sparse[rng.choice(3000, 40, replace=False)] = rng.integers(-50, 50, 40)
    floats = np.sin(np.arange(2000) / 9).astype(">f4").view(">u4").astype(np.int64)
    edges = np.array([-(2**63), 2**63 - 1, 0, -1, 2**62, -(2**62)] * 50, dtype=np.int64)
    made = [3, -7, 11]                                   # Intention: a column made by Andrew's add / subtract pattern
    for i in range(3, 1500):
        step = made[i - 1] - made[i - 3] if i % 2 else made[i - 2] - made[i - 1] + made[i - 3]
        made.append((step + 2**63) % 2**64 - 2**63)      # Intention: kept in the file's 64 bits, as the rule itself wraps
    made = np.array(made, dtype=np.int64)
    made[::7] ^= rng.integers(0, 3, made[::7].size)        # Intention: small adjustments on top of the pattern
    top = np.full(400, 2**63 - 1, dtype=np.int64) - rng.integers(0, 5, 400)   # Intention: digits at the very top (the Run overflow)
    lanes = np.stack([np.arange(300) * 7, np.full(300, 12345), 900000 - np.arange(300) * 3], axis=1).reshape(-1)   # Intention: three lanes woven (a shift pulls them apart)
    mixed = rng.permutation(np.arange(2000, dtype=np.int64) * 5 + 17)                    # Intention: a list that is a run once sorted
    turns = np.resize(np.array([1000, -40, 77777, 3]), 1200) + rng.integers(0, 4, 1200)  # Intention: amounts taking turns
    calm = rng.integers(0, 50, 1500)
    calm[rng.choice(np.arange(1, 1500), 30, replace=False)] = rng.integers(10**12, 10**13, 30)   # Intention: wide digits put in
    trig = []
    for v in rng.integers(0, 9, 900).tolist():                                           # Intention: a wide digit right after every 4
        trig += [v, int(rng.integers(10**10, 10**11))] if v == 4 else [v]
    again = np.repeat(rng.integers(0, 10**6, 300), rng.integers(1, 6, 300))              # Intention: digits said again
    grown = [3, 5]
    for i in range(2, 600):
        grown.append(((grown[i - 1] * grown[i - 2] if i % 2 else grown[i - 1] * 3) + int(rng.integers(0, 2)) + 2**63) % 2**64 - 2**63)
    divided, r = [], 123                                                                 # Intention: 123 / 457 in base 65,536
    for _ in range(800):
        r *= 65536; divided.append(r // 457); r %= 457
    return [(lanes.astype(np.int64), 64), (mixed, 64), (turns.astype(np.int64), 64), (calm.astype(np.int64), 64),
            (np.array(trig, dtype=np.int64), 64), (again.astype(np.int64), 64), (np.array(grown, dtype=np.int64), 64),
            (np.array(divided, dtype=np.int64), 16), (made, 64), (top, 64), (rows.astype(np.int64), 64), (sparse, 64), (rows.astype(np.int64) * 6 + 5, 64), (floats, 32),
            (edges, 64), (np.arange(1000, dtype=np.int64) * 3, 16)]


def test_every_rule_rebuilds_the_digits_it_fitted():
    for x, width in _cases():
        hints = Hints(width=width, periods=periods_of(x) + [48])
        for rule in RULES:
            fit = rule.fit(x, hints)
            if fit is None:
                continue
            assert np.array_equal(rule.rebuild(fit.settings, list(fit.parts)), x), rule.name


def test_a_written_chain_reads_back_and_is_priced_exactly():
    for x, width in _cases():
        hints = Hints(width=width, periods=periods_of(x))
        for rule in RULES:
            fit = rule.fit(x, hints)
            if fit is None:
                continue
            left = fit.parts[fit.follow] if fit.follow is not None else None
            raw = write_chain([(rule, fit)], left)
            back, end = read_chain(raw)
            assert np.array_equal(back, x) and end == len(raw), rule.name
            assert len(raw) == 1 + step_size(rule, fit) + (size_of(left) if left is not None else 0), rule.name


def test_rule_ids_are_unique_bytes():
    ids = [rule.ident for rule in RULES]
    assert len(set(ids)) == len(ids) and all(0 < i < 256 for i in ids) and set(BY_ID) == set(ids)


def test_a_row_width_is_found_from_the_digits():
    rng = np.random.default_rng(12)
    x = np.tile(rng.integers(0, 10_000, 192), 60) + rng.integers(0, 3, 192 * 60)
    assert 192 in periods_of(x)
