# WARP3/warp2/equation_book/__init__.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/__init__.py
#  Used by   : warp2/equation_book/* and its tests (the package).
#  Uses      : nothing.
#  Description:
#    THE EQUATION BOOK (claude/equation_book_plan_2026_11_14.md, step 2).
#    A file's binary is taken as ONE NUMBER; the number is written in the
#    base that makes it cheapest (its digits are the file's bits taken w at
#    a time); and what is kept is a RECIPE that makes those digits - rules
#    applied one on another's output, with end transforms - written as
#    binary, plus what is left over. Read back, the recipe gives the same
#    number, so the same file, bit for bit. A plain fallback (no recipe)
#    means nothing is ever kept bigger than the number itself and a few
#    bytes of heading.
#      bits.py     - signed numbers as unsigned ones, and how many bits each needs
#      digits.py   - a file's bytes as one number's digits in base 2^w, and back
#      packed.py   - a list of numbers bit-packed in blocks (binary), and back
#      rules/      - the vocabulary: each rule makes a list of digits from
#                    smaller parts, and gives the parts from the digits
#      search.py   - the cheapest chain of rules, each on the last one's
#                    leftover, for as long as that gains
#      written.py  - a chain and its parts as binary, and back
#      keep.py     - the doors: a file (or a list of numbers) kept as its
#                    cheapest recipe, read back exactly before it is given out
#    "recipe" already names code recipes in the warp (ask/code_learning.py),
#    so this part is called the equation book.
#  User intention (Andrew, 2026-11-14): 15:34 "store number in equations
#    instead of by compression ... keep a book of the best"; 15:59 "The only
#    things that matter are storage space and time to generate from storage";
#    16:16 "transformations after equations ... if that equals out to the
#    number, then it fits"; 17:06 "for storage we should store the file as a
#    binary"; 17:08 "the binary as a number".
# ============================================================================
"""The equation book: a file's binary as one number, kept as the recipe that makes it."""
