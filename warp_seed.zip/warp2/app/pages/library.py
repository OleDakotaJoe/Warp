# WARP3/warp2/app/pages/library.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/app/pages/library.py
#  Used by   : warp2/app/lean/parts.py (the Library part of the side menu); tests.
#  Uses      : warp2/app/parts/{page,cards,worker,library_reads}.py; qfluentwidgets; PySide6.
#  Description:
#    THE LIBRARY. Left: a box that searches the whole KG, and ONE TREE of
#    folders inside folders (BUILD_LOG 2010n) - the research, everything in
#    the KG by name, by type, by tag, and the state's kept files. A folder
#    reads what is in it only when it is opened; its rows are put in as they
#    come onto the screen, and what a thing is called is read only for the
#    rows on the screen - so nothing has a limit and nothing is read that is
#    not looked at. Right: the opened part in full - a kept file given back
#    from its corpus, or a thing of the KG with every fact's whole value -
#    with a search box that walks its hits; the tags on it, a box to add a
#    tag of your own, and a box to dispute the picked tag; what it is linked
#    to (a click opens the other thing); and a place to add new words or a
#    file to the KG. Reads run off the window's thread; every add, tag and
#    dispute goes to the inbox, and the runner writes it into the KG on its
#    next pass. What the page is doing is said at the top (1945t).
#  User intention (Andrew, 2026-11-19 16:48): "we need to add a tab that allows the user to look
#    at things in the kg as the rehydrated files in full. This should look
#    like a file system that allows the user to look through the system via
#    types and tags and other ways of separation and allow for search in the
#    opened part. It should also be a place where the user can add new
#    things to the kg themselves ... It should also allow the user to add
#    their own tags or dispute tags that were on something." BUILD_LOG 1700L.
#    (18:47): "that tab should let me get to anything in the kg". (19:02): "it
#    should have no limit and just load what it is looking at and it should
#    have things nested like any other normal system".
# ============================================================================
"""The Library page: the KG's files and things in full, searched, added to, tagged and disputed."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QTextCursor, QTextDocument
from PySide6.QtWidgets import QFileDialog, QHBoxLayout, QListWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout
from qfluentwidgets import BodyLabel, ComboBox, LineEdit, PlainTextEdit, PrimaryPushButton, PushButton

from warp2.app.parts import library_reads as reads
from warp2.app.parts.cards import Panel
from warp2.app.parts.page import Page
from warp2.app.parts.worker import later

# Intention (2000a): a line is "what it is called  ·  its name in the KG".
SEP = "   \u00b7   "
LIST_STYLE = "QListWidget, QTreeWidget {background: #0F172A; color: #E2E8F0; border: 1px solid #1E293B; border-radius: 6px}"
# Intention (2010n): the row that stands for what a folder holds before it is read, and for its rows not yet put in.
WAITING, MORE = "...", "... more below"
# Intention (2030o): the folder, at the end of a folder of things, of the ones stated since the KG was last folded.
NEW = "new since the KG was last folded"


class LibraryPage(Page):
    """The KG to look through like a file system, and to add to."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the ways of looking on the left, the opened part on the right, adding underneath."""
        super().__init__("library", "Library", "The KG's files and things in full - look, search, add, tag, dispute.", parent)
        self.state = Path(feed.state)
        self.rows: dict = {}       # what each row of the tree stands for: {its number: {"node", "name", "file", ...}}
        self.opened = ""           # the name of the opened part
        self.about = ""            # the thing asks about the opened part are kept against
        self.read_now = None       # the opened thing's reading (None for a kept file), kept to show it in another form
        split = QHBoxLayout()
        split.setSpacing(16)
        split.addWidget(self._left(), 2)
        split.addLayout(self._right(), 5)
        # Intention (1945t): what the page is doing is said at the top, where it is seen, not under everything.
        self.said = BodyLabel("")
        self.said.setStyleSheet("color: #FBBF24; font-weight: 600;")
        self.body.addWidget(self.said)
        self.body.addLayout(split)
        self.body.addWidget(self._adding())
        self._begin()

    # -- building ------------------------------------------------------------

    def _left(self) -> Panel:
        """Intention: the box that searches the whole KG, and the tree of folders inside folders."""
        panel = Panel("Look through")
        self.everywhere = LineEdit()
        self.everywhere.setPlaceholderText("search the whole KG (press Enter)")
        self.everywhere.returnPressed.connect(self.search)
        panel.add(self.everywhere)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setStyleSheet(LIST_STYLE)
        self.tree.setMinimumHeight(620)
        self.tree.itemExpanded.connect(self._opened_folder)
        self.tree.itemClicked.connect(self._clicked)
        self.tree.verticalScrollBar().valueChanged.connect(lambda _at: self._look_at())
        panel.add(self.tree)
        return panel

    def _right(self) -> QVBoxLayout:
        """Intention: the opened part with its search, then its tags."""
        side = QVBoxLayout()
        side.setSpacing(16)
        self.reading = Panel("Nothing opened yet")
        search = QHBoxLayout()
        self.find = LineEdit()
        self.find.setPlaceholderText("search in the opened part")
        self.find.returnPressed.connect(self.find_next)
        self.find.textChanged.connect(lambda _words: self._count_hits())
        self.hits = BodyLabel("")
        go = PushButton("Next")
        go.clicked.connect(self.find_next)
        # Intention (1830f): the form a kept paper is shown in - made again from its one kept text when picked.
        from warp2.research.paper_forms import FORMS
        self.form = ComboBox()
        self.form.addItems(list(FORMS))
        self.form.currentTextChanged.connect(lambda _form: self._show_read())
        search.addWidget(self.find, 1)
        search.addWidget(self.hits)
        search.addWidget(go)
        search.addWidget(BodyLabel("paper as"))
        search.addWidget(self.form)
        self.reading.body.addLayout(search)
        self.text = PlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setMinimumHeight(420)
        self.reading.add(self.text)
        side.addWidget(self.reading, 1)
        tags = Panel("Tags on it")
        self.tags = QListWidget()
        self.tags.setStyleSheet(LIST_STYLE)
        self.tags.setMaximumHeight(130)
        tags.add(self.tags)
        mine = QHBoxLayout()
        self.new_tag = LineEdit()
        self.new_tag.setPlaceholderText("a tag of your own for the opened part")
        add = PushButton("Add tag")
        add.clicked.connect(self.add_tag)
        mine.addWidget(self.new_tag, 1)
        mine.addWidget(add)
        tags.body.addLayout(mine)
        against = QHBoxLayout()
        self.why = LineEdit()
        self.why.setPlaceholderText("why the picked tag does not belong")
        dispute = PushButton("Dispute picked tag")
        dispute.clicked.connect(self.dispute)
        against.addWidget(self.why, 1)
        against.addWidget(dispute)
        tags.body.addLayout(against)
        side.addWidget(tags)
        # Intention (2000a): what the opened thing is linked to, both ways - a click opens the other thing.
        linked = Panel("Linked to it")
        self.links = QListWidget()
        self.links.setStyleSheet(LIST_STYLE)
        self.links.setMaximumHeight(170)
        self.links.itemClicked.connect(lambda item: self._follow(item.text().split(SEP)[-1]))
        linked.add(self.links)
        side.addWidget(linked)
        return side

    def _adding(self) -> Panel:
        """Intention: new words or a file for the KG, kept against the opened part when there is one."""
        panel = Panel("Add to the KG")
        self.title_box = LineEdit()
        self.title_box.setPlaceholderText("what it is called")
        panel.add(self.title_box)
        self.words = PlainTextEdit()
        self.words.setPlaceholderText("the words to add")
        self.words.setMaximumHeight(140)
        panel.add(self.words)
        line = QHBoxLayout()
        put = PrimaryPushButton("Add these words")
        put.clicked.connect(self.add_words)
        pick = PushButton("Add a file...")
        pick.clicked.connect(self.pick_file)
        line.addWidget(put)
        line.addWidget(pick)
        line.addStretch(1)
        panel.body.addLayout(line)
        return panel

    # -- looking -------------------------------------------------------------

    def _begin(self) -> None:
        """Intention: the first folders shown at once - nothing of the KG is read or opened for them (the first
        folder opened opens the KG, once for the window)."""
        self._fill(self.tree.invisibleRootItem(), reads.top(self.state))
        self.tree.topLevelItem(0).setExpanded(True)

    def _row(self, under, text: str, **what) -> QTreeWidgetItem:
        """Intention: one row put under another, with what it stands for kept by its number."""
        item = QTreeWidgetItem(under, [text])
        self.rows[id(item)] = dict(what, item=item, text=text)
        return item

    def _of(self, item) -> dict:
        """Intention: what a row stands for (nothing, for a row that only waits)."""
        return self.rows.get(id(item), {})

    def _fill(self, under, node: dict) -> None:
        """Intention: a folder's rows put in - as many as the screen shows, the rest as they come onto the screen
        (_look_at); a folder that holds something gets a waiting row so it can be opened."""
        if node["run"] is not None:
            return self._fill_run(under, node)
        held = self._of(under)
        order = held.get("order")
        if order is None:
            order = list(node["kids"]) if node["ordered"] else sorted(node["kids"], key=str.lower)
            # a folder's own things are rows in it only when several end at the same place (one alone is the row itself)
            order = [(piece, None) for piece in order] + [(None, name) for name in node["names"] if len(node["names"]) > 1]
            held["order"], held["shown"] = order, 0
            self.rows.setdefault(id(under), held).update(node=node, item=under)
        screen = max(self.tree.viewport().height() // max(self.tree.sizeHintForRow(0), self.tree.fontMetrics().height()), 1)
        last = min(held["shown"] + screen, len(order))
        for piece, name in order[held["shown"]:last]:
            if piece is None:
                self._row(under, name, name=name, file=held.get("file", False))
                continue
            kid = node["kids"][piece]
            alone = kid["names"][0] if len(kid["names"]) == 1 else None
            has_more = bool(kid["kids"]) or kid["lazy"] is not None or len(kid["names"]) > 1
            row = self._row(under, piece + (f"   ({kid['n']:,})" if kid["n"] > 1 else ""), node=kid, name=alone, piece=piece,
                            file=held.get("file", False) or (kid["lazy"] or ("",))[0] == "files")
            if has_more:
                QTreeWidgetItem(row, [WAITING])
        held["shown"] = last
        if last < len(order):
            self._row(under, MORE, more=under)

    def _fill_run(self, under, node: dict) -> None:
        """Intention (2030o): the next rows of a folder of the KG's things - worked out off the window's thread for
        just the rows the screen shows (a name is read only for a row shown); after the last of them, the things
        newer than the KG's last fold."""
        held = self.rows.setdefault(id(under), {"item": under})
        if held.get("filling"):
            return
        held.update(node=node, order=[], filling=True)
        state, at = self.state, held.get("at", node["run"]["lo"])
        screen = max(self.tree.viewport().height() // max(self.tree.sizeHintForRow(0), self.tree.fontMetrics().height()), 1)

        def then(read: dict) -> None:
            """Intention: the rows put in; a row that waits for more when the folder goes on."""
            for piece, name, kid in read["rows"]:
                many = kid["n"] if kid is not None else 1
                row = self._row(under, piece + (f"   ({many:,})" if many > 1 else ""), node=kid, name=name, piece=piece)
                if kid is not None:
                    QTreeWidgetItem(row, [WAITING])
            held.update(at=read["at"], filling=False)
            if read["at"] < node["run"]["hi"]:
                self._row(under, MORE, more=under)
            elif node["new"] is not None and not held.get("new_shown"):
                held["new_shown"] = True
                new = self._row(under, f"{NEW}   ({node['new']['n']:,})", node=node["new"], piece=NEW)
                QTreeWidgetItem(new, [WAITING])
            self.said.setText("")
            self._look_at()

        def failed(words: str) -> None:
            """Intention: a read that fell over is said, and the rows can be asked for again."""
            held["filling"] = False
            self.said.setText(f"Could not read the rows: {words}")

        later(lambda: reads.rows(state, node, at, screen), then, failed)

    def _opened_folder(self, item) -> None:
        """Intention: a folder opened - what is in it read now if it never was (off the window's thread), then its
        rows put in."""
        held = self._of(item)
        node = held.get("node")
        if node is None or held.get("order") is not None or held.get("reading"):
            return
        if node["lazy"] is None:
            item.takeChildren()
            self._fill(item, node)
            self._look_at()
            return
        held["reading"] = True
        state, lazy, piece = self.state, node["lazy"], held.get("piece", "")
        self.said.setText(f"Reading what is in {piece} ...")

        def then(read: dict) -> None:
            """Intention: what was read becomes the folder's own; its rows are put in and its count said."""
            node.update(read, lazy=None)
            held["reading"] = False
            item.setText(0, f"{piece}   ({node['n']:,})")
            item.takeChildren()
            self._fill(item, node)
            self.said.setText("")
            self._look_at()

        def failed(words: str) -> None:
            """Intention: a read that fell over is said, and the folder can be opened again."""
            held["reading"] = False
            self.said.setText(f"Could not read {piece}: {words}")

        later(lambda: reads.inside(state, lazy), then, failed)

    def _on_screen(self) -> list:
        """Intention: the rows of the tree that are on the screen now."""
        rows, item = [], self.tree.itemAt(0, 0)
        while item is not None and self.tree.visualItemRect(item).top() <= self.tree.viewport().height():
            rows.append(item)
            item = self.tree.itemBelow(item)
        return rows

    def _look_at(self) -> None:
        """Intention: only what is looked at is loaded - a folder's next rows when its last row comes onto the
        screen, and what the things on the screen are called (read once each, off the window's thread)."""
        asked = []
        for item in self._on_screen():
            held = self._of(item)
            if held.get("more") is not None:
                under = held["more"]
                under.removeChild(item)
                del self.rows[id(item)]
                node = self._of(under)["node"]
                self._fill(under, node)
                return self._look_at() if node["run"] is None else None
            if held.get("name") and not held.get("file") and not held.get("called"):
                held["called"] = True
                asked.append(held)
        if asked:
            state = self.state

            def then(said: dict) -> None:
                """Intention: each row says what its thing is called and its kind, before its name."""
                for held in asked:
                    label, kind = said.get(held["name"], ("", ""))
                    words = label + (f"   [{kind}]" if kind else "")
                    if words:
                        held["item"].setText(0, f"{words}{SEP}{held['text']}")

            later(lambda: reads.called(state, [held["name"] for held in asked]), then)

    def _clicked(self, item) -> None:
        """Intention: a click on a thing or a kept file opens it in full (a folder is opened by its arrow)."""
        held = self._of(item)
        if held.get("name"):
            self.open(held["name"], thing=not held.get("file"))

    def search(self) -> None:
        """Intention: the whole KG searched for the words typed; everything found put in a folder at the top of
        the tree, the best first."""
        words = self.everywhere.text().strip()
        if not words:
            return
        self.said.setText(f"Searching the whole KG for '{words}' ...")
        state = self.state

        def then(found: dict) -> None:
            """Intention: the found things as a folder of their own, opened."""
            self.said.setText(f"{found['n']:,} things found for '{words}'." if found["n"] else f"Nothing in the KG holds '{words}'.")
            folder = QTreeWidgetItem([f"Found for '{words}'   ({found['n']:,})"])
            self.tree.insertTopLevelItem(0, folder)
            self.rows[id(folder)] = {"item": folder, "node": found, "piece": f"Found for '{words}'"}
            self._fill(folder, found)
            folder.setExpanded(True)
            self.tree.scrollToItem(folder)
            self._look_at()

        later(lambda: reads.search(state, words), then, lambda said: self.said.setText(f"Could not search: {said}"))

    def _follow(self, name: str) -> None:
        """Intention (2000a): a linked thing opened - as a thing of the KG."""
        self.open(name, thing=True)

    # -- opening -------------------------------------------------------------

    def open(self, name: str, thing: bool = True) -> None:
        """Intention: a thing of the KG in full with its tags and links, or (`thing` False) a kept file in full -
        read off the window's thread."""
        is_file = not thing
        state = self.state
        self.said.setText(f"Opening {name} ...")

        def read() -> dict:
            """Intention: the part's text; for a thing of the KG its tags and disputes too."""
            if is_file:
                return {"text": reads.file_text(state, name), "read": None, "tags": [], "disputes": []}
            read_ = reads.thing(state, name)
            return {"read": read_, "tags": read_["tags"], "disputes": read_["disputes"], "links": read_["links"],
                    "called": reads.called(state, sorted({other for _how, other in read_["links"]}))}

        def then(answer: dict) -> None:
            """Intention: the opened part shown, its tags listed with anything said against them."""
            self.opened, self.about = name, (f"state/{name}" if is_file else name)
            self.reading.heading.setText(name)
            self.read_now = answer.get("read")
            self.text.setPlainText(answer["text"]) if self.read_now is None else self._show_read()
            against = dict(answer["disputes"])
            self.tags.clear()
            self.tags.addItems([tag + (f"   - disputed: {against[tag]}" if tag in against else "") for tag in answer["tags"]])
            self.links.clear()
            called = answer.get("called") or {}
            self.links.addItems([f"{how}: {called.get(other, ('', ''))[0]}{SEP}{other}" for how, other in answer.get("links") or []])
            self.said.setText("")
            self._count_hits()

        later(read, then, lambda words: self.said.setText(f"Could not open {name}: {words}"))

    def _show_read(self) -> None:
        """Intention (1830f): the opened thing of the KG shown again, its kept paper in the picked form."""
        if getattr(self, "read_now", None) is not None:
            self.text.setPlainText(reads.as_text(self.opened, self.read_now, self.form.currentText()))
            self._count_hits()

    def _count_hits(self) -> None:
        """Intention: how many times the search words are in the opened part."""
        words = self.find.text()
        count = self.text.toPlainText().lower().count(words.lower()) if words else 0
        self.hits.setText(f"{count:,} found" if words else "")

    def find_next(self) -> None:
        """Intention: the next place the search words are, going round to the top after the last."""
        words = self.find.text()
        if not words:
            return
        if not self.text.find(words, QTextDocument.FindFlag(0)):
            self.text.moveCursor(QTextCursor.MoveOperation.Start)
            self.text.find(words, QTextDocument.FindFlag(0))

    # -- asking --------------------------------------------------------------

    def _asked(self, ask: dict, what: str) -> None:
        """Intention: what was asked, said plainly; the runner writes it into the KG on its next pass."""
        self.said.setText(f"Asked ({ask.get('id', '')}): {what}. It is kept; the warp writes it into the KG on a pass "
                          f"after it has been restarted on this build.")

    def add_tag(self) -> None:
        """Intention: the user's own tag on the opened part - shown in the list at once as waiting (1945t)."""
        words = self.new_tag.text().strip()
        if not self.about or not words:
            self.said.setText("Open something and type the tag first.")
            return
        self._asked(reads.add_tag(self.state, self.about, words), f"tag '{words}' on {self.opened}")
        self.tags.addItem(f"tag:user={words}   - yours, waiting for the warp to write it")
        self.new_tag.clear()

    def dispute(self) -> None:
        """Intention: the user's word against the tag picked in the list."""
        item = self.tags.currentItem()
        if not self.about or item is None:
            self.said.setText("Open something and pick one of its tags first.")
            return
        tag = item.text().split("   - disputed:", 1)[0]
        self._asked(reads.dispute(self.state, self.about, tag, self.why.text()), f"dispute of {tag} on {self.opened}")
        item.setText(f"{tag}   - disputed: {self.why.text() or 'disputed'} (waiting for the warp to write it)")
        self.why.clear()

    def add_words(self) -> None:
        """Intention: typed words added to the KG as a new thing (kept against the opened part when there is one)."""
        title, words = self.title_box.text().strip(), self.words.toPlainText()
        if not title or not words.strip():
            self.said.setText("Give it a name and some words first.")
            return
        self._asked(reads.add_text(self.state, title, words, self.about), f"'{title}' added")
        self.title_box.clear()
        self.words.clear()

    def pick_file(self) -> None:
        """Intention: a file picked from the computer, copied in for the KG."""
        path, _kind = QFileDialog.getOpenFileName(self, "A file for the KG")
        if path:
            self._asked(reads.add_file(self.state, path, self.title_box.text().strip(), self.about), f"{Path(path).name} added")
