# WARP3/warp2/app/lean/last_read.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/app/lean/last_read.py
#  Used by   : warp2/app/pages/capabilities.py (every capability's standing),
#              warp2/app/pages/capability.py (one capability's runs),
#              warp2/app/pages/home.py (the outline's tiles);
#              warp2/app/tests/test_app.py.
#  Uses      : nothing.
#  Description:
#    WHAT A COSTLY PAGE LAST READ, KEPT FOR WHEN IT IS SHOWN AGAIN. A page is
#    let go when another tab is shown (warp2/app/lean/slot.py). The pages
#    whose reading walks the whole record - every capability's runs - start
#    empty when made again, and stay empty until that walk ends. Each keeps
#    its last answer here, by its own name, so a page shown again draws it at
#    once and reads afresh behind it. Only the answers are kept (rows of
#    words and numbers), never the pages.
#  User intention (Andrew, 2026-11-14 13:23): "the windows dont work it needs
#    more info in it". BUILD_LOG 1643c.
# ============================================================================
"""What a costly page last read, by its name - drawn at once when it is shown again."""
from __future__ import annotations

_LAST: dict = {}


def keep(name: str, got):
    """Intention: a page's newest answer kept under its name; the answer, so a page can keep and draw in one line."""
    _LAST[name] = got
    return got


def last(name: str):
    """Intention: the answer a page with this name last read, or None if it has not read one yet."""
    return _LAST.get(name)
