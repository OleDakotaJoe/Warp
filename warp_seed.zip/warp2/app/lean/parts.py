# WARP2/warp2/app/lean/parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/lean/parts.py
#  Used by   : warp2/app/window.py (the side menu - every part, made only when
#              it is shown); warp2/app/tests/test_app.py.
#  Uses      : warp2/app/pages/*.py - each imported only when its part is
#              shown.
#  Description:
#    EVERY PART THE WINDOW CAN SHOW, AND NOTHING MADE UNTIL IT IS SHOWN.
#    Each part is a key, the name in the side menu, a line saying what it
#    holds, its icon, whether it sits at the bottom of the menu, and a maker
#    that imports its page and builds it from the feed when the part is shown
#    - so the window holds the menu, not the pages. The order is the side
#    menu's (Home first, "Is it improving?" second, the code pages at the
#    bottom). What the warp is doing now is not a part: it stays down the
#    right of the window, always in view.
#  User intention (Andrew, 2026-11-14 12:41): "trim out the gui ... get it down
#    to bare bones but have it be able open up all the parts that it has in it
#    and that way we get the best of both worlds". BUILD_LOG 1640c. 13:23: "the
#    windows dont work it needs more info in it and it needs to look a lot
#    better" - back in the one window, each page made only while shown
#    (BUILD_LOG 1642c).
# ============================================================================
"""Every part of the window: a name, what it holds, and how it is made when it is opened."""
from __future__ import annotations


def _home(feed):
    """Intention: the old first page - holdings, what it did last, the tiles that open other parts."""
    from warp2.app.pages.home import HomePage
    return HomePage(feed)


def _improving(feed):
    """Intention: is the whole system improving (Andrew, 2026-10-16)."""
    from warp2.app.pages.improving import ImprovingPage
    return ImprovingPage(feed)


def _chat(feed):
    """Intention: the chat with the warp."""
    from warp2.app.pages.chat import ChatPage
    return ChatPage(feed)


def _capabilities(feed):
    """Intention: every capability, each opening its own part."""
    from warp2.app.pages.capabilities import CapabilitiesPage
    return CapabilitiesPage(feed)


def _connections(feed):
    """Intention: communications and connections."""
    from warp2.app.pages.connections import ConnectionsPage
    return ConnectionsPage(feed)


def _work(feed):
    """Intention: the work the warp holds."""
    from warp2.app.pages.work import WorkPage
    return WorkPage(feed)


def _models(feed):
    """Intention: the models."""
    from warp2.app.pages.models import ModelsPage
    return ModelsPage(feed)


def _eye_tree(feed):
    """Intention: the Eye's tree."""
    from warp2.app.pages.eye_tree import EyeTreePage
    return EyeTreePage(feed)


def _knowledge(feed):
    """Intention: the knowledge graph."""
    from warp2.app.pages.knowledge import KnowledgePage
    return KnowledgePage(feed)


def _webs(feed):
    """Intention: the webs and tags."""
    from warp2.app.pages.webs import WebsPage
    return WebsPage(feed)


def _library(feed):
    """Intention (1700L): the library - the KG's files and things to look through, add to, tag and dispute."""
    from warp2.app.pages.library import LibraryPage
    return LibraryPage(feed)


def _make(feed):
    """Intention: the make cycle."""
    from warp2.app.pages.make import MakePage
    return MakePage(feed)


def _problems(feed):
    """Intention: the problems."""
    from warp2.app.pages.problems import ProblemsPage
    return ProblemsPage(feed)


def _pictures(feed):
    """Intention: the pictures."""
    from warp2.app.pages.pictures import PicturesPage
    return PicturesPage(feed)


def _games(feed):
    """Intention: the games."""
    from warp2.app.pages.games import GamesPage
    return GamesPage(feed)


def _structure(feed):
    """Intention: the code structure."""
    from warp2.app.pages.structure import StructurePage
    return StructurePage(feed)


def _system(feed):
    """Intention: the system map."""
    from warp2.app.pages.system import SystemPage
    return SystemPage(feed)


# Intention: (key, name in the menu, what it holds, icon, at the bottom of the menu, maker) in the side menu's order;
# the keys are the old pages' keys, so a page that opens another by key (home, capabilities, chat) still finds it. The
# icon is the name of a Fluent icon, looked up by the window (this file imports no Qt).
PARTS = (
    ("home", "Home", "what the warp holds and did last", "HOME", False, _home),
    ("improving", "Is it improving?", "whether the whole system is getting better", "SPEED_HIGH", False, _improving),
    ("chat", "Chat", "talk with the warp", "CHAT", False, _chat),
    ("capabilities", "Capabilities", "every capability, each with its own tab", "APPLICATION", False, _capabilities),
    ("connections", "Communications & connections", "who the warp talks to", "WIFI", False, _connections),
    ("work", "Work", "the work it holds", "CHECKBOX", False, _work),
    ("models", "Models", "the models and how they do", "ROBOT", False, _models),
    ("eye_tree", "Eye tree", "the Eye's concepts and pairs", "VIEW", False, _eye_tree),
    ("knowledge", "Knowledge", "the knowledge graph", "IOT", False, _knowledge),
    ("webs", "Webs & tags", "the connection web", "TILES", False, _webs),
    ("library", "Library", "the KG's files and things in full", "LIBRARY", False, _library),
    ("make", "Make cycle", "the make cycle's jobs", "DEVELOPER_TOOLS", False, _make),
    ("problems", "Problems", "what went wrong", "INFO", False, _problems),
    ("pictures", "Pictures", "the pictures", "PHOTO", False, _pictures),
    ("games", "Games", "the games", "GAME", False, _games),
    ("structure", "Code structure", "the code, file by file", "CODE", True, _structure),
    ("system", "System map", "how the parts connect", "APPLICATION", True, _system),
)


def capability(cap: dict):
    """Intention: the maker of one capability's own tab (warp2/app/pages/capability.py)."""
    def made(feed):
        """Intention: the capability's page, made from the feed when its tab is shown."""
        from warp2.app.pages.capability import CapabilityPage
        return CapabilityPage(feed, cap)
    return made
