# WARP3/warp2/app/lean/__init__.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/app/lean/__init__.py
#  Used by   : warp2/app/window.py (the one window takes its pages from here).
#  Uses      : nothing.
#  Description:
#    What keeps the one window lean: the list of every page, each made only
#    when shown (parts.py), and a page's place in the side menu that holds
#    its page only while it is shown (slot.py).
#  User intention (Andrew, 2026-11-14 12:41): "change it to be leaner and use
#    less resources ... have it be able open up all the parts that it has in
#    it and that way we get the best of both worlds". BUILD_LOG 1640c, 1642c.
# ============================================================================
"""What keeps the one window lean."""
