# WARP2/warp2/app/lean/slot.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/lean/slot.py
#  Used by   : warp2/app/window.py (one slot for every page and every
#              capability's tab in the side menu); warp2/app/tests/test_app.py.
#  Uses      : PySide6 (QWidget, QVBoxLayout).
#  Description:
#    A PAGE'S PLACE IN THE WINDOW, HOLDING THE PAGE ONLY WHILE IT IS SHOWN.
#    The side menu needs a widget for every page; the slot is that widget,
#    empty and small. When its page is shown the slot makes the page from the
#    feed, hands it the newest reading and every new one, and gives it the
#    window's openers; when another page is shown the slot tells its page it
#    is closing, cuts it from the feed and lets it go. So the window looks and
#    works as it always has, with every page in the menu, but holds one page
#    at a time.
#  User intention (Andrew, 2026-11-14 12:41): "change it to be leaner and use
#    less resources ... have it be able open up all the parts that it has in
#    it and that way we get the best of both worlds"; 13:23: "the windows dont
#    work it needs more info in it and it needs to look a lot better".
#    BUILD_LOG 1642c.
# ============================================================================
"""A page's place in the side menu: the page made while shown, let go when not."""
from __future__ import annotations

from PySide6.QtWidgets import QVBoxLayout, QWidget


class PageSlot(QWidget):
    """Intention: a page's place in the window - empty until shown, holding its page only while shown."""

    def __init__(self, key: str, maker, feed, openers: dict, parent=None) -> None:
        """Intention: the page's key (its object name, as the side menu needs), how it is made, the feed it reads, and
        the window's openers it is given."""
        super().__init__(parent)
        self.setObjectName(key.replace(":", "-"))
        self.key, self.maker, self.feed, self.openers = key, maker, feed, openers
        self.page = None
        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(0, 0, 0, 0)

    def fill(self):
        """Intention: the page made, if it is not already, wired to the openers and the feed, and handed the newest
        reading; the page."""
        if self.page is not None:
            return self.page
        page = self.maker(self.feed)
        for name, work in self.openers.items():
            if hasattr(page, name):
                setattr(page, name, work)
        self.box.addWidget(page)
        self.page = page
        if hasattr(page, "take"):
            self.feed.snapshot.connect(page.take)
            if self.feed.last:
                page.take(self.feed.last)
        return page

    def empty(self) -> None:
        """Intention: the page told it is closing, cut from the feed and let go; the slot left empty."""
        page, self.page = self.page, None
        if page is None:
            return
        if hasattr(page, "close_page"):
            page.close_page()
        if hasattr(page, "take"):
            try:
                self.feed.snapshot.disconnect(page.take)
            except (RuntimeError, TypeError):  # fault: ok already cut - Qt cut it when the page went
                pass
        self.box.removeWidget(page)
        # Intention: the page stays the slot's child until Qt deletes it - a page made parentless and not yet deleted
        # when the program ends is destroyed after the application, which ended a test process on Windows (1642c).
        page.hide()
        page.deleteLater()
