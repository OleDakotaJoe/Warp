# WARP2/warp2/app/parts/library_reads.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/library_reads.py
#  Used by   : warp2/app/pages/library.py (every read off the window's thread, every ask through the inbox); tests.
#  Uses      : warp2/corpus/convert/state_text.py (text_parts, file_back), warp2/store/store.py (Store, store_home),
#              warp2/ask/inbox.py (Inbox, FILE, TAG, DISPUTE), warp2/research/paper_forms.py (as_form); (stdlib) tempfile, pathlib.
#  Description:
#    WHAT THE LIBRARY TAB READS AND ASKS. Reading (BUILD_LOG 2010n): the KG
#    and the state's kept files as ONE NEST of folders inside folders - a
#    name is cut at its own marks and each piece is a folder. Nothing is read
#    until its folder is opened: the things of a kind, the things whose name
#    begins so, the kinds there are, a folder's kept files; what a thing is
#    called is read only for the things on the screen; the whole KG is
#    searched by words with nothing held back; one thing is read in full -
#    every fact with its whole value, the tags on it, what has been said
#    against them, and its links both ways. The KG is held open for the life
#    of the window so a click does not wait for it to open.
#    BUILD_LOG 2030o: a folder of things is a run of numbers in name order
#    (warp2/store/small_kg/in_order.py); opening it reads no name, and its
#    rows are worked out a screen at a time.
#    Asking: a new thing, a tag of the user's own, or a dispute of a tag is put
#    in the inbox (warp2/ask/inbox.py); the runner takes it in and writes the
#    facts (warp2/ask/taking.py), so the window never writes the KG itself.
#  User intention (Andrew, 2026-11-19 16:48): "we need to add a tab that allows the user to look
#    at things in the kg as the rehydrated files in full. This should look
#    like a file system that allows the user to look through the system via
#    types and tags and other ways of separation and allow for search in the
#    opened part. It should also be a place where the user can add new
#    things to the kg themselves ... It should also allow the user to add
#    their own tags or dispute tags that were on something." BUILD_LOG 1700L.
#    (19:02): "it should have no limit and just load what it is looking at and
#    it should have things nested like any other normal system".
# ============================================================================
"""The Library tab's reads (files in full, things by type and tag) and its asks (add, tag, dispute)."""
from __future__ import annotations

import contextlib
import re
import tempfile
import threading
from pathlib import Path

TAG_HEAD, DISPUTE_KIND = "tag:", "tag_dispute"
DIGEST = "_digest"


# Intention (1945t): what has been read is kept for the life of the window - the window lets a page go whenever another
# is shown, and reading everything again each time the Library was opened left it blank for a minute.
_HELD: dict = {}


def held(state, what: str, read, fresh: bool = False):
    """Intention: what `read()` gives, read once for this state and kept; read again when `fresh` is asked."""
    key = (str(state), what)
    if fresh or key not in _HELD:
        _HELD[key] = read()
    return _HELD[key]


# Intention (2035q): one question of the KG at a time - the window's reads run on several threads and share one Store.
_ONE_AT_A_TIME = threading.Lock()


@contextlib.contextmanager
def _asking(state):
    """Intention: the KG for one question. (2010n) It is opened by the first question and held for the life of the
    window - opening it for each question cost about 20 seconds a click on the live KG. (2035q) The one held Store
    answers every question: making and closing a Store for each one cost from a third of a second to ten seconds
    each time (measured on the live KG while the runner worked)."""
    from warp2.store.store import Store, store_home
    with _ONE_AT_A_TIME:
        yield held(state, "open", lambda: Store(store_home(state)))


def file_text(state, name: str) -> str:
    """Intention: one kept file given back in full, as text (bytes that are not text are shown as they can be)."""
    from warp2.corpus.convert.state_text import file_back
    return file_back(state, name).decode("utf-8", errors="replace")


# -- the nest: names as folders inside folders (2010n) ------------------------------------------------------------
# Intention (Andrew 2026-11-19 19:02: "it should have no limit and just load what it is looking at and it should have
# things nested like any other normal system"): a name is cut where its own marks cut it, and each piece is a folder
# inside the one before - finding: / 9a1a ; projects / uhe / src / image.py / _apply ; https://arxiv.org / abs / 0001
# / part-1. A node is {"kids": {piece: node}, "names": [the things or files that end here], "n": how many are in
# it, "lazy": (what, about) when what is in it has not been read yet}. A folder of the KG's things is a RUN
# (2030o): {"numbers": things as numbers in the order of their names, "lo"/"hi": its stretch of them, "begins": the
# beginning its names share} - its rows are worked out a screen at a time (rows), a name read only for a row shown;
# "new" is the nest of the things first stated after the KG was last folded (few; they are not in that order).
CUTS = re.compile(r"::|[/:#=]")
SITE = re.compile(r"\w+://[^/#]*")
PATH = re.compile(r"/")
# Intention: what a thing is called in a list - the first of these it says (a finding's id says nothing; its summary
# does).
LABELS = ("title", "name", "question", "summary", "text", "definition", "intention")
# Intention: the types that are the research - what was asked, what was found, what it is about.
RESEARCH = ("need", "user_question", "to_ask", "finding", "concept", "paper_section", "judgement")
# Intention: the beginning every web address shares (a page or paper the research brought in is named by its address).
SITES = "http"


def node(lazy=None, ordered: bool = False) -> dict:
    """Intention: an empty folder of the nest; `lazy` says what to read when it is opened, `ordered` keeps its
    folders in the order they were put in (else they are shown by name)."""
    return {"kids": {}, "names": [], "n": 0, "lazy": lazy, "ordered": ordered, "run": None, "new": None}


def pieces(name: str, cuts=CUTS) -> list:
    """Intention: a name as the folders it is nested in - cut at its own marks, a web address kept whole up to its
    site; a piece that would be empty is left out."""
    site = SITE.match(name) if cuts is CUTS else None
    first = [site.group(0)] if site else []
    return first + [piece for piece in cuts.split(name[site.end():] if site else name) if piece]


def nested(names, cuts=CUTS) -> dict:
    """Intention: the nest of these names - every one of them, each where its pieces put it."""
    root = node()
    for name in names:
        name = str(name)
        at = root
        at["n"] += 1
        for piece in pieces(name, cuts):
            at = at["kids"].setdefault(piece, node())
            at["n"] += 1
        at["names"].append(name)
    return root


def top(state) -> dict:
    """Intention: the first folders of the Library - nothing of the KG read yet; each reads what is in it when it
    is opened. The research first (Andrew 18:47: "I am looking for things about research in it")."""
    root = node(ordered=True)
    research = root["kids"]["Research"] = node(ordered=True)
    for kind in RESEARCH:
        research["kids"][kind] = node(("kind", kind))
    research["kids"]["source (papers and pages)"] = node(("under", SITES))
    root["kids"]["Everything in the KG, by name"] = node(("under", ""))
    root["kids"]["By type"] = node(("kinds", ""))
    root["kids"]["By tag"] = node(("under", TAG_HEAD))
    files = root["kids"]["Kept files (logs, research kept as files)"] = node()
    home = Path(state) / "corpus" / "text"
    for folder in sorted(p.name for p in home.glob("*") if p.is_dir() and any(p.iterdir())) if home.is_dir() else []:
        files["kids"][folder] = node(("files", folder))
    return root


def inside(state, lazy) -> dict:
    """Intention: what is in a folder that had not been read - read now, once for the window, only because it was
    opened: the things of a kind, the things whose name begins so, the kinds there are, or a folder's kept files."""
    what, about = lazy
    return held(state, f"inside:{what}:{about}", lambda: _INSIDE[what](state, about))


def _lifted(read: dict, about: str) -> dict:
    """Intention: a folder that holds nothing but one folder of its own name shows what that one holds (finding /
    finding / 9a1a is shown as finding / 9a1a)."""
    only = next(iter(read["kids"].items())) if len(read["kids"]) == 1 and not read["names"] else None
    return only[1] if only is not None and only[0] == about.rstrip(":/") and not only[1]["names"] else read


def _run(store, answer: dict, begins: str, about: str) -> dict:
    """Intention: a folder of the KG's things from the store's answer - a run over the folded things (its names
    not read), the newer ones nested beside it; with nothing folded it is just the nest of the newer ones. When
    every name of the run begins `about:`, the run begins there (the folder is not shown again inside itself)."""
    numbers, new = answer["numbers"], nested(answer["new"])
    if not len(numbers):
        return _lifted(new, about)
    head = f"{about}:"
    if about and not begins and store.name_of(numbers[0]).startswith(head) and store.name_of(numbers[-1]).startswith(head):
        begins, new = head, _lifted(new, about)
    folder = node()
    folder.update(run={"numbers": numbers, "lo": 0, "hi": len(numbers), "begins": begins}, new=new if new["n"] else None,
                  n=len(numbers) + new["n"])
    return folder


def _of_kind(state, kind: str) -> dict:
    """Intention: every thing that says this kind, and every thing named as one (need:...) that says no kind."""
    with _asking(state) as store:
        return _run(store, store.things_in_order(f"{kind}:", attr="kind", value=kind), "", kind)


def _under(state, begins: str) -> dict:
    """Intention: every thing whose name begins so (every thing of the KG, for an empty beginning)."""
    with _asking(state) as store:
        about = begins.rstrip(":")
        return _run(store, store.things_in_order(begins), begins if begins.endswith(":") else "", about if begins.endswith(":") else "")


def _kinds(state, _about) -> dict:
    """Intention: the kinds the KG's things say, each a folder that reads its things when opened."""
    with _asking(state) as store:
        counted = store.said_values("kind")
    root = node()
    for kind, many in counted.items():
        root["kids"][kind] = node(("kind", kind))
        root["kids"][kind]["n"] = many
    root["n"] = sum(counted.values())
    return root


MARKS = re.compile(r"(?:::|[/:#=])*")


def _end(name, text: str, lo: int, hi: int) -> int:
    """Intention: the first place of a run, from `lo`, whose name is not before `text` (the names are in order)."""
    while lo < hi:
        mid = (lo + hi) // 2
        if name(mid) < text:
            lo = mid + 1
        else:
            hi = mid
    return lo


def rows(state, folder: dict, at: int, many: int) -> dict:
    """Intention: the next rows of a run from place `at`, at most `many` - {"rows": [(piece, the thing that ends
    there or None, the folder inside or None)], "at": where the rows after them start}. Only the names these rows
    need are read: one for a thing, and a search of the order for where a folder inside ends."""
    run = folder["run"]
    numbers, hi, begins = run["numbers"], run["hi"], run["begins"]
    with _asking(state) as store:
        def name(place: int) -> str:
            """Intention: the name at a place of the run."""
            return store.name_of(numbers[place])

        def inner(lo: int, shared: str) -> tuple:
            """Intention: the folder of the names from `lo` that share this beginning, and where it ends."""
            end = _end(name, shared + chr(0x10FFFF), lo, hi)
            kid = node()
            kid.update(run={"numbers": numbers, "lo": lo, "hi": end, "begins": shared}, n=end - lo)
            return kid, end

        out = []
        while at < hi and len(out) < many:
            text = name(at)
            site = SITE.match(text) if not begins else None
            lead = 0 if site else MARKS.match(text, len(begins)).end()
            cut = CUTS.search(text, site.end() if site else lead)
            mine = text[:cut.start()] if cut else text
            piece = mine[lead:] or text
            if len(mine) < len(text):                          # names go on below this piece: a folder
                kid, end = inner(at, mine + text[len(mine)])
                out.append((piece, None, kid))
            else:                                              # a thing; a folder too when the next names go on from it
                after = name(at + 1) if at + 1 < hi else ""
                kid, end = inner(at + 1, text + after[len(text)]) if after.startswith(text) and CUTS.match(after, len(text)) else (None, at + 1)
                if kid is not None:
                    kid["n"] += 1
                out.append((piece, text, kid))
            at = end
        return {"rows": out, "at": at}


def _files(state, folder: str) -> dict:
    """Intention: the files kept from one folder of the state, nested as their paths are."""
    from warp2.corpus.convert.state_text import text_parts
    return _lifted(nested(sorted(text_parts(state, "." if folder == "_top" else folder).where()), PATH), folder)


_INSIDE = {"kind": _of_kind, "under": _under, "kinds": _kinds, "files": _files}


def called(state, names) -> dict:
    """Intention: {thing: (what it is called, its kind)} for the things now on the screen - read only for them."""
    with _asking(state) as store:
        said: dict = {}
        # 2015s: one question for all the rows on the screen, not one each (5.5 s for 40 rows measured the other way)
        for fact in store.facts(subjects=list(names), attrs=LABELS + ("kind",)) if names else []:
            said.setdefault(str(fact["subject"]), {})[str(fact["attr"])] = str(store.payload(fact) or "").strip().split("\n", 1)[0]
        out = {}
        for name in names:
            label = [said.get(name, {})[attr] for attr in LABELS if said.get(name, {}).get(attr)]
            out[name] = (label[0] if label else "", said.get(name, {}).get("kind", ""))
        return out


def search(state, words: str) -> dict:
    """Intention: every thing of the whole KG whose facts hold these words, the best first - a folder of the nest,
    each thing under the words that were found in it. Nothing is held back."""
    with _asking(state) as store:
        found = store.search(words, max(store.facts_held(), 1))
    root, seen = node(ordered=True), set()
    for fact in found:
        thing_ = str(fact.get("subject"))
        if thing_ not in seen:
            seen.add(thing_)
            line = f"{fact.get('attr') or fact.get('relation') or ''}: " \
                   f"{str(fact.get('value') or fact.get('object') or '').split(chr(10), 1)[0]}"
            kid = root["kids"].setdefault(f"{line}   [{thing_}]", node())
            kid["names"].append(thing_)
            kid["n"] = 1
            root["n"] += 1
    return root


def _held_in_full(state, store, what: str, value: str) -> list:
    """Intention (1710L): a fact that only names what it holds by its digest (a paper's content_digest) has the
    held words fetched from the evidence and shown in full beside it - [(what it is, the words)], or nothing."""
    from warp2.record.evidence import Evidence
    if not what.endswith(DIGEST):
        return []
    for evidence in (store.evidence, Evidence(Path(state) / "evidence")):
        if evidence.has(value):
            return [(what[:-len(DIGEST)] + " in full", evidence.text(value))]
    return []


def thing(state, subject: str) -> dict:
    """Intention: one thing in full - {"facts": [(what, whole value)], "tags": [tags on it], "on": [what a tag is
    on], "disputes": [(tag, why)], "links": [(how it is linked, the other thing)]} (2000a: the links, both ways,
    so a question leads to its findings and a finding to its sources)."""
    with _asking(state) as store:
        facts = []
        for fact in store.current(subject=subject):
            if fact.get("attr"):
                facts.append((str(fact["attr"]), str(store.payload(fact) or "")))
                facts += _held_in_full(state, store, str(fact["attr"]), str(fact.get("value") or ""))
            else:
                facts.append((str(fact.get("relation")), str(fact.get("object") or "")))
        tags = sorted({str(f["subject"]) for f in store.facts(object=subject, relation="derives", subject_begins=TAG_HEAD)})
        on = sorted({str(f["object"]) for f in store.current(subject=subject, relation="derives")}) if subject.startswith(TAG_HEAD) else []
        disputes = []
        for row in store.current(attr="about", value=subject):
            mine = store.current(subject=row["subject"])
            if any(f.get("attr") == "kind" and f.get("value") == DISPUTE_KIND for f in mine):
                against = [str(f.get("object")) for f in mine if f.get("relation") == "contradicts"]
                why = [str(store.payload(f) or "") for f in mine if f.get("attr") == "user_said"]
                disputes.append((against[0] if against else "", why[0] if why else ""))
        links = [(str(f.get("relation")), str(f.get("object"))) for f in store.current(subject=subject)
                 if not f.get("attr") and f.get("object")]
        links += [(f"{f.get('relation')} (from)", str(f["subject"])) for f in store.facts(object=subject)
                  if not str(f["subject"]).startswith(("point:", "phrase:", TAG_HEAD))]
    return {"facts": facts, "tags": tags, "on": on, "disputes": disputes, "links": sorted(set(links))}


WHOLE = "whole in full"


def as_text(subject: str, read: dict, form: str = "source") -> str:
    """Intention: a thing's reading as one page of text to look through and search; a kept paper's whole text is
    given in the form asked for (1830f: warp2/research/paper_forms.py)."""
    from warp2.research.paper_forms import as_form
    lines = [subject, ""]
    facts = [(what, as_form(value, form) if what == WHOLE else value) for what, value in read["facts"]]
    lines += [f"{what}:\n{value}\n" if "\n" in value or len(value) > 100 else f"{what}: {value}" for what, value in facts]
    if read["on"]:
        lines += ["", "This tag is on:"] + [f"  {name}" for name in read["on"]]
    return "\n".join(lines)


def _inbox():
    """Intention (1945t): the inbox as it is on disk now. The window keeps the parts of the warp it has already
    brought in, and one brought in before the tag and dispute asks existed does not know them - then it is brought
    in again (the Add tag button did nothing: Andrew 2026-11-19 18:33, "the libary tag is still not working")."""
    import importlib
    from warp2.ask import inbox
    return inbox if hasattr(inbox, "KEPT_APART") else importlib.reload(inbox)


def add_text(state, title: str, text: str, about: str = "") -> dict:
    """Intention: words the user typed, kept as a file the runner takes into the KG (the ask is what is handed back)."""
    name = "".join(c if c.isalnum() or c in "-_ ." else "_" for c in title).strip() or "note"
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / (name if "." in name else name + ".txt")
        path.write_text(text, encoding="utf-8")
        return _inbox().Inbox(state).put_file(path, said=title, about=about)


def add_file(state, path, said: str = "", about: str = "") -> dict:
    """Intention: a file the user picked, copied in for the runner to take into the KG."""
    return _inbox().Inbox(state).put_file(path, said=said, about=about)


def add_tag(state, subject: str, words: str) -> dict:
    """Intention: the user's own tag on a thing, asked of the runner."""
    inbox = _inbox()
    return inbox.Inbox(state).put(inbox.TAG, said=words.strip(), about=subject)


def dispute(state, subject: str, tag: str, why: str) -> dict:
    """Intention: the user's word against a tag that is on a thing, asked of the runner."""
    inbox = _inbox()
    return inbox.Inbox(state).put(inbox.DISPUTE, said=why.strip(), about=subject, tag=tag)
